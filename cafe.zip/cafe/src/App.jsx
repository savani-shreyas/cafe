import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import SuperAdminDashboard from "./components/superadmin/SuperAdminDashboard";
import CafeOwnerPanel from "./components/cafeowner/CafeOwnerPanel";
import CustomerView from "./components/customer/CustomerView";
import SuperAdminLogin from "./components/auth/SuperAdminLogin";
import CafeOwnerLogin from "./components/auth/CafeOwnerLogin";
import { 
  INITIAL_CAFES, getStoredCafes, saveStoredCafes, playChime 
} from "./data/mockData";
import { Coffee } from "lucide-react";

// Route detector helper
function getInitialPortal() {
  if (typeof window === "undefined") return "customer";
  const path = window.location.pathname.toLowerCase();
  const search = window.location.search.toLowerCase();
  const hash = window.location.hash.toLowerCase();

  if (
    path.includes("superadmin") || 
    path.includes("/admin") || 
    search.includes("portal=superadmin") || 
    hash.includes("superadmin")
  ) {
    return "superadmin";
  }

  if (
    path.includes("cafeadmin") || 
    path.includes("cafeowner") || 
    path.includes("/owner") || 
    search.includes("portal=cafeowner") || 
    hash.includes("cafeowner")
  ) {
    return "cafeowner";
  }

  return "customer";
}

export default function App() {
  const [cafes, setCafes] = useState(getStoredCafes);
  const [portalMode, setPortalMode] = useState(getInitialPortal); // "customer", "superadmin", "cafeowner"
  const [activeCafeId, setActiveCafeId] = useState("cafe-aroma-01");
  const [theme, setTheme] = useState("light");
  const [currency, setCurrency] = useState("INR");
  const [scannedTableInfo, setScannedTableInfo] = useState(null);
  const [showMyReservationsModal, setShowMyReservationsModal] = useState(false);

  // Shopping Cart State
  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem("aroma_customer_cart");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Persist cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("aroma_customer_cart", JSON.stringify(cart));
    } catch (e) {
      console.error("Failed to save cart:", e);
    }
  }, [cart]);

  // Total items count in order cart
  const cartCount = cart.reduce((total, item) => total + (item.quantity || 1), 0);

  // Authentication Session
  const [authSession, setAuthSession] = useState(() => {
    try {
      const saved = localStorage.getItem("aroma_auth_session");
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  // Theme Sync
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  // Listen to popstate for browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      setPortalMode(getInitialPortal());
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  // Check URL params for direct QR scan simulation on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cafeParam = params.get("cafe");
    const tableParam = params.get("table");
    if (cafeParam && tableParam) {
      handleSimulateTableScan(cafeParam, tableParam);
    }
  }, []);

  // Save to LocalStorage whenever cafes state changes
  const updateCafesState = (updatedList) => {
    setCafes(updatedList);
    saveStoredCafes(updatedList);
  };

  const handleUpdateSingleCafe = (updatedCafe) => {
    const nextList = cafes.map(c => c.id === updatedCafe.id ? updatedCafe : c);
    updateCafesState(nextList);
  };

  // Navigation handler
  const navigateTo = (targetPortal) => {
    setPortalMode(targetPortal);
    let targetPath = "/";
    if (targetPortal === "superadmin") targetPath = "/superadmin";
    else if (targetPortal === "cafeowner") targetPath = "/cafeadmin";
    window.history.pushState(null, "", targetPath);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Auth Handlers
  const handleSuperAdminLoginSuccess = (sessionData) => {
    setAuthSession(sessionData);
    localStorage.setItem("aroma_auth_session", JSON.stringify(sessionData));
    setPortalMode("superadmin");
  };

  const handleCafeOwnerLoginSuccess = (sessionData) => {
    setAuthSession(sessionData);
    localStorage.setItem("aroma_auth_session", JSON.stringify(sessionData));
    if (sessionData.cafeId) {
      setActiveCafeId(sessionData.cafeId);
    }
    setPortalMode("cafeowner");
  };

  const handleLogout = () => {
    setAuthSession(null);
    localStorage.removeItem("aroma_auth_session");
    navigateTo("customer");
    playChime("alert");
  };

  // Simulate scanning a table QR code
  const handleSimulateTableScan = (cafeId, tableId) => {
    if (!cafeId || !tableId) {
      setScannedTableInfo(null);
      return;
    }
    const targetCafe = cafes.find(c => c.id === cafeId) || cafes[0];
    const targetTable = targetCafe.tables?.find(t => t.id === tableId) || { id: tableId, number: `Table #${tableId}` };

    const updatedTables = targetCafe.tables?.map(t => {
      if (t.id === tableId) {
        return { ...t, scanCount: (t.scanCount || 0) + 1 };
      }
      return t;
    }) || [];
    handleUpdateSingleCafe({ ...targetCafe, tables: updatedTables });

    setActiveCafeId(cafeId);
    setScannedTableInfo({
      cafeId,
      tableId,
      tableNumber: targetTable.number
    });
    setPortalMode("customer");
    playChime("success");
  };

  // Add new customer reservation
  const handleAddReservation = (cafeId, newReservation) => {
    const targetCafe = cafes.find(c => c.id === cafeId);
    if (!targetCafe) return;
    const updatedReservations = [newReservation, ...(targetCafe.reservations || [])];
    handleUpdateSingleCafe({ ...targetCafe, reservations: updatedReservations });
  };

  // Place new order
  const handlePlaceOrder = (cafeId, newOrder) => {
    const targetCafe = cafes.find(c => c.id === cafeId);
    if (!targetCafe) return;
    const updatedOrders = [newOrder, ...(targetCafe.orders || [])];
    handleUpdateSingleCafe({ ...targetCafe, orders: updatedOrders });
  };

  // Cancel reservation
  const handleCancelReservation = (resId) => {
    const nextList = cafes.map(c => {
      const match = c.reservations?.find(r => r.id === resId);
      if (match) {
        return {
          ...c,
          reservations: c.reservations.map(r => r.id === resId ? { ...r, status: "cancelled" } : r)
        };
      }
      return c;
    });
    updateCafesState(nextList);
    playChime("alert");
  };

  const allUserReservations = cafes.flatMap(c => c.reservations || []);
  const activeCafe = cafes.find(c => c.id === activeCafeId) || cafes[0];

  // =========================================================
  // VIEW ROUTING
  // =========================================================

  // 1. DEDICATED SUPER ADMIN ROUTE (/superadmin)
  if (portalMode === "superadmin") {
    if (authSession?.role !== "superadmin") {
      return (
        <SuperAdminLogin 
          onLoginSuccess={handleSuperAdminLoginSuccess}
          onReturnToCustomer={() => navigateTo("customer")}
        />
      );
    }

    return (
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Navbar
          portalMode="superadmin"
          cafes={cafes}
          activeCafeId={activeCafeId}
          setActiveCafeId={setActiveCafeId}
          theme={theme}
          setTheme={setTheme}
          authSession={authSession}
          onNavigate={navigateTo}
          onLogout={handleLogout}
        />
        <main style={{ flex: 1 }}>
          <SuperAdminDashboard
            cafes={cafes}
            currency={currency}
            onUpdateCafes={updateCafesState}
            onSwitchToCafeOwner={(cafeId) => {
              setActiveCafeId(cafeId);
              navigateTo("cafeowner");
            }}
          />
        </main>
      </div>
    );
  }

  // 2. DEDICATED CAFÉ OWNER ROUTE (/cafeadmin)
  if (portalMode === "cafeowner") {
    if (authSession?.role !== "cafeowner" && authSession?.role !== "superadmin") {
      return (
        <CafeOwnerLogin 
          cafes={cafes}
          onLoginSuccess={handleCafeOwnerLoginSuccess}
          onReturnToCustomer={() => navigateTo("customer")}
        />
      );
    }

    return (
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Navbar
          portalMode="cafeowner"
          cafes={cafes}
          activeCafeId={activeCafeId}
          setActiveCafeId={setActiveCafeId}
          theme={theme}
          setTheme={setTheme}
          authSession={authSession}
          onNavigate={navigateTo}
          onLogout={handleLogout}
        />
        <main style={{ flex: 1 }}>
          <CafeOwnerPanel
            cafe={activeCafe}
            currency={currency}
            onUpdateCafe={handleUpdateSingleCafe}
            onSimulateTableScan={handleSimulateTableScan}
          />
        </main>
      </div>
    );
  }

  // 3. PURE CUSTOMER WEBSITE (NO ADMIN OPTIONS DISPLAYED)
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* 100% Clean Customer Navigation */}
      <Navbar
        portalMode="customer"
        cafes={cafes}
        activeCafeId={activeCafeId}
        setActiveCafeId={setActiveCafeId}
        theme={theme}
        setTheme={setTheme}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenMyReservations={() => setShowMyReservationsModal(true)}
        scannedTableInfo={scannedTableInfo}
        onClearScannedTable={() => setScannedTableInfo(null)}
        authSession={null}
        onNavigate={navigateTo}
        onLogout={handleLogout}
      />

      {/* Main Customer View */}
      <main style={{ flex: 1 }}>
        <CustomerView
          cafes={cafes}
          currency={currency}
          activeCafeId={activeCafeId}
          setActiveCafeId={setActiveCafeId}
          scannedTableInfo={scannedTableInfo}
          onClearScannedTable={() => setScannedTableInfo(null)}
          onAddReservation={handleAddReservation}
          onPlaceOrder={handlePlaceOrder}
          myReservations={allUserReservations}
          onCancelReservation={handleCancelReservation}
          isMobileFrame={false}
          showMyReservationsModal={showMyReservationsModal}
          setShowMyReservationsModal={setShowMyReservationsModal}
          cart={cart}
          setCart={setCart}
          isCartOpen={isCartOpen}
          setIsCartOpen={setIsCartOpen}
        />
      </main>

      {/* Pure Customer Footer (Zero Admin Options / Links) */}
      <footer style={{
        background: "var(--cafe-card)",
        borderTop: "1px solid var(--cafe-border)",
        padding: "48px 24px 28px 24px",
        marginTop: "60px"
      }}>
        <div style={{
          maxWidth: "1280px",
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: "36px",
          marginBottom: "36px"
        }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
              <div style={{
                width: "36px",
                height: "36px",
                borderRadius: "10px",
                background: "var(--cafe-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#FFF"
              }}>
                <Coffee size={20} />
              </div>
              <span style={{ fontFamily: "var(--font-heading)", fontSize: "1.3rem", fontWeight: "800" }}>
                Aroma<span style={{ color: "var(--cafe-primary)" }}>Cloud</span>
              </span>
            </div>
            <p style={{ fontSize: "0.9rem", color: "var(--cafe-text-muted)", lineHeight: 1.6 }}>
              Specialty micro-roasteries and artisan kitchens. Experience seamless online table reservations, curated culinary menus, and direct table ordering.
            </p>
          </div>

          <div>
            <h4 style={{ fontSize: "1rem", fontWeight: "700", marginBottom: "14px", color: "var(--cafe-text)" }}>
              Opening Hours & Hospitality
            </h4>
            <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", lineHeight: 1.8 }}>
              Monday – Friday: 07:30 AM – 10:30 PM<br/>
              Saturday – Sunday: 08:00 AM – 11:00 PM<br/>
              Breakfast & Brunch: Until 02:00 PM<br/>
              Dine-in, Takeaway & Private Bookings
            </p>
          </div>

          <div>
            <h4 style={{ fontSize: "1rem", fontWeight: "700", marginBottom: "14px", color: "var(--cafe-text)" }}>
              Locations & Contact
            </h4>
            <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", lineHeight: 1.8 }}>
              Flagship Roastery: 42 Heritage Boulevard, Old Town<br/>
              Phone: +1 (555) 234-8900<br/>
              Email: concierge@aromacloud.com<br/>
              San Francisco, California
            </p>
          </div>
        </div>

        <div style={{
          maxWidth: "1280px",
          margin: "0 auto",
          paddingTop: "24px",
          borderTop: "1px solid var(--cafe-border)",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "12px",
          fontSize: "0.85rem",
          color: "var(--cafe-text-muted)"
        }}>
          <div>© 2026 AromaCloud Artisan Dining Network. All rights reserved.</div>
          <div>Warm Amber Roast & Italian Hospitality</div>
        </div>
      </footer>
    </div>
  );
}
