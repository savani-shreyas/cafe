import React, { useState } from "react";
import { 
  Building2, Plus, Search, ShieldCheck, Download, Database, 
  BarChart3, Users, DollarSign, Store, CheckCircle, XCircle, 
  Trash2, Edit3, ArrowRight, Eye, RefreshCw, Key, Mail, Phone,
  Clock, MapPin, Sparkles, AlertCircle
} from "lucide-react";
import { exportToCsv, playChime } from "../../data/mockData";

export default function SuperAdminDashboard({
  cafes,
  onUpdateCafes,
  onSwitchToCafeOwner
}) {
  const [activeTab, setActiveTab] = useState("cafes"); // "cafes", "analytics", "backup"
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showIntegrityResult, setShowIntegrityResult] = useState(null);
  const [customerSearchPhone, setCustomerSearchPhone] = useState("");
  const [selectedCafeForDetails, setSelectedCafeForDetails] = useState(null);

  // Form State for New Cafe Account
  const [newCafe, setNewCafe] = useState({
    ownerName: "",
    mobile: "",
    email: "",
    shopName: "",
    shopAddress: "",
    city: "",
    state: "",
    pincode: "",
    description: "",
    contactNumber: "",
    category: "Fine Casual",
    seatingCapacity: 40,
    openHours: "08:00 - 22:00",
    cuisines: ["Artisan Coffee", "Italian"],
    image: "/images/artisan_cafe_ambiance.jpg",
    bankName: "",
    accountNumber: "",
    swiftIfsc: "",
    permissionLevel: "Full Operations"
  });

  // Calculate totals
  const totalCafes = cafes.length;
  const activeCafes = cafes.filter(c => c.status === "active").length;
  const inactiveCafes = totalCafes - activeCafes;
  const totalMonthlyOrders = cafes.reduce((sum, c) => sum + (c.stats?.monthlyOrders || 0), 0);
  const totalNetworkRevenue = cafes.reduce((sum, c) => sum + (c.stats?.monthlyRevenue || 0), 0);
  const totalTablesNetwork = cafes.reduce((sum, c) => sum + (c.tables?.length || 0), 0);

  // Filtered cafes
  const filteredCafes = cafes.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" ? true : c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Handle Toggle Active/Inactive
  const handleToggleStatus = (cafeId) => {
    const updated = cafes.map(c => {
      if (c.id === cafeId) {
        const nextStatus = c.status === "active" ? "inactive" : "active";
        return { ...c, status: nextStatus };
      }
      return c;
    });
    onUpdateCafes(updated);
    playChime("alert");
  };

  // Handle Delete Cafe
  const handleDeleteCafe = (cafeId) => {
    if (window.confirm("Are you sure you want to remove this café franchise account?")) {
      const updated = cafes.filter(c => c.id !== cafeId);
      onUpdateCafes(updated);
      playChime("alert");
    }
  };

  // Helper for Auto-generated Username
  const generateUsername = (shopName, ownerName) => {
    const cleanShop = (shopName || "cafe").toLowerCase().replace(/[^a-z0-9]/g, "_").slice(0, 14);
    const cleanOwner = (ownerName || "owner").toLowerCase().replace(/[^a-z0-9]/g, "_").slice(0, 10);
    return `${cleanShop}_${cleanOwner}`;
  };

  // Handle Create Cafe Submit
  const handleCreateCafe = (e) => {
    e.preventDefault();
    if (!newCafe.ownerName || !newCafe.mobile || !newCafe.email || !newCafe.shopName) {
      alert("Please fill in all required fields.");
      return;
    }

    const autoUsername = generateUsername(newCafe.shopName, newCafe.ownerName);
    const autoPassword = `Cafe#${Math.floor(100000 + Math.random() * 900000)}!`;
    const newId = `cafe-${Date.now().toString().slice(-6)}`;

    const createdRecord = {
      id: newId,
      name: newCafe.shopName,
      ownerName: newCafe.ownerName,
      mobile: newCafe.mobile,
      email: newCafe.email,
      shopAddress: newCafe.shopAddress || "Main Avenue",
      city: newCafe.city || "Metropolis",
      state: newCafe.state || "State",
      pincode: newCafe.pincode || "10001",
      description: newCafe.description || "Artisan culinary destination providing handcrafted food and beverages.",
      contactNumber: newCafe.contactNumber || newCafe.mobile,
      category: newCafe.category,
      seatingCapacity: Number(newCafe.seatingCapacity) || 30,
      openHours: newCafe.openHours,
      cuisines: newCafe.cuisines,
      image: newCafe.image,
      gallery: [newCafe.image, "/images/gourmet_cafe_dishes.jpg"],
      bankDetails: {
        bankName: newCafe.bankName || "Commercial Business Bank",
        accountNumber: newCafe.accountNumber || "8821-3991-0021",
        swiftIfsc: newCafe.swiftIfsc || "SWFTUS33",
        accountType: "Commercial Merchant"
      },
      credentials: {
        username: autoUsername,
        tempPassword: autoPassword,
        permissionLevel: newCafe.permissionLevel,
        status: "active"
      },
      status: "active",
      rating: 5.0,
      reviewCount: 1,
      priceRange: "$$",
      createdAt: new Date().toISOString().split("T")[0],
      updatedAt: new Date().toISOString().split("T")[0],
      stats: {
        monthlyOrders: 0,
        monthlyRevenue: 0,
        customerGrowth: "+0%"
      },
      tables: [
        { id: "T001", number: "Table 1", capacity: 2, location: "Center", features: ["Standard"], status: "available", setupFee: 15, scanCount: 0 },
        { id: "T002", number: "Table 2", capacity: 4, location: "Near Window", features: ["Window view"], status: "available", setupFee: 20, scanCount: 0 }
      ],
      menuCategories: [
        { id: "cat-1", name: "House Specials", icon: "☕", displayOrder: 1, active: true }
      ],
      menuItems: [],
      offers: [],
      reservations: [],
      orders: [],
      eventRequests: []
    };

    onUpdateCafes([createdRecord, ...cafes]);
    setShowCreateModal(false);
    playChime("success");
    alert(`Café "${newCafe.shopName}" successfully created!\n\nAuto-Generated Login Credentials:\nUsername: ${autoUsername}\nPassword: ${autoPassword}\n\n(A simulated credentials email has been dispatched to ${newCafe.email})`);
  };

  // Export Customer Data to CSV
  const handleExportCustomers = () => {
    const customerRows = [];
    cafes.forEach(c => {
      // Collect from reservations
      c.reservations?.forEach(r => {
        customerRows.push({
          "Customer Name": r.customerName,
          "Phone": r.phone,
          "Email": r.email,
          "Café Franchise": c.name,
          "Activity Type": "Table Reservation",
          "Date": r.date,
          "Party Size": r.partySize,
          "Status": r.status
        });
      });
      // Collect from orders
      c.orders?.forEach(o => {
        customerRows.push({
          "Customer Name": o.customerName,
          "Phone": o.phone,
          "Email": "N/A (Direct Scan)",
          "Café Franchise": c.name,
          "Activity Type": "Order Placed",
          "Date": o.createdAt,
          "Party Size": "N/A",
          "Status": o.status + ` (₹${o.total})`
        });
      });
    });

    if (customerRows.length === 0) {
      alert("No customer records found to export.");
      return;
    }
    exportToCsv("AromaCloud_Franchise_Customer_Records.csv", customerRows);
    playChime("success");
  };

  // Export Cafe Directory CSV
  const handleExportCafesCsv = () => {
    const rows = cafes.map(c => ({
      "Café ID": c.id,
      "Café Name": c.name,
      "Owner Name": c.ownerName,
      "Mobile": c.mobile,
      "Email": c.email,
      "Category": c.category,
      "City": c.city,
      "Capacity": c.seatingCapacity,
      "Tables Count": c.tables?.length || 0,
      "Monthly Orders": c.stats?.monthlyOrders || 0,
      "Monthly Revenue (₹)": c.stats?.monthlyRevenue || 0,
      "Status": c.status,
      "Created At": c.createdAt
    }));
    exportToCsv("AromaCloud_All_Franchises.csv", rows);
    playChime("success");
  };

  // Run Data Integrity Check
  const handleRunIntegrityCheck = () => {
    const issues = [];
    let checkedTables = 0;
    let checkedOrders = 0;

    cafes.forEach(c => {
      checkedTables += c.tables?.length || 0;
      checkedOrders += c.orders?.length || 0;
      if (!c.email || !c.mobile) issues.push(`Café "${c.name}" has incomplete owner contact information.`);
      if (!c.tables || c.tables.length === 0) issues.push(`Café "${c.name}" has no registered tables.`);
    });

    setShowIntegrityResult({
      checkedAt: new Date().toLocaleTimeString(),
      totalCafesChecked: cafes.length,
      tablesAudited: checkedTables,
      ordersAudited: checkedOrders,
      issuesFound: issues,
      status: issues.length === 0 ? "PASSED - 100% HEALTHY" : "WARNINGS DETECTED"
    });
    playChime("success");
  };

  return (
    <div style={{ maxWidth: "1350px", margin: "0 auto", padding: "24px 20px" }}>
      {/* Super Admin Top Header */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "16px",
        marginBottom: "24px"
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <span style={{
              background: "#FEF3C7",
              color: "#92400E",
              padding: "4px 10px",
              borderRadius: "var(--radius-full)",
              fontSize: "0.75rem",
              fontWeight: "800",
              display: "inline-flex",
              alignItems: "center",
              gap: "4px"
            }}>
              <ShieldCheck size={14} /> SUPER ADMIN HEADQUARTERS
            </span>
            <span style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
              Franchise Governance & Network Oversight
            </span>
          </div>
          <h1 style={{ fontSize: "1.9rem", marginTop: "4px" }}>
            Franchise Operations & Account Center
          </h1>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary"
            style={{ padding: "10px 18px" }}
          >
            <Plus size={18} />
            <span>Create New Café Account</span>
          </button>
        </div>
      </div>

      {/* Network KPI Cards */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
        gap: "16px",
        marginBottom: "24px"
      }}>
        <div className="glass-card" style={{ padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
            <span>Total Franchises</span>
            <Store size={18} color="var(--cafe-primary)" />
          </div>
          <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
            {totalCafes}
          </div>
          <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
            <span style={{ color: "#16A34A", fontWeight: "700" }}>{activeCafes} Active</span> • <span>{inactiveCafes} Inactive</span>
          </div>
        </div>

        <div className="glass-card" style={{ padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
            <span>Network Monthly Orders</span>
            <BarChart3 size={18} color="#2563EB" />
          </div>
          <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
            {totalMonthlyOrders.toLocaleString()}
          </div>
          <div style={{ fontSize: "0.8rem", color: "#16A34A", fontWeight: "700", marginTop: "4px" }}>
            ↑ +18.4% vs last month
          </div>
        </div>

        <div className="glass-card" style={{ padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
            <span>Network Revenue</span>
            <DollarSign size={18} color="var(--cafe-primary)" />
          </div>
          <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
            ₹{totalNetworkRevenue.toLocaleString()}
          </div>
          <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
            Avg ₹{(totalNetworkRevenue / (totalCafes || 1)).toFixed(0)} / café
          </div>
        </div>

        <div className="glass-card" style={{ padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
            <span>Managed Tables</span>
            <Users size={18} color="#9333EA" />
          </div>
          <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
            {totalTablesNetwork}
          </div>
          <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
            Real-time QR tracking enabled
          </div>
        </div>
      </div>

      {/* Sub Tabs Navigation */}
      <div style={{
        display: "flex",
        borderBottom: "1px solid var(--cafe-border)",
        gap: "24px",
        marginBottom: "24px"
      }}>
        <button
          onClick={() => setActiveTab("cafes")}
          style={{
            padding: "10px 4px",
            fontSize: "0.95rem",
            fontWeight: "700",
            color: activeTab === "cafes" ? "var(--cafe-primary)" : "var(--cafe-text-muted)",
            borderBottom: activeTab === "cafes" ? "3px solid var(--cafe-primary)" : "3px solid transparent",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <Building2 size={18} />
          <span>All Cafés ({cafes.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("analytics")}
          style={{
            padding: "10px 4px",
            fontSize: "0.95rem",
            fontWeight: "700",
            color: activeTab === "analytics" ? "var(--cafe-primary)" : "var(--cafe-text-muted)",
            borderBottom: activeTab === "analytics" ? "3px solid var(--cafe-primary)" : "3px solid transparent",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <BarChart3 size={18} />
          <span>Franchise Analytics</span>
        </button>

        <button
          onClick={() => setActiveTab("backup")}
          style={{
            padding: "10px 4px",
            fontSize: "0.95rem",
            fontWeight: "700",
            color: activeTab === "backup" ? "var(--cafe-primary)" : "var(--cafe-text-muted)",
            borderBottom: activeTab === "backup" ? "3px solid var(--cafe-primary)" : "3px solid transparent",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <Database size={18} />
          <span>Backup & Data Management</span>
        </button>
      </div>

      {/* TAB 1: ALL CAFES DIRECTORY */}
      {activeTab === "cafes" && (
        <div>
          {/* Controls Bar */}
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "12px",
            marginBottom: "18px"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", flex: 1, minWidth: "260px" }}>
              <div style={{ position: "relative", width: "100%", maxWidth: "360px" }}>
                <Search size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--cafe-text-muted)" }} />
                <input
                  type="text"
                  placeholder="Search by café, owner, or city..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="form-input"
                  style={{ paddingLeft: "36px" }}
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="form-select"
                style={{ width: "auto" }}
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="inactive">Inactive Only</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: "8px" }}>
              <button onClick={handleExportCafesCsv} className="btn-secondary" style={{ fontSize: "0.85rem", padding: "8px 14px" }}>
                <Download size={15} /> Export Cafés CSV
              </button>
            </div>
          </div>

          {/* Cafes Table */}
          <div className="glass-card" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.9rem" }}>
              <thead>
                <tr style={{ background: "var(--cafe-card-alt)", borderBottom: "1px solid var(--cafe-border)", color: "var(--cafe-text-muted)" }}>
                  <th style={{ padding: "14px 16px" }}>Café Details</th>
                  <th style={{ padding: "14px 16px" }}>Owner Contact</th>
                  <th style={{ padding: "14px 16px" }}>Seating & Tables</th>
                  <th style={{ padding: "14px 16px" }}>Monthly Orders</th>
                  <th style={{ padding: "14px 16px" }}>Revenue</th>
                  <th style={{ padding: "14px 16px" }}>Status</th>
                  <th style={{ padding: "14px 16px", textAlign: "right" }}>Quick Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCafes.map((c) => (
                  <tr key={c.id} style={{ borderBottom: "1px solid var(--cafe-border-light)" }}>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                        <img 
                          src={c.image} 
                          alt={c.name}
                          style={{ width: "48px", height: "48px", borderRadius: "10px", objectFit: "cover" }}
                        />
                        <div>
                          <div style={{ fontWeight: "700", color: "var(--cafe-text)" }}>
                            {c.name}
                          </div>
                          <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)", display: "flex", alignItems: "center", gap: "4px" }}>
                            <MapPin size={12} /> {c.city}, {c.state} • <span style={{ color: "var(--cafe-primary)", fontWeight: "600" }}>{c.category}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "600" }}>{c.ownerName}</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>{c.mobile}</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>{c.email}</div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "600" }}>{c.tables?.length || 0} Tables</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>
                        {c.seatingCapacity} Seats Capacity
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "700" }}>{c.stats?.monthlyOrders?.toLocaleString() || 0}</div>
                      <div style={{ fontSize: "0.75rem", color: "#16A34A" }}>{c.stats?.customerGrowth || "+0%"}</div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "700", color: "var(--cafe-primary)" }}>
                        ₹{c.stats?.monthlyRevenue?.toLocaleString() || 0}
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <span className={`badge ${c.status === "active" ? "badge-active" : "badge-inactive"}`}>
                        {c.status}
                      </span>
                    </td>

                    <td style={{ padding: "14px 16px", textAlign: "right" }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: "8px" }}>
                        {/* Switch to this Cafe's Admin Panel */}
                        <button
                          onClick={() => onSwitchToCafeOwner(c.id)}
                          title="Manage this cafe directly as Owner"
                          className="btn-primary"
                          style={{ padding: "6px 10px", fontSize: "0.78rem" }}
                        >
                          <span>Manage</span>
                          <ArrowRight size={14} />
                        </button>

                        {/* Toggle Status */}
                        <button
                          onClick={() => handleToggleStatus(c.id)}
                          title={c.status === "active" ? "Deactivate Account" : "Activate Account"}
                          style={{
                            padding: "6px 10px",
                            borderRadius: "var(--radius-md)",
                            border: "1px solid var(--cafe-border)",
                            background: "var(--cafe-card-alt)",
                            color: c.status === "active" ? "#DC2626" : "#16A34A",
                            fontSize: "0.8rem",
                            cursor: "pointer"
                          }}
                        >
                          {c.status === "active" ? "Deactivate" : "Activate"}
                        </button>

                        {/* View Details */}
                        <button
                          onClick={() => setSelectedCafeForDetails(c)}
                          title="View Cafe Details & Credentials"
                          style={{
                            padding: "6px 8px",
                            borderRadius: "var(--radius-md)",
                            border: "1px solid var(--cafe-border)",
                            background: "var(--cafe-card-alt)",
                            color: "var(--cafe-text-muted)"
                          }}
                        >
                          <Eye size={15} />
                        </button>

                        {/* Delete Cafe */}
                        <button
                          onClick={() => handleDeleteCafe(c.id)}
                          title="Delete Cafe Account"
                          style={{
                            padding: "6px 8px",
                            borderRadius: "var(--radius-md)",
                            border: "1px solid #FECACA",
                            background: "#FEF2F2",
                            color: "#DC2626"
                          }}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredCafes.length === 0 && (
              <div style={{ padding: "40px", textAlign: "center", color: "var(--cafe-text-muted)" }}>
                No café franchises found matching your search.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: ANALYTICS DASHBOARD */}
      {activeTab === "analytics" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "20px" }}>
            {/* Monthly Registration Trends Chart */}
            <div className="glass-card" style={{ padding: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                <div>
                  <h3 style={{ fontSize: "1.1rem" }}>Franchise Registrations & Growth Trend</h3>
                  <p style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>2026 Monthly New Onboardings & Active Locations</p>
                </div>
                <span className="badge badge-primary">MONTHLY TREND</span>
              </div>

              {/* Visual SVG Bar Chart */}
              <div style={{ height: "200px", display: "flex", alignItems: "flex-end", gap: "16px", padding: "10px 0", borderBottom: "1px solid var(--cafe-border)" }}>
                {[
                  { month: "May", count: 2, height: "35%" },
                  { month: "Jun", count: 4, height: "50%" },
                  { month: "Jul", count: 6, height: "65%" },
                  { month: "Aug", count: 7, height: "70%" },
                  { month: "Sep", count: 9, height: "85%" },
                  { month: "Oct (Now)", count: 12, height: "100%" }
                ].map((bar, idx) => (
                  <div key={idx} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: "8px" }}>
                    <span style={{ fontSize: "0.75rem", fontWeight: "700", color: "var(--cafe-primary)" }}>{bar.count}</span>
                    <div style={{
                      width: "100%",
                      maxWidth: "42px",
                      height: bar.height,
                      background: "linear-gradient(180deg, var(--cafe-primary) 0%, #1A120B 100%)",
                      borderRadius: "6px 6px 0 0",
                      transition: "height 0.3s ease"
                    }} />
                    <span style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>{bar.month}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: "12px", fontSize: "0.8rem", color: "var(--cafe-text-muted)", display: "flex", justifyContent: "space-between" }}>
                <span>Consistent 28% MoM Network Expansion</span>
                <span style={{ fontWeight: "700", color: "#16A34A" }}>Target 2026: 25 Franchises</span>
              </div>
            </div>

            {/* Top Performing Cafés Leaderboard */}
            <div className="glass-card" style={{ padding: "24px" }}>
              <div style={{ marginBottom: "16px" }}>
                <h3 style={{ fontSize: "1.1rem" }}>Top-Performing Cafés Leaderboard</h3>
                <p style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Ranked by monthly gross orders and customer reviews</p>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {cafes.slice(0, 3).map((c, index) => (
                  <div key={c.id} style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "12px",
                    background: "var(--cafe-card-alt)",
                    borderRadius: "var(--radius-md)",
                    border: "1px solid var(--cafe-border-light)"
                  }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                      <span style={{
                        width: "28px",
                        height: "28px",
                        borderRadius: "50%",
                        background: index === 0 ? "#F59E0B" : index === 1 ? "#94A3B8" : "#B45309",
                        color: "#FFF",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontWeight: "800",
                        fontSize: "0.8rem"
                      }}>
                        #{index + 1}
                      </span>
                      <div>
                        <div style={{ fontWeight: "700", fontSize: "0.95rem" }}>{c.name}</div>
                        <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                          ★ {c.rating} ({c.reviewCount || 100}+ reviews) • {c.category}
                        </div>
                      </div>
                    </div>

                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontWeight: "700", color: "var(--cafe-primary)" }}>
                        ₹{c.stats?.monthlyRevenue?.toLocaleString() || 0}
                      </div>
                      <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                        {c.stats?.monthlyOrders || 0} orders
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* System Health & Usage Statistics */}
          <div className="glass-card" style={{ padding: "24px" }}>
            <h3 style={{ fontSize: "1.1rem", marginBottom: "16px" }}>System Infrastructure & Usage Statistics</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
              <div style={{ padding: "16px", background: "var(--cafe-card-alt)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Franchise API Uptime</div>
                <div style={{ fontSize: "1.4rem", fontWeight: "800", color: "#16A34A", marginTop: "4px" }}>99.98%</div>
                <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>Zero critical outages reported</div>
              </div>
              <div style={{ padding: "16px", background: "var(--cafe-card-alt)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Avg Table Order Latency</div>
                <div style={{ fontSize: "1.4rem", fontWeight: "800", color: "var(--cafe-primary)", marginTop: "4px" }}>42 ms</div>
                <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>Instant KDS WebSocket sync</div>
              </div>
              <div style={{ padding: "16px", background: "var(--cafe-card-alt)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Table QR Scans Today</div>
                <div style={{ fontSize: "1.4rem", fontWeight: "800", color: "#2563EB", marginTop: "4px" }}>1,492 scans</div>
                <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>82% conversion to order</div>
              </div>
              <div style={{ padding: "16px", background: "var(--cafe-card-alt)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Database Storage</div>
                <div style={{ fontSize: "1.4rem", fontWeight: "800", color: "#7C3AED", marginTop: "4px" }}>18.4 MB / 10 GB</div>
                <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>Scheduled daily cloud backups</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BACKUP & DATA MANAGEMENT */}
      {activeTab === "backup" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {/* Quick Data Exports Bar */}
          <div className="glass-card" style={{ padding: "24px" }}>
            <h3 style={{ fontSize: "1.1rem", marginBottom: "8px" }}>Network Data Backups & Exports</h3>
            <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", marginBottom: "20px" }}>
              Generate comprehensive CSV/Excel export files containing customer records, transactions, table reservations, and franchise financials.
            </p>

            <div style={{ display: "flex", flexWrap: "wrap", gap: "12px" }}>
              <button onClick={handleExportCustomers} className="btn-primary">
                <Download size={18} />
                <span>Export All Customers Database (CSV)</span>
              </button>

              <button onClick={handleExportCafesCsv} className="btn-secondary">
                <Download size={18} />
                <span>Export Franchise Registry & Financials</span>
              </button>

              <button onClick={handleRunIntegrityCheck} className="btn-secondary">
                <RefreshCw size={18} />
                <span>Run Data Integrity Audit</span>
              </button>
            </div>

            {/* Audit Results Box */}
            {showIntegrityResult && (
              <div style={{
                marginTop: "20px",
                padding: "16px",
                borderRadius: "var(--radius-md)",
                background: showIntegrityResult.issuesFound.length === 0 ? "#DCFCE7" : "#FEF3C7",
                border: "1px solid " + (showIntegrityResult.issuesFound.length === 0 ? "#86EFAC" : "#FDE68A")
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: "700" }}>
                  <CheckCircle size={18} color={showIntegrityResult.issuesFound.length === 0 ? "#16A34A" : "#D97706"} />
                  <span>Integrity Scan Status: {showIntegrityResult.status}</span>
                </div>
                <div style={{ fontSize: "0.85rem", marginTop: "6px" }}>
                  Audited <strong>{showIntegrityResult.totalCafesChecked}</strong> cafés, <strong>{showIntegrityResult.tablesAudited}</strong> registered tables, and <strong>{showIntegrityResult.ordersAudited}</strong> order transactions.
                </div>
                {showIntegrityResult.issuesFound.length > 0 && (
                  <ul style={{ marginTop: "8px", paddingLeft: "20px", fontSize: "0.85rem", color: "#B45309" }}>
                    {showIntegrityResult.issuesFound.map((iss, i) => (
                      <li key={i}>{iss}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* Backup Schedule & Logs */}
          <div className="glass-card" style={{ padding: "24px" }}>
            <h3 style={{ fontSize: "1.1rem", marginBottom: "8px" }}>Automated Database Backup Scheduling</h3>
            <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", marginBottom: "16px" }}>
              Configure scheduled database snapshots to encrypted cloud storage with multi-region redundancy.
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "16px" }}>
              <div style={{ padding: "16px", border: "1px solid var(--cafe-border)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontWeight: "700", marginBottom: "4px" }}>Daily Backup Schedule</div>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Runs every night at 02:00 AM UTC</div>
                <span className="badge badge-active" style={{ marginTop: "10px" }}>Active</span>
              </div>

              <div style={{ padding: "16px", border: "1px solid var(--cafe-border)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontWeight: "700", marginBottom: "4px" }}>Weekly Cold Storage Archive</div>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Runs Sundays at 04:00 AM UTC</div>
                <span className="badge badge-active" style={{ marginTop: "10px" }}>Active</span>
              </div>

              <div style={{ padding: "16px", border: "1px solid var(--cafe-border)", borderRadius: "var(--radius-md)" }}>
                <div style={{ fontWeight: "700", marginBottom: "4px" }}>Data Retention Policy</div>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Retain transaction logs for 365 days</div>
                <span className="badge badge-primary" style={{ marginTop: "10px" }}>Compliance Mode</span>
              </div>
            </div>
          </div>

          {/* Searchable Customer Records Explorer */}
          <div className="glass-card" style={{ padding: "24px" }}>
            <h3 style={{ fontSize: "1.1rem", marginBottom: "12px" }}>Search Customer Records by Phone / Café</h3>
            <div style={{ display: "flex", gap: "10px", maxWidth: "450px", marginBottom: "16px" }}>
              <input
                type="text"
                placeholder="Enter customer phone (e.g. 555-782)..."
                value={customerSearchPhone}
                onChange={(e) => setCustomerSearchPhone(e.target.value)}
                className="form-input"
              />
            </div>

            {/* List matching reservations / orders */}
            <div style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
              {(() => {
                const results = [];
                cafes.forEach(c => {
                  c.reservations?.forEach(r => {
                    if (!customerSearchPhone || r.phone.includes(customerSearchPhone) || r.customerName.toLowerCase().includes(customerSearchPhone.toLowerCase())) {
                      results.push({ ...r, cafeName: c.name, type: "Reservation" });
                    }
                  });
                });
                if (results.length === 0) return <p>No matching customer records found.</p>;
                return (
                  <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                    {results.slice(0, 5).map((res, i) => (
                      <div key={i} style={{ padding: "10px", background: "var(--cafe-card-alt)", borderRadius: "8px", display: "flex", justifyContent: "space-between" }}>
                        <div>
                          <strong>{res.customerName}</strong> ({res.phone}) • <span style={{ color: "var(--cafe-primary)" }}>{res.cafeName}</span>
                        </div>
                        <div>
                          {res.date} at {res.time} • Party of {res.partySize} • <span className="badge badge-active">{res.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREATE NEW CAFE ACCOUNT */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "780px", padding: "28px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <div>
                <h2 style={{ fontSize: "1.4rem" }}>Create New Café Franchise Account</h2>
                <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                  Registers café, provisions automated credentials, and sets up franchise operations.
                </p>
              </div>
              <button 
                onClick={() => setShowCreateModal(false)}
                style={{ fontSize: "1.2rem", color: "var(--cafe-text-muted)", cursor: "pointer" }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCafe} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {/* Section 1: Owner Information */}
              <div style={{ fontWeight: "700", color: "var(--cafe-primary)", borderBottom: "1px solid var(--cafe-border)", paddingBottom: "6px" }}>
                1. Owner & Primary Contact
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                <div className="form-group">
                  <label className="form-label">Owner Full Name <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Johnathan Miller"
                    value={newCafe.ownerName}
                    onChange={(e) => setNewCafe({ ...newCafe, ownerName: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Owner Mobile Number <span className="req">*</span></label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. +1 (555) 392-1094"
                    value={newCafe.mobile}
                    onChange={(e) => setNewCafe({ ...newCafe, mobile: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                <div className="form-group">
                  <label className="form-label">Owner Email Address <span className="req">*</span></label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. owner@artisanroast.com"
                    value={newCafe.email}
                    onChange={(e) => setNewCafe({ ...newCafe, email: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Café Shop Contact Number <span className="req">*</span></label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. +1 (555) 392-1000"
                    value={newCafe.contactNumber}
                    onChange={(e) => setNewCafe({ ...newCafe, contactNumber: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              {/* Section 2: Cafe Details */}
              <div style={{ fontWeight: "700", color: "var(--cafe-primary)", borderBottom: "1px solid var(--cafe-border)", paddingBottom: "6px", marginTop: "8px" }}>
                2. Café Shop Details & Location
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "14px" }}>
                <div className="form-group">
                  <label className="form-label">Café Shop Name <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Hearth & Crema Espresso Bar"
                    value={newCafe.shopName}
                    onChange={(e) => setNewCafe({ ...newCafe, shopName: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Café Category <span className="req">*</span></label>
                  <select
                    value={newCafe.category}
                    onChange={(e) => setNewCafe({ ...newCafe, category: e.target.value })}
                    className="form-select"
                  >
                    <option value="Fine Dining">Fine Dining</option>
                    <option value="Casual">Casual</option>
                    <option value="Fine Casual">Fine Casual</option>
                    <option value="Fast-Casual">Fast-Casual</option>
                    <option value="Cloud Kitchen">Cloud Kitchen</option>
                    <option value="Bakery & Bistro">Bakery & Bistro</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Street Address <span className="req">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 742 Evergreen Terrace, Suite 100"
                  value={newCafe.shopAddress}
                  onChange={(e) => setNewCafe({ ...newCafe, shopAddress: e.target.value })}
                  className="form-input"
                />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                <div className="form-group">
                  <label className="form-label">City <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Seattle"
                    value={newCafe.city}
                    onChange={(e) => setNewCafe({ ...newCafe, city: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">State / Region <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Washington"
                    value={newCafe.state}
                    onChange={(e) => setNewCafe({ ...newCafe, state: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Pincode / Zip <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 98101"
                    value={newCafe.pincode}
                    onChange={(e) => setNewCafe({ ...newCafe, pincode: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                <div className="form-group">
                  <label className="form-label">Total Seating Capacity</label>
                  <input
                    type="number"
                    min="1"
                    value={newCafe.seatingCapacity}
                    onChange={(e) => setNewCafe({ ...newCafe, seatingCapacity: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Operating Hours</label>
                  <input
                    type="text"
                    placeholder="e.g. 07:30 - 22:30"
                    value={newCafe.openHours}
                    onChange={(e) => setNewCafe({ ...newCafe, openHours: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">
                  Shop Description (250+ characters recommended)
                  <span style={{ marginLeft: "auto", fontSize: "0.75rem", color: newCafe.description.length >= 250 ? "#16A34A" : "var(--cafe-text-muted)" }}>
                    {newCafe.description.length} characters
                  </span>
                </label>
                <textarea
                  rows="3"
                  placeholder="Describe your culinary vision, coffee roast profile, kitchen specialties, and atmosphere..."
                  value={newCafe.description}
                  onChange={(e) => setNewCafe({ ...newCafe, description: e.target.value })}
                  className="form-textarea"
                />
              </div>

              {/* Section 3: Credentials Auto-Generation Preview */}
              <div style={{
                background: "var(--cafe-primary-light)",
                border: "1px dashed var(--cafe-primary)",
                padding: "14px",
                borderRadius: "var(--radius-md)"
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", color: "var(--cafe-primary)" }}>
                  <Key size={16} /> Automated Franchise Credentials Provisioning
                </div>
                <div style={{ fontSize: "0.8rem", color: "var(--cafe-text)", marginTop: "4px" }}>
                  Username format: <code>{generateUsername(newCafe.shopName, newCafe.ownerName)}</code> • Temporary secure password will be created and emailed to <strong>{newCafe.email || "owner email"}</strong>.
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px", marginTop: "12px" }}>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary"
                >
                  <Sparkles size={16} />
                  <span>Create Account & Provision Credentials</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW CAFE DETAILS & CREDENTIALS */}
      {selectedCafeForDetails && (
        <div className="modal-overlay" onClick={() => setSelectedCafeForDetails(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ padding: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ fontSize: "1.3rem" }}>{selectedCafeForDetails.name}</h2>
              <button onClick={() => setSelectedCafeForDetails(null)}>✕</button>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px", fontSize: "0.9rem" }}>
              <div>
                <strong>Owner:</strong> {selectedCafeForDetails.ownerName} ({selectedCafeForDetails.mobile})
              </div>
              <div>
                <strong>Email:</strong> {selectedCafeForDetails.email}
              </div>
              <div>
                <strong>Address:</strong> {selectedCafeForDetails.shopAddress}, {selectedCafeForDetails.city}, {selectedCafeForDetails.state} {selectedCafeForDetails.pincode}
              </div>
              <div>
                <strong>Admin Credentials:</strong>
                <div style={{ background: "var(--cafe-card-alt)", padding: "10px", borderRadius: "8px", marginTop: "4px" }}>
                  <div>Username: <code>{selectedCafeForDetails.credentials?.username}</code></div>
                  <div>Temp Password: <code>{selectedCafeForDetails.credentials?.tempPassword}</code></div>
                  <div>Permissions: <strong>{selectedCafeForDetails.credentials?.permissionLevel}</strong></div>
                </div>
              </div>
              <div>
                <strong>Bank Account:</strong> {selectedCafeForDetails.bankDetails?.bankName} ({selectedCafeForDetails.bankDetails?.accountNumber})
              </div>
            </div>

            <div style={{ marginTop: "20px", display: "flex", justifyContent: "flex-end" }}>
              <button onClick={() => setSelectedCafeForDetails(null)} className="btn-secondary">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
