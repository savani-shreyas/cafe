import React from "react";
import { 
  Coffee, Shield, Store, Moon, Sun, 
  QrCode, ShoppingBag, Calendar, LogOut, User, ExternalLink, ArrowRight
} from "lucide-react";

export default function Navbar({
  portalMode = "customer", // "customer", "superadmin", "cafeowner"
  cafes = [],
  activeCafeId,
  setActiveCafeId,
  theme,
  setTheme,
  cartCount = 0,
  onOpenCart,
  onOpenMyReservations,
  scannedTableInfo,
  onClearScannedTable,
  authSession,
  onNavigate,
  onLogout
}) {
  const activeCafe = cafes.find(c => c.id === activeCafeId) || cafes[0];

  return (
    <header style={{
      background: "var(--cafe-card)",
      borderBottom: "1px solid var(--cafe-border)",
      position: "sticky",
      top: 0,
      zIndex: 100,
      boxShadow: "var(--shadow-sm)"
    }}>
      {/* Table Scan Active Banner (Only when a customer scanned a table QR) */}
      {scannedTableInfo && portalMode === "customer" && (
        <div style={{
          background: "linear-gradient(90deg, #C86D27 0%, #D97706 100%)",
          color: "#FFFFFF",
          padding: "7px 20px",
          fontSize: "0.85rem",
          fontWeight: "600",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <QrCode size={16} />
            <span>
              Direct Table Scan Active: <strong>{scannedTableInfo.tableNumber || `Table #${scannedTableInfo.tableId}`}</strong> at <strong>{activeCafe?.name}</strong>
            </span>
          </div>
          <button 
            onClick={onClearScannedTable}
            style={{
              color: "#FFF",
              textDecoration: "underline",
              fontSize: "0.75rem",
              background: "transparent",
              border: "none",
              cursor: "pointer",
              fontWeight: "600"
            }}
          >
            Exit Table Scan Mode
          </button>
        </div>
      )}

      <div style={{
        maxWidth: "1400px",
        margin: "0 auto",
        padding: "12px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "14px"
      }}>
        {/* =========================================================
            BRAND LOGO
            ========================================================= */}
        <div 
          onClick={() => onNavigate("customer")}
          style={{ display: "flex", alignItems: "center", gap: "12px", cursor: "pointer" }}
        >
          <div style={{
            width: "42px",
            height: "42px",
            borderRadius: "12px",
            background: portalMode === "superadmin" 
              ? "linear-gradient(135deg, #B45309 0%, #1A120B 100%)"
              : "linear-gradient(135deg, var(--cafe-primary) 0%, #1A120B 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#FFF",
            boxShadow: "0 4px 12px var(--cafe-primary-glow)"
          }}>
            {portalMode === "superadmin" ? <Shield size={22} color="#F59E0B" /> : <Coffee size={22} />}
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span style={{
                fontFamily: "var(--font-heading)",
                fontSize: "1.35rem",
                fontWeight: "800",
                letterSpacing: "-0.5px",
                color: "var(--cafe-text)",
                lineHeight: 1.1
              }}>
                Aroma<span style={{ color: "var(--cafe-primary)" }}>Cloud</span>
              </span>

              {/* Portal Badges (Only in admin portals, never on customer website) */}
              {portalMode === "superadmin" && (
                <span style={{
                  fontSize: "0.7rem",
                  fontWeight: "800",
                  background: "#FEF3C7",
                  color: "#92400E",
                  padding: "2px 8px",
                  borderRadius: "999px",
                  border: "1px solid #FCD34D"
                }}>
                  SUPER ADMIN HQ
                </span>
              )}
              {portalMode === "cafeowner" && (
                <span style={{
                  fontSize: "0.7rem",
                  fontWeight: "800",
                  background: "var(--cafe-primary-light)",
                  color: "var(--cafe-primary)",
                  padding: "2px 8px",
                  borderRadius: "999px",
                  border: "1px solid var(--cafe-primary)"
                }}>
                  CAFÉ OPERATIONS
                </span>
              )}
            </div>
            <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>
              {portalMode === "superadmin"
                ? "Franchise Governance & Network Oversight"
                : portalMode === "cafeowner"
                ? `${activeCafe?.name || "Artisan Roastery"} Management`
                : "Artisan Roasters & Dining Network"}
            </div>
          </div>
        </div>

        {/* =========================================================
            MIDDLE SECTION: PORTAL-SPECIFIC CONTROLS
            ========================================================= */}
        {/* In Super Admin Portal: Navigation options */}
        {portalMode === "superadmin" && (
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <button
              onClick={() => onNavigate("cafeowner")}
              style={{
                background: "var(--cafe-card-alt)",
                border: "1px solid var(--cafe-border)",
                color: "var(--cafe-text)",
                padding: "6px 12px",
                borderRadius: "var(--radius-md)",
                fontSize: "0.82rem",
                fontWeight: "600",
                display: "flex",
                alignItems: "center",
                gap: "6px",
                cursor: "pointer"
              }}
            >
              <Store size={15} color="var(--cafe-primary)" />
              <span>Café Owner Panel</span>
            </button>
            <button
              onClick={() => onNavigate("customer")}
              style={{
                background: "transparent",
                border: "1px solid var(--cafe-border)",
                color: "var(--cafe-text-muted)",
                padding: "6px 12px",
                borderRadius: "var(--radius-md)",
                fontSize: "0.82rem",
                display: "flex",
                alignItems: "center",
                gap: "5px",
                cursor: "pointer"
              }}
            >
              <span>View Customer Website</span>
              <ExternalLink size={13} />
            </button>
          </div>
        )}

        {/* In Café Owner Portal: Active Cafe Selector & Customer Link */}
        {portalMode === "cafeowner" && (
          <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", fontWeight: "600" }}>
                Active Location:
              </span>
              <select
                value={activeCafeId}
                onChange={(e) => setActiveCafeId(e.target.value)}
                className="form-select"
                style={{ padding: "6px 12px", fontSize: "0.85rem", minWidth: "180px" }}
              >
                {cafes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              onClick={() => onNavigate("customer")}
              style={{
                background: "transparent",
                border: "1px solid var(--cafe-border)",
                color: "var(--cafe-text-muted)",
                padding: "6px 12px",
                borderRadius: "var(--radius-md)",
                fontSize: "0.82rem",
                display: "flex",
                alignItems: "center",
                gap: "5px",
                cursor: "pointer"
              }}
            >
              <span>View Customer Website</span>
              <ExternalLink size={13} />
            </button>
          </div>
        )}

        {/* =========================================================
            RIGHT TOOLBAR
            ========================================================= */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          {/* Customer-only tools: My Bookings & Cart */}
          {portalMode === "customer" && (
            <>
              <button
                onClick={onOpenMyReservations}
                title="View your table reservations"
                style={{
                  background: "var(--cafe-card-alt)",
                  color: "var(--cafe-text)",
                  border: "1px solid var(--cafe-border)",
                  padding: "8px 14px",
                  borderRadius: "var(--radius-md)",
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "0.85rem",
                  fontWeight: "600",
                  cursor: "pointer"
                }}
              >
                <Calendar size={15} color="var(--cafe-primary)" />
                <span>My Bookings</span>
              </button>

              <button
                onClick={onOpenCart}
                style={{
                  position: "relative",
                  background: "var(--cafe-primary)",
                  color: "#FFF",
                  border: "none",
                  padding: "8px 16px",
                  borderRadius: "var(--radius-md)",
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "0.85rem",
                  fontWeight: "600",
                  cursor: "pointer",
                  boxShadow: "0 2px 8px var(--cafe-primary-glow)"
                }}
              >
                <ShoppingBag size={16} />
                <span>Cart</span>
                {cartCount > 0 && (
                  <span style={{
                    background: "#FFF",
                    color: "var(--cafe-primary)",
                    borderRadius: "999px",
                    padding: "1px 6px",
                    fontSize: "0.75rem",
                    fontWeight: "800",
                    marginLeft: "2px"
                  }}>
                    {cartCount}
                  </span>
                )}
              </button>
            </>
          )}

          {/* Theme Toggle (Dark / Light) */}
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            title="Toggle Dark / Light Theme"
            style={{
              padding: "8px",
              borderRadius: "var(--radius-md)",
              border: "1px solid var(--cafe-border)",
              color: "var(--cafe-text)",
              background: "var(--cafe-card-alt)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          {/* Admin Logout button (Only visible when in admin portal) */}
          {portalMode !== "customer" && authSession && (
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{
                background: portalMode === "superadmin" ? "#FEF3C7" : "var(--cafe-primary-light)",
                color: portalMode === "superadmin" ? "#92400E" : "var(--cafe-primary)",
                padding: "6px 12px",
                borderRadius: "var(--radius-md)",
                fontSize: "0.8rem",
                fontWeight: "700",
                display: "flex",
                alignItems: "center",
                gap: "6px"
              }}>
                <User size={14} />
                <span>{portalMode === "superadmin" ? "Super Admin" : authSession.name || "Owner"}</span>
              </div>

              <button
                onClick={onLogout}
                title="Log out of session"
                style={{
                  background: "var(--cafe-card-alt)",
                  color: "#DC2626",
                  border: "1px solid #FECACA",
                  padding: "6px 12px",
                  borderRadius: "var(--radius-md)",
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "0.8rem",
                  fontWeight: "600",
                  cursor: "pointer"
                }}
              >
                <LogOut size={14} />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
