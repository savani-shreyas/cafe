import React, { useState, useEffect } from "react";
import { 
  LayoutDashboard, Table as TableIcon, UtensilsCrossed, Calendar, 
  ChefHat, Users, QrCode, AlertTriangle, CheckCircle, Clock, 
  Plus, Edit, Trash2, Printer, Download, Sparkles, Search,
  Bell, Check, X, ShieldAlert, ArrowRight, ArrowLeft, RefreshCw, Eye
} from "lucide-react";
import { exportToCsv, playChime } from "../../data/mockData";
import { generateQrDataUrl, getTableScanUrl } from "../../utils/qrHelper";

export default function CafeOwnerPanel({
  cafe,
  onUpdateCafe,
  onSimulateTableScan
}) {
  const [activeTab, setActiveTab] = useState("dashboard"); 
  // "dashboard", "tables", "menu", "reservations", "kds", "customers", "qr_batch"

  const [kdsFilter, setKdsFilter] = useState("all"); // "all", "received", "preparing", "ready"
  const [reservationFilter, setReservationFilter] = useState("all");
  const [reservationView, setReservationView] = useState("list"); // "list", "calendar"
  const [calendarMode, setCalendarMode] = useState("day"); // "day", "week", "month"

  // Modals
  const [showAddTableModal, setShowAddTableModal] = useState(false);
  const [showBulkTableModal, setShowBulkTableModal] = useState(false);
  const [selectedTableForQr, setSelectedTableForQr] = useState(null);
  const [qrModalDataUrl, setQrModalDataUrl] = useState("");
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [showAddCategoryModal, setShowAddCategoryModal] = useState(false);
  const [showAddOfferModal, setShowAddOfferModal] = useState(false);
  const [selectedReservationForAction, setSelectedReservationForAction] = useState(null);
  const [showAssignTableModal, setShowAssignTableModal] = useState(false);

  // New Table Form State
  const [tableForm, setTableForm] = useState({
    number: "",
    capacity: 4,
    location: "Near Window",
    features: "High chair available",
    status: "available",
    notes: "",
    setupFee: 20
  });

  // Bulk Table Form State
  const [bulkCount, setBulkCount] = useState(4);
  const [bulkCapacity, setBulkCapacity] = useState(4);
  const [bulkLocation, setBulkLocation] = useState("Center");

  // New Item Form State
  const [itemForm, setItemForm] = useState({
    name: "",
    categoryId: cafe.menuCategories?.[0]?.id || "",
    description: "",
    price: 12.00,
    discountedPrice: "",
    status: "in_stock",
    stockQty: 30,
    prepTimeMins: 15,
    spiceLevel: "mild",
    dietary: "veg",
    calories: 500,
    protein: "20g",
    carbs: "50g",
    fat: "18g",
    allergens: "Dairy, Gluten",
    image: "/images/gourmet_cafe_dishes.jpg",
    addons: [
      { name: "Extra Cheese", price: 1.50, type: "multiple" },
      { name: "House Truffle Sauce", price: 2.00, type: "multiple" }
    ]
  });

  // Calculate Dashboard KPIs
  const todayReservations = cafe.reservations?.filter(r => r.date === "2026-10-19") || [];
  const checkedInCount = todayReservations.filter(r => r.status === "arrived").length;
  const pendingOrders = cafe.orders?.filter(o => o.status === "received" || o.status === "preparing") || [];
  const todayRevenue = cafe.orders?.reduce((acc, o) => acc + (o.total || 0), 0) || 0;
  const availableTablesCount = cafe.tables?.filter(t => t.status === "available").length || 0;
  const occupiedTablesCount = cafe.tables?.filter(t => t.status === "occupied").length || 0;

  // Alerts
  const lowStockItems = cafe.menuItems?.filter(i => i.stockQty <= 15) || [];
  const pendingReservations = cafe.reservations?.filter(r => r.status === "pending") || [];

  // Generate QR for a selected table
  const handleOpenQrModal = async (tbl) => {
    setSelectedTableForQr(tbl);
    const url = getTableScanUrl(cafe.id, tbl.id);
    const dataUrl = await generateQrDataUrl(url);
    setQrModalDataUrl(dataUrl);
  };

  // Change Table Status
  const handleUpdateTableStatus = (tableId, newStatus) => {
    const updatedTables = cafe.tables.map(t => {
      if (t.id === tableId) {
        return { ...t, status: newStatus, isSos: false };
      }
      return t;
    });
    onUpdateCafe({ ...cafe, tables: updatedTables });
    playChime("success");
  };

  // Trigger SOS Alert for Table
  const handleToggleSos = (tableId) => {
    const updatedTables = cafe.tables.map(t => {
      if (t.id === tableId) {
        const nextSos = !t.isSos;
        return { ...t, isSos: nextSos };
      }
      return t;
    });
    onUpdateCafe({ ...cafe, tables: updatedTables });
    playChime("alert");
  };

  // Handle Add Single Table
  const handleAddTableSubmit = (e) => {
    e.preventDefault();
    const nextNum = (cafe.tables?.length || 0) + 1;
    const newId = `T00${nextNum}`;
    const newTbl = {
      id: newId,
      number: tableForm.number || `Table ${nextNum} (${tableForm.location})`,
      capacity: Number(tableForm.capacity),
      location: tableForm.location,
      features: tableForm.features.split(",").map(s => s.trim()),
      status: tableForm.status,
      notes: tableForm.notes,
      setupFee: Number(tableForm.setupFee) || 20,
      scanCount: 0
    };
    onUpdateCafe({ ...cafe, tables: [...(cafe.tables || []), newTbl] });
    setShowAddTableModal(false);
    playChime("success");
  };

  // Handle Bulk Add Tables
  const handleBulkAddSubmit = (e) => {
    e.preventDefault();
    const currentCount = cafe.tables?.length || 0;
    const newTables = [];
    for (let i = 1; i <= Number(bulkCount); i++) {
      const idx = currentCount + i;
      newTables.push({
        id: `T${idx < 10 ? "00" + idx : "0" + idx}`,
        number: `Table ${idx} (${bulkLocation})`,
        capacity: Number(bulkCapacity),
        location: bulkLocation,
        features: ["Standard setup"],
        status: "available",
        setupFee: Number(bulkCapacity) === 2 ? 15 : Number(bulkCapacity) === 4 ? 20 : 30,
        scanCount: 0
      });
    }
    onUpdateCafe({ ...cafe, tables: [...(cafe.tables || []), ...newTables] });
    setShowBulkTableModal(false);
    playChime("success");
  };

  // Handle Add / Edit Menu Item Submit
  const handleItemSubmit = (e) => {
    e.preventDefault();
    const itemData = {
      id: editingItem ? editingItem.id : `item-${Date.now().toString().slice(-5)}`,
      name: itemForm.name,
      categoryId: itemForm.categoryId,
      description: itemForm.description,
      price: Number(itemForm.price),
      discountedPrice: itemForm.discountedPrice ? Number(itemForm.discountedPrice) : undefined,
      status: itemForm.status,
      stockQty: Number(itemForm.stockQty),
      prepTimeMins: Number(itemForm.prepTimeMins),
      spiceLevel: itemForm.spiceLevel,
      dietary: itemForm.dietary,
      calories: Number(itemForm.calories),
      nutrition: { protein: itemForm.protein, carbs: itemForm.carbs, fat: itemForm.fat },
      allergens: itemForm.allergens.split(",").map(a => a.trim()),
      image: itemForm.image,
      popular: editingItem?.popular || false,
      customizations: [
        {
          id: "opt-addons",
          name: "Additions & Extras",
          required: false,
          type: "multiple",
          options: itemForm.addons
        }
      ]
    };

    let updatedItems;
    if (editingItem) {
      updatedItems = cafe.menuItems.map(i => i.id === editingItem.id ? itemData : i);
    } else {
      updatedItems = [...(cafe.menuItems || []), itemData];
    }

    onUpdateCafe({ ...cafe, menuItems: updatedItems });
    setShowAddItemModal(false);
    setEditingItem(null);
    playChime("success");
  };

  // Reservation Status Updates
  const handleUpdateReservationStatus = (resId, nextStatus) => {
    const updated = cafe.reservations.map(r => {
      if (r.id === resId) {
        return { ...r, status: nextStatus };
      }
      return r;
    });

    // If marked "arrived", auto mark corresponding table as occupied!
    let updatedTables = cafe.tables;
    if (nextStatus === "arrived") {
      const targetRes = cafe.reservations.find(r => r.id === resId);
      if (targetRes && targetRes.tableId) {
        updatedTables = cafe.tables.map(t => {
          if (t.id === targetRes.tableId) return { ...t, status: "occupied" };
          return t;
        });
      }
    }

    onUpdateCafe({ ...cafe, reservations: updated, tables: updatedTables });
    playChime("success");
  };

  // KDS Stage Transitions: received -> preparing -> ready -> delivered
  const handleProgressOrderStage = (orderId) => {
    const order = cafe.orders.find(o => o.id === orderId);
    if (!order) return;

    let nextStage = "preparing";
    if (order.status === "received") nextStage = "preparing";
    else if (order.status === "preparing") {
      nextStage = "ready";
      // Simulate SMS alert when ready!
      playChime("alert");
      alert(`🔔 Order Ready Notification!\n\nSMS dispatched to ${order.customerName} (${order.phone}):\n"Your order #${order.id} is freshly prepared and ready at ${cafe.name}!"`);
    } else if (order.status === "ready") nextStage = "delivered";

    const updatedOrders = cafe.orders.map(o => {
      if (o.id === orderId) {
        return { ...o, status: nextStage };
      }
      return o;
    });

    onUpdateCafe({ ...cafe, orders: updatedOrders });
    playChime("success");
  };

  // Check off individual item inside order
  const handleToggleOrderItemPrepared = (orderId, itemIndex) => {
    const updatedOrders = cafe.orders.map(o => {
      if (o.id === orderId) {
        const updatedItems = [...o.items];
        updatedItems[itemIndex] = {
          ...updatedItems[itemIndex],
          prepared: !updatedItems[itemIndex].prepared
        };
        return { ...o, items: updatedItems };
      }
      return o;
    });
    onUpdateCafe({ ...cafe, orders: updatedOrders });
  };

  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "20px 20px" }}>
      {/* Cafe Header & Sub-Bar */}
      <div style={{
        background: "var(--cafe-card)",
        border: "1px solid var(--cafe-border)",
        borderRadius: "var(--radius-xl)",
        padding: "20px 24px",
        marginBottom: "24px",
        boxShadow: "var(--shadow-sm)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: "wrap",
        gap: "16px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <img 
            src={cafe.image} 
            alt={cafe.name}
            style={{ width: "64px", height: "64px", borderRadius: "14px", objectFit: "cover", boxShadow: "var(--shadow-sm)" }}
          />
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <h1 style={{ fontSize: "1.6rem" }}>{cafe.name}</h1>
              <span className="badge badge-primary">{cafe.category}</span>
              <span className="badge badge-active">Live Operations</span>
            </div>
            <div style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", marginTop: "3px" }}>
              Owner: <strong>{cafe.ownerName}</strong> ({cafe.mobile}) �?� {cafe.shopAddress}, {cafe.city} �?� Open: <strong>{cafe.openHours}</strong>
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <button
            onClick={() => {
              const firstTable = cafe.tables?.[0]?.id || "T001";
              onSimulateTableScan(cafe.id, firstTable);
            }}
            className="btn-primary"
            style={{ fontSize: "0.85rem", padding: "8px 14px" }}
          >
            <QrCode size={16} />
            <span>Customer Scan Test</span>
          </button>
        </div>
      </div>

      {/* Dynamic Alerts Banner */}
      {(lowStockItems.length > 0 || pendingReservations.length > 0) && (
        <div style={{
          background: "#FEF3C7",
          border: "1px solid #FDE68A",
          borderRadius: "var(--radius-lg)",
          padding: "12px 18px",
          marginBottom: "20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "12px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <AlertTriangle size={20} color="#D97706" />
            <div style={{ fontSize: "0.88rem", color: "#92400E" }}>
              <strong>Operational Alerts:</strong>{" "}
              {lowStockItems.length > 0 && (
                <span>⚠️ {lowStockItems.length} menu items running low on stock ({lowStockItems.map(i => i.name).slice(0, 2).join(", ")}). </span>
              )}
              {pendingReservations.length > 0 && (
                <span>📅 {pendingReservations.length} guest table reservation(s) awaiting your approval.</span>
              )}
            </div>
          </div>
          <button 
            onClick={() => setActiveTab(pendingReservations.length > 0 ? "reservations" : "menu")}
            style={{ fontSize: "0.82rem", fontWeight: "700", color: "#92400E", textDecoration: "underline" }}
          >
            Review Now →
          </button>
        </div>
      )}

      {/* Sub Navigation Tabs */}
      <div style={{
        display: "flex",
        background: "var(--cafe-card-alt)",
        padding: "6px",
        borderRadius: "var(--radius-lg)",
        border: "1px solid var(--cafe-border)",
        gap: "4px",
        overflowX: "auto",
        marginBottom: "24px"
      }}>
        {[
          { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
          { id: "tables", label: `Tables (${cafe.tables?.length || 0})`, icon: TableIcon },
          { id: "menu", label: `Menu (${cafe.menuItems?.length || 0})`, icon: UtensilsCrossed },
          { id: "reservations", label: `Reservations (${cafe.reservations?.length || 0})`, icon: Calendar },
          { id: "kds", label: `Kitchen Display (${cafe.orders?.length || 0})`, icon: ChefHat },
          { id: "customers", label: "Customer CRM", icon: Users },
          { id: "qr_batch", label: "QR Generator & Backups", icon: QrCode }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: "10px 16px",
                borderRadius: "var(--radius-md)",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                fontSize: "0.88rem",
                fontWeight: "700",
                whiteSpace: "nowrap",
                background: isActive ? "var(--cafe-primary)" : "transparent",
                color: isActive ? "#FFFFFF" : "var(--cafe-text-muted)",
                boxShadow: isActive ? "0 2px 8px var(--cafe-primary-glow)" : "none"
              }}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================
          1. DASHBOARD OVERVIEW TAB
          ======================================================== */}
      {activeTab === "dashboard" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {/* Quick Metrics */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
            gap: "16px"
          }}>
            <div className="glass-card" style={{ padding: "18px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
                <span>Today's Reservations</span>
                <Calendar size={18} color="var(--cafe-primary)" />
              </div>
              <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
                {todayReservations.length}
              </div>
              <div style={{ fontSize: "0.8rem", color: "#16A34A", marginTop: "4px" }}>
                {checkedInCount} Guests Checked-In
              </div>
            </div>

            <div className="glass-card" style={{ padding: "18px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
                <span>Pending Orders</span>
                <Clock size={18} color="#F59E0B" />
              </div>
              <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
                {pendingOrders.length}
              </div>
              <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
                Active in Kitchen (KDS)
              </div>
            </div>

            <div className="glass-card" style={{ padding: "18px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
                <span>Today's Gross Sales</span>
                <span style={{ fontWeight: "700", color: "#16A34A" }}>₹</span>
              </div>
              <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px", color: "var(--cafe-primary)" }}>
                ₹{todayRevenue.toFixed(2)}
              </div>
              <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
                This Month: ₹{cafe.stats?.monthlyRevenue?.toLocaleString()}
              </div>
            </div>

            <div className="glass-card" style={{ padding: "18px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: "var(--cafe-text-muted)", fontSize: "0.85rem", fontWeight: "600" }}>
                <span>Floor Availability</span>
                <TableIcon size={18} color="#16A34A" />
              </div>
              <div style={{ fontSize: "1.8rem", fontWeight: "800", marginTop: "8px" }}>
                {availableTablesCount} / {cafe.tables?.length || 0}
              </div>
              <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
                {occupiedTablesCount} Occupied �?� {cafe.tables?.length - availableTablesCount - occupiedTablesCount} Reserved
              </div>
            </div>
          </div>

          {/* Real-Time Live Tables Mini-Grid & Recent Orders */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))", gap: "20px" }}>
            {/* Real-time Tables Status */}
            <div className="glass-card" style={{ padding: "20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                <h3 style={{ fontSize: "1.1rem" }}>Real-Time Table Floor Overview</h3>
                <button onClick={() => setActiveTab("tables")} style={{ fontSize: "0.8rem", color: "var(--cafe-primary)", fontWeight: "700" }}>
                  Manage Floor →
                </button>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))", gap: "10px" }}>
                {cafe.tables?.map(t => {
                  const statusColors = {
                    available: { bg: "#DCFCE7", text: "#16A34A", border: "#86EFAC" },
                    occupied: { bg: "#FEE2E2", text: "#DC2626", border: "#FCA5A5" },
                    reserved: { bg: "#FEF3C7", text: "#D97706", border: "#FDE68A" },
                    maintenance: { bg: "#F3F4F6", text: "#6B7280", border: "#E5E7EB" }
                  };
                  const color = statusColors[t.status] || statusColors.available;
                  return (
                    <div
                      key={t.id}
                      className={t.isSos ? "sos-alert" : ""}
                      onClick={() => handleOpenQrModal(t)}
                      style={{
                        background: color.bg,
                        border: `1.5px solid ${color.border}`,
                        color: color.text,
                        borderRadius: "12px",
                        padding: "10px 8px",
                        textAlign: "center",
                        cursor: "pointer",
                        transition: "transform 0.15s"
                      }}
                    >
                      <div style={{ fontSize: "0.75rem", fontWeight: "700" }}>{t.id}</div>
                      <div style={{ fontSize: "0.85rem", fontWeight: "800" }}>{t.capacity}P</div>
                      <div style={{ fontSize: "0.7rem", textTransform: "capitalize", marginTop: "2px" }}>
                        {t.isSos ? "🚨 SOS" : t.status}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Recent Orders Stream */}
            <div className="glass-card" style={{ padding: "20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                <h3 style={{ fontSize: "1.1rem" }}>Incoming Orders & Kitchen Stream</h3>
                <button onClick={() => setActiveTab("kds")} style={{ fontSize: "0.8rem", color: "var(--cafe-primary)", fontWeight: "700" }}>
                  Open KDS Display →
                </button>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {cafe.orders?.slice(0, 4).map(o => (
                  <div key={o.id} style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 12px",
                    background: "var(--cafe-card-alt)",
                    borderRadius: "8px",
                    border: "1px solid var(--cafe-border-light)"
                  }}>
                    <div>
                      <div style={{ fontWeight: "700", fontSize: "0.88rem" }}>
                        #{o.id} �?� {o.tableNumber || "Direct Pickup"}
                      </div>
                      <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>
                        {o.customerName} �?� {o.items.map(i => `${i.qty}x ${i.name}`).join(", ")}
                      </div>
                    </div>

                    <div style={{ textAlign: "right" }}>
                      <span className={`badge ${o.status === "ready" ? "badge-active" : o.status === "preparing" ? "badge-primary" : "badge-inactive"}`}>
                        {o.status}
                      </span>
                      <div style={{ fontSize: "0.85rem", fontWeight: "700", color: "var(--cafe-primary)", marginTop: "2px" }}>
                        ₹{o.total?.toFixed(2)}
                      </div>
                    </div>
                  </div>
                ))}

                {(!cafe.orders || cafe.orders.length === 0) && (
                  <p style={{ color: "var(--cafe-text-muted)", fontSize: "0.85rem" }}>No orders received yet today.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          2. TABLE MANAGEMENT TAB
          ======================================================== */}
      {activeTab === "tables" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {/* Controls Bar */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2 style={{ fontSize: "1.3rem" }}>Floor Plan & Table Management</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                Configure seating capacities, generate unique scannable QR codes, and trigger table assistance alerts.
              </p>
            </div>

            <div style={{ display: "flex", gap: "10px" }}>
              <button onClick={() => setShowAddTableModal(true)} className="btn-primary" style={{ fontSize: "0.85rem" }}>
                <Plus size={16} /> Add Single Table
              </button>
              <button onClick={() => setShowBulkTableModal(true)} className="btn-secondary" style={{ fontSize: "0.85rem" }}>
                <Plus size={16} /> Bulk Add Tables
              </button>
            </div>
          </div>

          {/* Tables Grid */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(310px, 1fr))",
            gap: "18px"
          }}>
            {cafe.tables?.map((table) => {
              const statusColors = {
                available: { bg: "#DCFCE7", text: "#16A34A", label: "Available" },
                occupied: { bg: "#FEE2E2", text: "#DC2626", label: "Occupied" },
                reserved: { bg: "#FEF3C7", text: "#D97706", label: "Reserved" },
                maintenance: { bg: "#F3F4F6", text: "#6B7280", label: "Maintenance" }
              };
              const sc = statusColors[table.status] || statusColors.available;

              return (
                <div 
                  key={table.id} 
                  className={`glass-card ${table.isSos ? "sos-alert" : ""}`}
                  style={{
                    padding: "18px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between"
                  }}
                >
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <span style={{
                            background: "var(--cafe-primary-light)",
                            color: "var(--cafe-primary)",
                            fontWeight: "800",
                            fontSize: "0.8rem",
                            padding: "2px 8px",
                            borderRadius: "6px"
                          }}>
                            {table.id}
                          </span>
                          <span style={{ fontWeight: "700", fontSize: "1.05rem" }}>{table.number}</span>
                        </div>
                        <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)", marginTop: "3px" }}>
                          Location: <strong>{table.location}</strong> �?� Capacity: <strong>{table.capacity} Persons</strong>
                        </div>
                      </div>

                      <span style={{
                        background: sc.bg,
                        color: sc.text,
                        fontSize: "0.75rem",
                        fontWeight: "800",
                        padding: "3px 8px",
                        borderRadius: "999px"
                      }}>
                        {table.isSos ? "🚨 SOS ALERT" : sc.label}
                      </span>
                    </div>

                    {/* Features Tags */}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", margin: "10px 0" }}>
                      {table.features?.map((f, i) => (
                        <span key={i} style={{ fontSize: "0.72rem", background: "var(--cafe-card-alt)", border: "1px solid var(--cafe-border-light)", padding: "2px 6px", borderRadius: "4px" }}>
                          ✓ {f}
                        </span>
                      ))}
                    </div>

                    <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>
                      Setup Fee: <strong>₹{table.setupFee || 20}</strong> �?� QR Scans: <strong>{table.scanCount || 0}</strong>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div style={{
                    marginTop: "16px",
                    paddingTop: "12px",
                    borderTop: "1px solid var(--cafe-border-light)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: "6px",
                    flexWrap: "wrap"
                  }}>
                    {/* Status Changer */}
                    <select
                      value={table.status}
                      onChange={(e) => handleUpdateTableStatus(table.id, e.target.value)}
                      className="form-select"
                      style={{ padding: "4px 8px", fontSize: "0.8rem", width: "auto" }}
                    >
                      <option value="available">Mark Available</option>
                      <option value="occupied">Mark Occupied</option>
                      <option value="reserved">Mark Reserved</option>
                      <option value="maintenance">Mark Maintenance</option>
                    </select>

                    <div style={{ display: "flex", gap: "6px" }}>
                      {/* View & Download QR */}
                      <button
                        onClick={() => handleOpenQrModal(table)}
                        title="View & Download Table QR Code"
                        style={{
                          background: "var(--cafe-card-alt)",
                          border: "1px solid var(--cafe-border)",
                          padding: "6px 10px",
                          borderRadius: "6px",
                          color: "var(--cafe-primary)",
                          fontSize: "0.78rem",
                          display: "flex",
                          alignItems: "center",
                          gap: "4px"
                        }}
                      >
                        <QrCode size={14} /> QR
                      </button>

                      {/* Trigger Emergency / SOS */}
                      <button
                        onClick={() => handleToggleSos(table.id)}
                        title="Toggle Emergency / Server SOS Alert"
                        style={{
                          background: table.isSos ? "#DC2626" : "#FEE2E2",
                          color: table.isSos ? "#FFF" : "#DC2626",
                          border: "1px solid #FECACA",
                          padding: "6px 10px",
                          borderRadius: "6px",
                          fontSize: "0.78rem"
                        }}
                      >
                        {table.isSos ? "Clear SOS" : "SOS"}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          3. MENU MANAGEMENT TAB
          ======================================================== */}
      {activeTab === "menu" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2 style={{ fontSize: "1.3rem" }}>Menu & Culinary Inventory</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                Manage categories, food items, allergen tags, spice levels, stock counts, and add-on customizations.
              </p>
            </div>

            <div style={{ display: "flex", gap: "10px" }}>
              <button 
                onClick={() => {
                  setEditingItem(null);
                  setItemForm({
                    name: "",
                    categoryId: cafe.menuCategories?.[0]?.id || "",
                    description: "",
                    price: 12.00,
                    discountedPrice: "",
                    status: "in_stock",
                    stockQty: 30,
                    prepTimeMins: 15,
                    spiceLevel: "mild",
                    dietary: "veg",
                    calories: 500,
                    protein: "20g",
                    carbs: "50g",
                    fat: "18g",
                    allergens: "Dairy, Gluten",
                    image: "/images/gourmet_cafe_dishes.jpg",
                    addons: [{ name: "Extra Sauce", price: 1.00, type: "multiple" }]
                  });
                  setShowAddItemModal(true);
                }} 
                className="btn-primary" 
                style={{ fontSize: "0.85rem" }}
              >
                <Plus size={16} /> Add Food Item
              </button>
            </div>
          </div>

          {/* Menu Categories Pills */}
          <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "6px" }}>
            {cafe.menuCategories?.map(cat => (
              <span key={cat.id} style={{
                background: "var(--cafe-card-alt)",
                border: "1px solid var(--cafe-border)",
                padding: "6px 14px",
                borderRadius: "var(--radius-full)",
                fontSize: "0.85rem",
                fontWeight: "700",
                display: "inline-flex",
                alignItems: "center",
                gap: "6px"
              }}>
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </span>
            ))}
          </div>

          {/* Menu Items Table / Cards */}
          <div className="glass-card" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.9rem" }}>
              <thead>
                <tr style={{ background: "var(--cafe-card-alt)", borderBottom: "1px solid var(--cafe-border)", color: "var(--cafe-text-muted)" }}>
                  <th style={{ padding: "14px 16px" }}>Food Item</th>
                  <th style={{ padding: "14px 16px" }}>Category</th>
                  <th style={{ padding: "14px 16px" }}>Dietary & Allergens</th>
                  <th style={{ padding: "14px 16px" }}>Price</th>
                  <th style={{ padding: "14px 16px" }}>Stock & Prep Time</th>
                  <th style={{ padding: "14px 16px", textAlign: "right" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {cafe.menuItems?.map(item => (
                  <tr key={item.id} style={{ borderBottom: "1px solid var(--cafe-border-light)" }}>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          style={{ width: "48px", height: "48px", borderRadius: "10px", objectFit: "cover" }}
                        />
                        <div>
                          <div style={{ fontWeight: "700", color: "var(--cafe-text)" }}>{item.name}</div>
                          <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)", maxWidth: "320px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                            {item.description}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px", fontWeight: "600" }}>
                      {cafe.menuCategories?.find(c => c.id === item.categoryId)?.name || "General"}
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <span className={`badge ${item.dietary === "veg" ? "badge-veg" : item.dietary === "vegan" ? "badge-vegan" : "badge-nonveg"}`}>
                          {item.dietary}
                        </span>
                        <span style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                          🌶️ {item.spiceLevel}
                        </span>
                      </div>
                      <div style={{ fontSize: "0.75rem", color: "#DC2626", marginTop: "3px" }}>
                        Allergens: {item.allergens?.join(", ") || "None"}
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "700", color: "var(--cafe-primary)" }}>
                        ₹{item.price?.toFixed(2)}
                      </div>
                      {item.discountedPrice && (
                        <div style={{ fontSize: "0.75rem", textDecoration: "line-through", color: "var(--cafe-text-muted)" }}>
                          ₹{item.discountedPrice?.toFixed(2)}
                        </div>
                      )}
                    </td>

                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontWeight: "600", color: item.stockQty <= 15 ? "#DC2626" : "var(--cafe-text)" }}>
                        {item.stockQty} in stock
                      </div>
                      <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                        ⏱️ ~{item.prepTimeMins} mins
                      </div>
                    </td>

                    <td style={{ padding: "14px 16px", textAlign: "right" }}>
                      <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px" }}>
                        <button
                          onClick={() => {
                            setEditingItem(item);
                            setItemForm({
                              name: item.name,
                              categoryId: item.categoryId,
                              description: item.description,
                              price: item.price,
                              discountedPrice: item.discountedPrice || "",
                              status: item.status,
                              stockQty: item.stockQty,
                              prepTimeMins: item.prepTimeMins,
                              spiceLevel: item.spiceLevel,
                              dietary: item.dietary,
                              calories: item.calories,
                              protein: item.nutrition?.protein || "20g",
                              carbs: item.nutrition?.carbs || "40g",
                              fat: item.nutrition?.fat || "15g",
                              allergens: item.allergens?.join(", ") || "",
                              image: item.image,
                              addons: item.customizations?.[0]?.options || []
                            });
                            setShowAddItemModal(true);
                          }}
                          style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid var(--cafe-border)", background: "var(--cafe-card-alt)", color: "var(--cafe-primary)" }}
                        >
                          <Edit size={14} />
                        </button>

                        <button
                          onClick={() => {
                            if (window.confirm(`Delete ${item.name}?`)) {
                              const updated = cafe.menuItems.filter(i => i.id !== item.id);
                              onUpdateCafe({ ...cafe, menuItems: updated });
                            }
                          }}
                          style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid #FECACA", background: "#FEF2F2", color: "#DC2626" }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================
          4. RESERVATIONS MANAGEMENT TAB
          ======================================================== */}
      {activeTab === "reservations" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {/* Header Controls */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2 style={{ fontSize: "1.3rem" }}>Table Bookings & Guest Arrivals</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                Calendar & list views, instant table assignments, check-in tracking, and special seating requests.
              </p>
            </div>

            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              {/* Calendar vs List Mode */}
              <div style={{ display: "flex", background: "var(--cafe-card-alt)", border: "1px solid var(--cafe-border)", borderRadius: "8px", padding: "2px" }}>
                <button
                  onClick={() => setReservationView("list")}
                  style={{
                    padding: "6px 12px",
                    borderRadius: "6px",
                    fontSize: "0.8rem",
                    background: reservationView === "list" ? "var(--cafe-espresso)" : "transparent",
                    color: reservationView === "list" ? "#FFF" : "var(--cafe-text-muted)"
                  }}
                >
                  List View
                </button>
                <button
                  onClick={() => setReservationView("calendar")}
                  style={{
                    padding: "6px 12px",
                    borderRadius: "6px",
                    fontSize: "0.8rem",
                    background: reservationView === "calendar" ? "var(--cafe-espresso)" : "transparent",
                    color: reservationView === "calendar" ? "#FFF" : "var(--cafe-text-muted)"
                  }}
                >
                  Calendar View
                </button>
              </div>

              {/* Status Filter */}
              <select
                value={reservationFilter}
                onChange={(e) => setReservationFilter(e.target.value)}
                className="form-select"
                style={{ width: "auto", fontSize: "0.85rem" }}
              >
                <option value="all">All Bookings</option>
                <option value="pending">Pending Approval</option>
                <option value="confirmed">Confirmed</option>
                <option value="arrived">Checked-In (Arrived)</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* VIEW: LIST */}
          {reservationView === "list" && (
            <div className="glass-card" style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.9rem" }}>
                <thead>
                  <tr style={{ background: "var(--cafe-card-alt)", borderBottom: "1px solid var(--cafe-border)", color: "var(--cafe-text-muted)" }}>
                    <th style={{ padding: "14px 16px" }}>Reservation ID & Guest</th>
                    <th style={{ padding: "14px 16px" }}>Date & Time</th>
                    <th style={{ padding: "14px 16px" }}>Party & Table</th>
                    <th style={{ padding: "14px 16px" }}>Customization & Occasion</th>
                    <th style={{ padding: "14px 16px" }}>Status</th>
                    <th style={{ padding: "14px 16px", textAlign: "right" }}>Operations</th>
                  </tr>
                </thead>
                <tbody>
                  {cafe.reservations?.filter(r => reservationFilter === "all" ? true : r.status === reservationFilter).map(res => (
                    <tr key={res.id} style={{ borderBottom: "1px solid var(--cafe-border-light)" }}>
                      <td style={{ padding: "14px 16px" }}>
                        <div style={{ fontWeight: "700" }}>{res.customerName}</div>
                        <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>
                          {res.phone} �?� {res.id}
                        </div>
                      </td>

                      <td style={{ padding: "14px 16px" }}>
                        <div style={{ fontWeight: "600" }}>{res.date}</div>
                        <div style={{ fontSize: "0.78rem", color: "var(--cafe-primary)", fontWeight: "700" }}>
                          ⏱️ {res.time}
                        </div>
                      </td>

                      <td style={{ padding: "14px 16px" }}>
                        <div style={{ fontWeight: "700" }}>{res.partySize} Guests</div>
                        <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>
                          Assigned: <strong>{res.tableNumber || "Unassigned"}</strong>
                        </div>
                      </td>

                      <td style={{ padding: "14px 16px" }}>
                        <span className="badge badge-primary" style={{ fontSize: "0.7rem" }}>
                          {res.occasion || "Dining"}
                        </span>
                        {res.customSetup && (
                          <div style={{ fontSize: "0.75rem", color: "var(--cafe-primary)", marginTop: "4px" }}>
                            Setup: {res.customSetup.baseTable} {res.customSetup.extraChairs > 0 && `(+${res.customSetup.extraChairs} chairs)`} �?� ₹{res.customSetup.setupFee}
                          </div>
                        )}
                        {res.specialRequests && (
                          <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", maxWidth: "260px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                            Note: {res.specialRequests}
                          </div>
                        )}
                      </td>

                      <td style={{ padding: "14px 16px" }}>
                        <span className={`badge ${
                          res.status === "confirmed" ? "badge-active" :
                          res.status === "arrived" ? "badge-primary" :
                          res.status === "pending" ? "badge-inactive" : "badge-nonveg"
                        }`}>
                          {res.status}
                        </span>
                      </td>

                      <td style={{ padding: "14px 16px", textAlign: "right" }}>
                        <div style={{ display: "flex", justifyContent: "flex-end", gap: "6px" }}>
                          {res.status === "pending" && (
                            <button
                              onClick={() => handleUpdateReservationStatus(res.id, "confirmed")}
                              className="btn-success"
                              style={{ padding: "5px 10px", fontSize: "0.78rem" }}
                            >
                              Approve
                            </button>
                          )}

                          {res.status === "confirmed" && (
                            <button
                              onClick={() => handleUpdateReservationStatus(res.id, "arrived")}
                              className="btn-primary"
                              style={{ padding: "5px 10px", fontSize: "0.78rem" }}
                            >
                              Check-In (Arrived)
                            </button>
                          )}

                          {res.status !== "cancelled" && (
                            <button
                              onClick={() => handleUpdateReservationStatus(res.id, "cancelled")}
                              className="btn-danger"
                              style={{ padding: "5px 8px", fontSize: "0.78rem" }}
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {(!cafe.reservations || cafe.reservations.length === 0) && (
                <div style={{ padding: "30px", textAlign: "center", color: "var(--cafe-text-muted)" }}>
                  No reservations found.
                </div>
              )}
            </div>
          )}

          {/* VIEW: CALENDAR */}
          {reservationView === "calendar" && (
            <div className="glass-card" style={{ padding: "20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                <h3 style={{ fontSize: "1.1rem" }}>October 2026 Reservation Calendar</h3>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button onClick={() => setCalendarMode("day")} className={calendarMode === "day" ? "btn-primary" : "btn-secondary"} style={{ padding: "4px 10px", fontSize: "0.8rem" }}>Day</button>
                  <button onClick={() => setCalendarMode("week")} className={calendarMode === "week" ? "btn-primary" : "btn-secondary"} style={{ padding: "4px 10px", fontSize: "0.8rem" }}>Week</button>
                  <button onClick={() => setCalendarMode("month")} className={calendarMode === "month" ? "btn-primary" : "btn-secondary"} style={{ padding: "4px 10px", fontSize: "0.8rem" }}>Month</button>
                </div>
              </div>

              {/* Time Slots Schedule */}
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {["12:00", "13:30", "18:00", "19:00", "20:30"].map(slot => {
                  const matching = cafe.reservations?.filter(r => r.time === slot);
                  return (
                    <div key={slot} style={{
                      display: "flex",
                      alignItems: "flex-start",
                      gap: "16px",
                      padding: "12px",
                      background: "var(--cafe-card-alt)",
                      borderRadius: "8px",
                      border: "1px solid var(--cafe-border-light)"
                    }}>
                      <div style={{ width: "70px", fontWeight: "800", color: "var(--cafe-primary)" }}>{slot}</div>
                      <div style={{ flex: 1, display: "flex", gap: "10px", flexWrap: "wrap" }}>
                        {matching && matching.length > 0 ? (
                          matching.map(r => (
                            <div key={r.id} style={{
                              background: "var(--cafe-card)",
                              border: "1px solid var(--cafe-border)",
                              borderRadius: "6px",
                              padding: "6px 10px",
                              fontSize: "0.85rem"
                            }}>
                              <strong>{r.customerName}</strong> ({r.partySize}p) �?� {r.tableNumber || "TBD"} �?� <span className="badge badge-active">{r.status}</span>
                            </div>
                          ))
                        ) : (
                          <span style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Available for bookings</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Event Buyout Requests */}
          {cafe.eventRequests && cafe.eventRequests.length > 0 && (
            <div className="glass-card" style={{ padding: "20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                <h3 style={{ fontSize: "1.1rem" }}>Full Restaurant Event Buyout Requests</h3>
                <span className="badge badge-primary">EVENT QUOTES</span>
              </div>

              {cafe.eventRequests.map(evt => (
                <div key={evt.id} style={{
                  padding: "16px",
                  background: "var(--cafe-card-alt)",
                  borderRadius: "var(--radius-md)",
                  border: "1px solid var(--cafe-border-light)"
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <h4 style={{ fontSize: "1rem" }}>{evt.eventName}</h4>
                      <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                        Organizer: <strong>{evt.customerName}</strong> ({evt.phone}, {evt.email})
                      </p>
                    </div>
                    <span className="badge badge-active">{evt.status}</span>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "10px", margin: "12px 0", fontSize: "0.85rem" }}>
                    <div>Date: <strong>{evt.date}</strong> ({evt.timeRange})</div>
                    <div>Expected Guests: <strong>{evt.guests} Guests</strong></div>
                    <div>Budget: <strong>{evt.budget}</strong></div>
                    <div>Quote Amount: <strong style={{ color: "var(--cafe-primary)" }}>₹{evt.quoteAmount}</strong></div>
                  </div>

                  <p style={{ fontSize: "0.82rem", color: "var(--cafe-text-muted)", background: "var(--cafe-card)", padding: "8px", borderRadius: "6px" }}>
                    <strong>Special Requirements:</strong> {evt.requirements}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          5. KITCHEN DISPLAY SYSTEM (KDS) TAB
          ======================================================== */}
      {activeTab === "kds" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {/* KDS Header */}
          <div style={{
            background: "var(--cafe-espresso)",
            color: "#FFF",
            padding: "16px 20px",
            borderRadius: "var(--radius-lg)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "12px"
          }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <ChefHat size={22} color="var(--cafe-primary)" />
                <h2 style={{ fontSize: "1.3rem", color: "#FFF" }}>Live Kitchen Display System (KDS)</h2>
              </div>
              <p style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.7)" }}>
                Orders sorted by priority. Check off items as they finish on the line.
              </p>
            </div>

            <div style={{ display: "flex", gap: "8px" }}>
              {["all", "received", "preparing", "ready"].map(st => (
                <button
                  key={st}
                  onClick={() => setKdsFilter(st)}
                  style={{
                    padding: "6px 12px",
                    borderRadius: "6px",
                    fontSize: "0.8rem",
                    fontWeight: "700",
                    textTransform: "capitalize",
                    background: kdsFilter === st ? "var(--cafe-primary)" : "rgba(255,255,255,0.1)",
                    color: "#FFF"
                  }}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* KDS Ticket Cards */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(330px, 1fr))",
            gap: "18px"
          }}>
            {cafe.orders?.filter(o => kdsFilter === "all" ? o.status !== "delivered" : o.status === kdsFilter).map((order) => {
              const isUrgent = order.elapsedMinutes > 15 && order.status !== "ready";
              const stageColors = {
                received: { bg: "#FEF2F2", text: "#DC2626", label: "NEW ORDER ALERT" },
                preparing: { bg: "#FEF3C7", text: "#D97706", label: "PREPARING" },
                ready: { bg: "#DCFCE7", text: "#16A34A", label: "READY FOR PICKUP/TABLE" }
              };
              const sc = stageColors[order.status] || stageColors.received;

              return (
                <div 
                  key={order.id}
                  style={{
                    background: "var(--cafe-card)",
                    border: `2px solid ${isUrgent ? "#DC2626" : "var(--cafe-border)"}`,
                    borderRadius: "var(--radius-lg)",
                    padding: "16px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    boxShadow: isUrgent ? "0 0 16px rgba(220, 38, 38, 0.25)" : "var(--shadow-sm)"
                  }}
                >
                  <div>
                    {/* Ticket Header */}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "10px" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                          <span style={{ fontWeight: "800", fontSize: "1.1rem" }}>#{order.id}</span>
                          <span style={{
                            background: "var(--cafe-primary-light)",
                            color: "var(--cafe-primary)",
                            fontSize: "0.75rem",
                            fontWeight: "800",
                            padding: "2px 8px",
                            borderRadius: "4px"
                          }}>
                            {order.source}
                          </span>
                        </div>
                        <div style={{ fontSize: "0.85rem", fontWeight: "700", marginTop: "2px", color: "var(--cafe-text)" }}>
                          {order.tableNumber || "To-Go Station"}
                        </div>
                      </div>

                      <div style={{ textAlign: "right" }}>
                        <span style={{
                          background: sc.bg,
                          color: sc.text,
                          fontWeight: "800",
                          fontSize: "0.72rem",
                          padding: "3px 8px",
                          borderRadius: "999px"
                        }}>
                          {sc.label}
                        </span>
                        <div style={{ fontSize: "0.75rem", color: isUrgent ? "#DC2626" : "var(--cafe-text-muted)", fontWeight: "700", marginTop: "3px" }}>
                          ⏱️ {order.elapsedMinutes}m elapsed / {order.estimatedMinutes}m
                        </div>
                      </div>
                    </div>

                    {/* Customer Notes */}
                    {order.specialNotes && (
                      <div style={{
                        background: "#FEF9C3",
                        border: "1px dashed #EAB308",
                        padding: "6px 10px",
                        borderRadius: "6px",
                        fontSize: "0.78rem",
                        color: "#854D0E",
                        marginBottom: "12px"
                      }}>
                        📝 <strong>Kitchen Note:</strong> {order.specialNotes}
                      </div>
                    )}

                    {/* Items Checklist */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "8px", margin: "12px 0" }}>
                      {order.items?.map((it, idx) => (
                        <div 
                          key={idx}
                          onClick={() => handleToggleOrderItemPrepared(order.id, idx)}
                          style={{
                            display: "flex",
                            alignItems: "flex-start",
                            gap: "8px",
                            padding: "6px 8px",
                            borderRadius: "6px",
                            background: it.prepared ? "var(--cafe-border-light)" : "var(--cafe-card-alt)",
                            cursor: "pointer",
                            transition: "background 0.15s"
                          }}
                        >
                          <input 
                            type="checkbox" 
                            checked={!!it.prepared} 
                            readOnly 
                            style={{ marginTop: "4px", accentColor: "var(--cafe-primary)" }}
                          />
                          <div style={{ flex: 1, textDecoration: it.prepared ? "line-through" : "none", opacity: it.prepared ? 0.6 : 1 }}>
                            <div style={{ fontWeight: "700", fontSize: "0.9rem" }}>
                              {it.qty}x {it.name}
                            </div>
                            {it.customizations && it.customizations.length > 0 && (
                              <div style={{ fontSize: "0.75rem", color: "var(--cafe-primary)" }}>
                                {it.customizations.join(" �?� ")}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Stage Advance Button */}
                  <div style={{ marginTop: "12px", paddingTop: "12px", borderTop: "1px solid var(--cafe-border-light)" }}>
                    <button
                      onClick={() => handleProgressOrderStage(order.id)}
                      className="btn-primary"
                      style={{ width: "100%", padding: "10px", fontSize: "0.85rem" }}
                    >
                      {order.status === "received" && "Start Preparation →"}
                      {order.status === "preparing" && "Mark Ready for Pickup / Table (Send SMS) →"}
                      {order.status === "ready" && "Complete & Delivered ✓"}
                    </button>
                  </div>
                </div>
              );
            })}

            {(!cafe.orders || cafe.orders.filter(o => o.status !== "delivered").length === 0) && (
              <div style={{ gridColumn: "1/-1", padding: "50px", textAlign: "center", color: "var(--cafe-text-muted)" }}>
                🎉 Kitchen all caught up! No active tickets in the line.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          6. CUSTOMER DATA & ANALYTICS TAB
          ======================================================== */}
      {activeTab === "customers" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2 style={{ fontSize: "1.3rem" }}>Customer Database & Diners Analytics</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                Diner history, order spend, dietary tags, and preferred seating patterns.
              </p>
            </div>

            <button 
              onClick={() => {
                const rows = (cafe.reservations || []).map(r => ({
                  "Name": r.customerName,
                  "Phone": r.phone,
                  "Email": r.email,
                  "Bookings": 1,
                  "Occasion": r.occasion || "Dining",
                  "Preferred Table": r.tableNumber || "Window"
                }));
                exportToCsv(`${cafe.name.replace(/\s+/g, "_")}_Customers.csv`, rows);
              }}
              className="btn-secondary"
            >
              <Download size={16} /> Export Customers (CSV)
            </button>
          </div>

          {/* Customer CRM Table */}
          <div className="glass-card" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.9rem" }}>
              <thead>
                <tr style={{ background: "var(--cafe-card-alt)", borderBottom: "1px solid var(--cafe-border)", color: "var(--cafe-text-muted)" }}>
                  <th style={{ padding: "14px 16px" }}>Customer Name</th>
                  <th style={{ padding: "14px 16px" }}>Contact Info</th>
                  <th style={{ padding: "14px 16px" }}>Visits / Reservations</th>
                  <th style={{ padding: "14px 16px" }}>Preferred Seating</th>
                  <th style={{ padding: "14px 16px" }}>Dietary & Special Notes</th>
                </tr>
              </thead>
              <tbody>
                {cafe.reservations?.map((res, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid var(--cafe-border-light)" }}>
                    <td style={{ padding: "14px 16px", fontWeight: "700" }}>{res.customerName}</td>
                    <td style={{ padding: "14px 16px" }}>
                      <div>{res.phone}</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>{res.email}</div>
                    </td>
                    <td style={{ padding: "14px 16px", fontWeight: "600" }}>
                      {i + 2} Lifetime Bookings
                    </td>
                    <td style={{ padding: "14px 16px" }}>
                      <span className="badge badge-primary">{res.seatingPreference || "Near Window"}</span>
                    </td>
                    <td style={{ padding: "14px 16px", fontSize: "0.82rem", color: "var(--cafe-text-muted)" }}>
                      {res.specialRequests || "No specific allergen preferences"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================
          7. QR BATCH OPERATIONS & BACKUPS
          ======================================================== */}
      {activeTab === "qr_batch" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2 style={{ fontSize: "1.3rem" }}>Printable Table QR Signage & Backups</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>
                Print high-resolution QR standees for all your tables with table numbers and branding.
              </p>
            </div>

            <button 
              onClick={() => window.print()}
              className="btn-primary"
            >
              <Printer size={16} /> Print All QR Signage Standees
            </button>
          </div>

          {/* Printable Cards Grid */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: "20px"
          }}>
            {cafe.tables?.map((table) => {
              const url = getTableScanUrl(cafe.id, table.id);
              return (
                <div 
                  key={table.id}
                  style={{
                    background: "#FFFFFF",
                    border: "2px solid #C86D27",
                    borderRadius: "16px",
                    padding: "24px",
                    textAlign: "center",
                    boxShadow: "var(--shadow-md)",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center"
                  }}
                >
                  <div style={{ fontSize: "0.8rem", textTransform: "uppercase", letterSpacing: "1px", color: "#6B5B4E", fontWeight: "700" }}>
                    {cafe.name}
                  </div>
                  <h3 style={{ fontSize: "1.4rem", margin: "6px 0", color: "#1A120B" }}>
                    {table.number}
                  </h3>
                  <div style={{ fontSize: "0.78rem", color: "#C86D27", fontWeight: "700", marginBottom: "16px" }}>
                    Scan to Browse Menu & Order Directly
                  </div>

                  {/* QR Image Placeholder / Canvas */}
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(url)}`}
                    alt={`QR Code for ${table.number}`}
                    style={{ width: "160px", height: "160px", borderRadius: "12px", border: "1px solid #E8DCCF" }}
                  />

                  <div style={{ fontSize: "0.75rem", color: "#6B5B4E", marginTop: "14px" }}>
                    Direct Kitchen Dispatch �?� Instant Digital Bill
                  </div>

                  <div style={{ marginTop: "14px", display: "flex", gap: "8px" }}>
                    <button
                      onClick={() => onSimulateTableScan(cafe.id, table.id)}
                      className="btn-secondary"
                      style={{ padding: "4px 10px", fontSize: "0.75rem" }}
                    >
                      Test Scan
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODAL: SINGLE TABLE QR PREVIEW */}
      {selectedTableForQr && (
        <div className="modal-overlay" onClick={() => setSelectedTableForQr(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "420px", padding: "28px", textAlign: "center" }}>
            <h3 style={{ fontSize: "1.3rem" }}>{selectedTableForQr.number} QR Code</h3>
            <p style={{ fontSize: "0.82rem", color: "var(--cafe-text-muted)", marginTop: "4px" }}>
              Scanning this code in the café connects diners directly to {selectedTableForQr.id}
            </p>

            <div style={{ margin: "20px 0" }}>
              {qrModalDataUrl ? (
                <img src={qrModalDataUrl} alt="QR Code" style={{ width: "220px", height: "220px", borderRadius: "12px", margin: "0 auto" }} />
              ) : (
                <div>Generating QR...</div>
              )}
            </div>

            <div style={{ fontSize: "0.8rem", background: "var(--cafe-card-alt)", padding: "10px", borderRadius: "8px", wordBreak: "break-all" }}>
              Target URL: <code>{getTableScanUrl(cafe.id, selectedTableForQr.id)}</code>
            </div>

            <div style={{ display: "flex", justifyContent: "center", gap: "10px", marginTop: "20px" }}>
              <button
                onClick={() => {
                  onSimulateTableScan(cafe.id, selectedTableForQr.id);
                  setSelectedTableForQr(null);
                }}
                className="btn-primary"
                style={{ fontSize: "0.85rem" }}
              >
                �? Test Scan as Customer Now
              </button>
              <button onClick={() => setSelectedTableForQr(null)} className="btn-secondary">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD SINGLE TABLE */}
      {showAddTableModal && (
        <div className="modal-overlay" onClick={() => setShowAddTableModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "500px", padding: "24px" }}>
            <h3 style={{ fontSize: "1.3rem", marginBottom: "16px" }}>Add New Dining Table</h3>
            <form onSubmit={handleAddTableSubmit} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              <div className="form-group">
                <label className="form-label">Table Name / Visible Label</label>
                <input
                  type="text"
                  placeholder="e.g. Table 9 (Corner Patio)"
                  value={tableForm.number}
                  onChange={(e) => setTableForm({ ...tableForm, number: e.target.value })}
                  className="form-input"
                />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div className="form-group">
                  <label className="form-label">Default Seating Capacity</label>
                  <select
                    value={tableForm.capacity}
                    onChange={(e) => setTableForm({ ...tableForm, capacity: Number(e.target.value) })}
                    className="form-select"
                  >
                    <option value="2">2 Persons</option>
                    <option value="4">4 Persons</option>
                    <option value="6">6 Persons</option>
                    <option value="8">8 Persons</option>
                    <option value="10">10 Persons</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Location in Café</label>
                  <select
                    value={tableForm.location}
                    onChange={(e) => setTableForm({ ...tableForm, location: e.target.value })}
                    className="form-select"
                  >
                    <option value="Near Window">Near Window</option>
                    <option value="Center">Center Courtyard</option>
                    <option value="Corner">Quiet Corner</option>
                    <option value="Outdoor">Outdoor Patio / Terrace</option>
                    <option value="VIP">VIP Private Nook</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Special Features (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. High chair available, Wheelchair accessible, VIP"
                  value={tableForm.features}
                  onChange={(e) => setTableForm({ ...tableForm, features: e.target.value })}
                  className="form-input"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Table Setup Fee (₹)</label>
                <input
                  type="number"
                  value={tableForm.setupFee}
                  onChange={(e) => setTableForm({ ...tableForm, setupFee: e.target.value })}
                  className="form-input"
                />
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginTop: "10px" }}>
                <button type="button" onClick={() => setShowAddTableModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Create Table & Generate QR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: BULK ADD TABLES */}
      {showBulkTableModal && (
        <div className="modal-overlay" onClick={() => setShowBulkTableModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "480px", padding: "24px" }}>
            <h3 style={{ fontSize: "1.3rem", marginBottom: "16px" }}>Bulk Add Tables</h3>
            <form onSubmit={handleBulkAddSubmit} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              <div className="form-group">
                <label className="form-label">How many tables to add?</label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={bulkCount}
                  onChange={(e) => setBulkCount(e.target.value)}
                  className="form-input"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Capacity for each</label>
                <select
                  value={bulkCapacity}
                  onChange={(e) => setBulkCapacity(e.target.value)}
                  className="form-select"
                >
                  <option value="2">2 Persons</option>
                  <option value="4">4 Persons</option>
                  <option value="6">6 Persons</option>
                  <option value="8">8 Persons</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Location</label>
                <select
                  value={bulkLocation}
                  onChange={(e) => setBulkLocation(e.target.value)}
                  className="form-select"
                >
                  <option value="Center">Center Main Floor</option>
                  <option value="Outdoor">Outdoor Terrace</option>
                  <option value="Near Window">Window Section</option>
                </select>
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginTop: "10px" }}>
                <button type="button" onClick={() => setShowBulkTableModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Add {bulkCount} Tables
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT MENU ITEM */}
      {showAddItemModal && (
        <div className="modal-overlay" onClick={() => setShowAddItemModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "680px", padding: "26px" }}>
            <h3 style={{ fontSize: "1.3rem", marginBottom: "16px" }}>
              {editingItem ? "Edit Food Item" : "Add New Menu Item"}
            </h3>

            <form onSubmit={handleItemSubmit} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "12px" }}>
                <div className="form-group">
                  <label className="form-label">Food Item Name <span className="req">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Truffle Wild Mushroom Pizza"
                    value={itemForm.name}
                    onChange={(e) => setItemForm({ ...itemForm, name: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select
                    value={itemForm.categoryId}
                    onChange={(e) => setItemForm({ ...itemForm, categoryId: e.target.value })}
                    className="form-select"
                  >
                    {cafe.menuCategories?.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Detailed Description (ingredients & prep method)</label>
                <textarea
                  rows="2"
                  value={itemForm.description}
                  onChange={(e) => setItemForm({ ...itemForm, description: e.target.value })}
                  className="form-textarea"
                />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                <div className="form-group">
                  <label className="form-label">Price (₹) <span className="req">*</span></label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={itemForm.price}
                    onChange={(e) => setItemForm({ ...itemForm, price: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Discount Price (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Optional"
                    value={itemForm.discountedPrice}
                    onChange={(e) => setItemForm({ ...itemForm, discountedPrice: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Stock Quantity</label>
                  <input
                    type="number"
                    value={itemForm.stockQty}
                    onChange={(e) => setItemForm({ ...itemForm, stockQty: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                <div className="form-group">
                  <label className="form-label">Dietary Classification</label>
                  <select
                    value={itemForm.dietary}
                    onChange={(e) => setItemForm({ ...itemForm, dietary: e.target.value })}
                    className="form-select"
                  >
                    <option value="veg">Vegetarian</option>
                    <option value="vegan">Vegan</option>
                    <option value="non-veg">Non-Vegetarian</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Spice Level</label>
                  <select
                    value={itemForm.spiceLevel}
                    onChange={(e) => setItemForm({ ...itemForm, spiceLevel: e.target.value })}
                    className="form-select"
                  >
                    <option value="mild">Mild</option>
                    <option value="medium">Medium</option>
                    <option value="hot">Hot</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Prep Time (mins)</label>
                  <input
                    type="number"
                    value={itemForm.prepTimeMins}
                    onChange={(e) => setItemForm({ ...itemForm, prepTimeMins: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Allergens List (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Dairy, Gluten, Tree Nuts, Peanuts"
                  value={itemForm.allergens}
                  onChange={(e) => setItemForm({ ...itemForm, allergens: e.target.value })}
                  className="form-input"
                />
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginTop: "10px" }}>
                <button type="button" onClick={() => setShowAddItemModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  {editingItem ? "Save Changes" : "Publish Food Item"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

