import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, Store, Lock, User, Key, Eye, EyeOff, 
  ArrowRight, X, CheckCircle2, Coffee, AlertCircle, Sparkles 
} from "lucide-react";
import { playChime } from "../../data/mockData";

export const DEMO_CREDENTIALS = {
  superadmin: {
    role: "superadmin",
    username: "admin",
    password: "admin123",
    title: "Super Admin",
    name: "System Super Admin",
    email: "admin@aromacloud.com",
    badge: "Franchise Headquarters",
    description: "Full governance, franchise onboarding, network analytics & multi-café auditing."
  },
  cafeowner: {
    role: "cafeowner",
    username: "owner",
    password: "owner123",
    title: "Café Owner",
    name: "Marcus Vance",
    email: "marcus@aromaroast.com",
    badge: "Store Operations",
    description: "Live table layout, table QR ordering, kitchen display (KDS), and menu management."
  }
};

export default function LoginModal({
  isOpen,
  onClose,
  initialRole = "superadmin", // "superadmin" or "cafeowner"
  onLoginSuccess,
  cafes = []
}) {
  const [selectedRole, setSelectedRole] = useState(initialRole);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [selectedCafeId, setSelectedCafeId] = useState(cafes[0]?.id || "cafe-aroma-01");
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync role when modal opens with specific initialRole
  useEffect(() => {
    if (isOpen) {
      setSelectedRole(initialRole);
      setErrorMessage("");
    }
  }, [isOpen, initialRole]);

  if (!isOpen) return null;

  const currentCreds = DEMO_CREDENTIALS[selectedRole];

  // Auto-fill demo credentials helper
  const handleAutoFill = () => {
    setUsername(currentCreds.username);
    setPassword(currentCreds.password);
    setErrorMessage("");
    playChime("success");
  };

  // Switch role tab
  const handleTabChange = (role) => {
    setSelectedRole(role);
    setErrorMessage("");
    setUsername("");
    setPassword("");
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage("");
    setIsSubmitting(true);

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setErrorMessage("Please enter both ID/Username and Password.");
      setIsSubmitting(false);
      playChime("alert");
      return;
    }

    if (selectedRole === "superadmin") {
      // Validate Super Admin credentials
      const isValidAdmin = (
        (cleanUser === "admin" || cleanUser === "superadmin" || cleanUser === "admin@aromacloud.com") &&
        cleanPass === "admin123"
      );

      if (isValidAdmin) {
        onLoginSuccess({
          role: "superadmin",
          username: cleanUser,
          name: "Franchise Super Admin",
          email: "admin@aromacloud.com"
        });
        onClose();
      } else {
        setErrorMessage("Invalid Super Admin ID or Password. Check the demo credentials above.");
        playChime("alert");
      }
    } else {
      // Validate Café Owner credentials
      // 1. Matches demo owner/owner123
      const isDemoOwner = (
        (cleanUser === "owner" || cleanUser === "cafeowner" || cleanUser === "owner@aroma.com") &&
        cleanPass === "owner123"
      );

      // 2. Or matches any specific cafe's configured credentials
      const matchedCafe = cafes.find(c => 
        (c.credentials?.username?.toLowerCase() === cleanUser && c.credentials?.tempPassword === cleanPass) ||
        (c.email?.toLowerCase() === cleanUser && cleanPass === "owner123")
      );

      if (isDemoOwner || matchedCafe) {
        const targetCafe = matchedCafe || cafes.find(c => c.id === selectedCafeId) || cafes[0];
        onLoginSuccess({
          role: "cafeowner",
          username: cleanUser,
          name: targetCafe.ownerName || "Marcus Vance",
          email: targetCafe.email || "marcus@aromaroast.com",
          cafeId: targetCafe.id
        });
        onClose();
      } else {
        setErrorMessage("Invalid Café Owner ID or Password. Check the demo credentials above.");
        playChime("alert");
      }
    }

    setIsSubmitting(false);
  };

  return (
    <div 
      className="modal-overlay" 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      style={{ zIndex: 9999 }}
    >
      <div 
        className="modal-content"
        style={{
          maxWidth: "480px",
          padding: "0",
          overflow: "hidden",
          borderRadius: "20px",
          border: "1px solid var(--cafe-border)",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.3)"
        }}
      >
        {/* Modal Header */}
        <div style={{
          background: "linear-gradient(135deg, var(--cafe-espresso) 0%, #2A1C12 100%)",
          color: "#FFF",
          padding: "24px",
          position: "relative"
        }}>
          <button
            onClick={onClose}
            style={{
              position: "absolute",
              top: "16px",
              right: "16px",
              background: "rgba(255, 255, 255, 0.15)",
              border: "none",
              color: "#FFF",
              width: "32px",
              height: "32px",
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer"
            }}
          >
            <X size={18} />
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "8px" }}>
            <div style={{
              width: "38px",
              height: "38px",
              borderRadius: "10px",
              background: "var(--cafe-primary)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#FFF"
            }}>
              <Lock size={20} />
            </div>
            <div>
              <h2 style={{ fontSize: "1.3rem", color: "#FFF", margin: 0, fontWeight: "700" }}>
                Portal Authentication
              </h2>
              <div style={{ fontSize: "0.8rem", color: "rgba(255, 255, 255, 0.75)" }}>
                Secure access for Franchise Governance & Café Management
              </div>
            </div>
          </div>

          {/* Role Selection Tabs */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "8px",
            marginTop: "18px",
            background: "rgba(0, 0, 0, 0.35)",
            padding: "4px",
            borderRadius: "12px"
          }}>
            <button
              type="button"
              onClick={() => handleTabChange("superadmin")}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "10px",
                borderRadius: "8px",
                border: "none",
                fontSize: "0.85rem",
                fontWeight: "700",
                cursor: "pointer",
                background: selectedRole === "superadmin" ? "var(--cafe-primary)" : "transparent",
                color: "#FFF",
                transition: "all 0.2s"
              }}
            >
              <ShieldCheck size={16} />
              <span>Super Admin</span>
            </button>

            <button
              type="button"
              onClick={() => handleTabChange("cafeowner")}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "10px",
                borderRadius: "8px",
                border: "none",
                fontSize: "0.85rem",
                fontWeight: "700",
                cursor: "pointer",
                background: selectedRole === "cafeowner" ? "var(--cafe-primary)" : "transparent",
                color: "#FFF",
                transition: "all 0.2s"
              }}
            >
              <Store size={16} />
              <span>Café Owner</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div style={{ padding: "24px" }}>
          {/* Quick Demo Credentials Info Card */}
          <div style={{
            background: "var(--cafe-primary-light)",
            border: "1px dashed var(--cafe-primary)",
            borderRadius: "12px",
            padding: "14px 16px",
            marginBottom: "20px"
          }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{
                fontSize: "0.75rem",
                fontWeight: "800",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                color: "var(--cafe-primary)",
                display: "flex",
                alignItems: "center",
                gap: "4px"
              }}>
                <Sparkles size={14} /> Demo Credentials
              </span>
              <button
                type="button"
                onClick={handleAutoFill}
                style={{
                  background: "var(--cafe-primary)",
                  color: "#FFF",
                  border: "none",
                  padding: "4px 10px",
                  borderRadius: "6px",
                  fontSize: "0.75rem",
                  fontWeight: "700",
                  cursor: "pointer"
                }}
              >
                1-Click Auto Fill
              </button>
            </div>

            <div style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "8px",
              fontSize: "0.85rem",
              background: "rgba(255, 255, 255, 0.7)",
              padding: "10px",
              borderRadius: "8px"
            }}>
              <div>
                <span style={{ color: "var(--cafe-text-muted)", fontSize: "0.75rem", display: "block" }}>Demo ID / Username:</span>
                <strong style={{ color: "var(--cafe-text)", fontFamily: "monospace", fontSize: "0.95rem" }}>
                  {currentCreds.username}
                </strong>
              </div>
              <div>
                <span style={{ color: "var(--cafe-text-muted)", fontSize: "0.75rem", display: "block" }}>Demo Password:</span>
                <strong style={{ color: "var(--cafe-text)", fontFamily: "monospace", fontSize: "0.95rem" }}>
                  {currentCreds.password}
                </strong>
              </div>
            </div>
            <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "8px" }}>
              {currentCreds.description}
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              background: "#FEE2E2",
              color: "#B91C1C",
              padding: "10px 14px",
              borderRadius: "8px",
              fontSize: "0.85rem",
              marginBottom: "16px",
              border: "1px solid #FECACA"
            }}>
              <AlertCircle size={16} />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "var(--cafe-text)" }}>
                ID / Username
              </label>
              <div style={{ position: "relative" }}>
                <User size={18} color="var(--cafe-text-muted)" style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)" }} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={`Enter ${selectedRole === "superadmin" ? "admin" : "owner"}`}
                  className="form-input"
                  style={{ width: "100%", paddingLeft: "38px" }}
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "var(--cafe-text)" }}>
                Password
              </label>
              <div style={{ position: "relative" }}>
                <Key size={18} color="var(--cafe-text-muted)" style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)" }} />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="form-input"
                  style={{ width: "100%", paddingLeft: "38px", paddingRight: "38px" }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    right: "12px",
                    top: "50%",
                    transform: "translateY(-50%)",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    color: "var(--cafe-text-muted)"
                  }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Target Cafe selector if Cafe Owner */}
            {selectedRole === "cafeowner" && cafes.length > 1 && (
              <div>
                <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "var(--cafe-text)" }}>
                  Assign to Café Location
                </label>
                <select
                  value={selectedCafeId}
                  onChange={(e) => setSelectedCafeId(e.target.value)}
                  className="form-select"
                  style={{ width: "100%" }}
                >
                  {cafes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.city})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-primary"
              style={{
                width: "100%",
                padding: "12px",
                fontSize: "0.95rem",
                fontWeight: "700",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                marginTop: "6px"
              }}
            >
              <span>Login to {selectedRole === "superadmin" ? "Super Admin" : "Café Owner Panel"}</span>
              <ArrowRight size={18} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
