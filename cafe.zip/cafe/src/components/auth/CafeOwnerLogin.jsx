import React, { useState } from "react";
import { Store, User, Key, Eye, EyeOff, ArrowRight, ArrowLeft, Sparkles, AlertCircle, Coffee } from "lucide-react";
import { playChime } from "../../data/mockData";

export default function CafeOwnerLogin({ cafes = [], onLoginSuccess, onReturnToCustomer }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [selectedCafeId, setSelectedCafeId] = useState(cafes[0]?.id || "cafe-aroma-01");
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const DEMO_USER = "owner";
  const DEMO_PASS = "owner123";

  const handleAutoFill = () => {
    setUsername(DEMO_USER);
    setPassword(DEMO_PASS);
    setErrorMessage("");
    playChime("success");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage("");
    setIsSubmitting(true);

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setErrorMessage("Please enter both Café Owner ID and Password.");
      setIsSubmitting(false);
      playChime("alert");
      return;
    }

    const isDemoOwner = (
      (cleanUser === "owner" || cleanUser === "cafeowner" || cleanUser === "owner@aroma.com") &&
      cleanPass === "owner123"
    );

    const matchedCafe = cafes.find(c => 
      (c.credentials?.username?.toLowerCase() === cleanUser && c.credentials?.tempPassword === cleanPass) ||
      (c.email?.toLowerCase() === cleanUser && cleanPass === "owner123")
    );

    if (isDemoOwner || matchedCafe) {
      const targetCafe = matchedCafe || cafes.find(c => c.id === selectedCafeId) || cafes[0];
      onLoginSuccess({
        role: "cafeowner",
        username: cleanUser,
        name: targetCafe.ownerName || "Marcus Vance",
        email: targetCafe.email || "marcus@aromaroast.com",
        cafeId: targetCafe.id
      });
      playChime("success");
    } else {
      setErrorMessage("Invalid Café Owner ID or Password. Please check demo credentials.");
      playChime("alert");
    }

    setIsSubmitting(false);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "radial-gradient(ellipse at top, #2C1B10 0%, #150E09 100%)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      color: "#FFF"
    }}>
      {/* Brand Header */}
      <div style={{ textAlign: "center", marginBottom: "28px" }}>
        <div style={{
          width: "56px",
          height: "56px",
          borderRadius: "16px",
          background: "linear-gradient(135deg, var(--cafe-primary) 0%, #1A120B 100%)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#FFF",
          boxShadow: "0 8px 24px rgba(200, 109, 39, 0.35)",
          marginBottom: "12px"
        }}>
          <Store size={28} color="#FFF" />
        </div>
        <h1 style={{
          fontFamily: "var(--font-heading)",
          fontSize: "2rem",
          fontWeight: "800",
          color: "#FFF",
          margin: 0
        }}>
          Café Owner <span style={{ color: "var(--cafe-primary)" }}>Portal</span>
        </h1>
        <p style={{ color: "rgba(255, 255, 255, 0.65)", fontSize: "0.9rem", marginTop: "4px" }}>
          Daily Table Layout, Live KDS Kitchen Orders & Digital Menu Control
        </p>
      </div>

      {/* Login Card */}
      <div style={{
        maxWidth: "460px",
        width: "100%",
        background: "rgba(35, 24, 15, 0.95)",
        backdropFilter: "blur(12px)",
        borderRadius: "24px",
        border: "1px solid rgba(200, 109, 39, 0.25)",
        boxShadow: "0 25px 60px rgba(0, 0, 0, 0.6)",
        padding: "32px",
        position: "relative"
      }}>
        {/* Demo Credentials Box */}
        <div style={{
          background: "rgba(200, 109, 39, 0.12)",
          border: "1px dashed rgba(200, 109, 39, 0.5)",
          borderRadius: "14px",
          padding: "16px",
          marginBottom: "24px"
        }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
            <span style={{
              fontSize: "0.75rem",
              fontWeight: "800",
              textTransform: "uppercase",
              letterSpacing: "0.5px",
              color: "var(--cafe-primary)",
              display: "flex",
              alignItems: "center",
              gap: "5px"
            }}>
              <Sparkles size={14} /> Café Owner Demo Access
            </span>
            <button
              type="button"
              onClick={handleAutoFill}
              style={{
                background: "var(--cafe-primary)",
                color: "#FFF",
                border: "none",
                padding: "4px 10px",
                borderRadius: "6px",
                fontSize: "0.75rem",
                fontWeight: "700",
                cursor: "pointer"
              }}
            >
              1-Click Fill
            </button>
          </div>

          <div style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "8px",
            background: "rgba(0, 0, 0, 0.3)",
            padding: "10px",
            borderRadius: "8px",
            fontSize: "0.85rem"
          }}>
            <div>
              <span style={{ color: "rgba(255, 255, 255, 0.6)", fontSize: "0.72rem", display: "block" }}>Demo ID:</span>
              <strong style={{ color: "#FFF", fontFamily: "monospace", fontSize: "0.95rem" }}>{DEMO_USER}</strong>
            </div>
            <div>
              <span style={{ color: "rgba(255, 255, 255, 0.6)", fontSize: "0.72rem", display: "block" }}>Password:</span>
              <strong style={{ color: "#FFF", fontFamily: "monospace", fontSize: "0.95rem" }}>{DEMO_PASS}</strong>
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            background: "rgba(220, 38, 38, 0.15)",
            border: "1px solid rgba(220, 38, 38, 0.4)",
            color: "#FCA5A5",
            padding: "10px 14px",
            borderRadius: "10px",
            fontSize: "0.85rem",
            marginBottom: "18px"
          }}>
            <AlertCircle size={16} />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "rgba(255, 255, 255, 0.85)" }}>
              Café Owner ID / Username
            </label>
            <div style={{ position: "relative" }}>
              <User size={18} color="rgba(255, 255, 255, 0.4)" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter owner ID"
                style={{
                  width: "100%",
                  padding: "12px 14px 12px 42px",
                  borderRadius: "10px",
                  border: "1px solid rgba(255, 255, 255, 0.15)",
                  background: "rgba(0, 0, 0, 0.3)",
                  color: "#FFF",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
                autoFocus
              />
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "rgba(255, 255, 255, 0.85)" }}>
              Password
            </label>
            <div style={{ position: "relative" }}>
              <Key size={18} color="rgba(255, 255, 255, 0.4)" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                style={{
                  width: "100%",
                  padding: "12px 42px 12px 42px",
                  borderRadius: "10px",
                  border: "1px solid rgba(255, 255, 255, 0.15)",
                  background: "rgba(0, 0, 0, 0.3)",
                  color: "#FFF",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{
                  position: "absolute",
                  right: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  color: "rgba(255, 255, 255, 0.5)"
                }}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {cafes.length > 1 && (
            <div>
              <label style={{ display: "block", fontSize: "0.85rem", fontWeight: "600", marginBottom: "6px", color: "rgba(255, 255, 255, 0.85)" }}>
                Select Café Location
              </label>
              <select
                value={selectedCafeId}
                onChange={(e) => setSelectedCafeId(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 14px",
                  borderRadius: "10px",
                  border: "1px solid rgba(255, 255, 255, 0.15)",
                  background: "#1E140C",
                  color: "#FFF",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              >
                {cafes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.city})
                  </option>
                ))}
              </select>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="btn-primary"
            style={{
              padding: "13px",
              fontSize: "0.95rem",
              fontWeight: "700",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              marginTop: "8px",
              borderRadius: "10px"
            }}
          >
            <span>Sign In to Café Operations</span>
            <ArrowRight size={18} />
          </button>
        </form>

        {/* Back to Customer Website */}
        <div style={{ marginTop: "24px", textAlign: "center", borderTop: "1px solid rgba(255, 255, 255, 0.1)", paddingTop: "18px" }}>
          <button
            type="button"
            onClick={onReturnToCustomer}
            style={{
              background: "none",
              border: "none",
              color: "rgba(255, 255, 255, 0.6)",
              fontSize: "0.85rem",
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
              cursor: "pointer",
              transition: "color 0.2s"
            }}
          >
            <ArrowLeft size={15} />
            <span>Return to Public Customer Website</span>
          </button>
        </div>
      </div>
    </div>
  );
}
