import React, { useState, useEffect } from "react";
import { 
  Search, MapPin, Star, Calendar, Clock, Users, Coffee, 
  UtensilsCrossed, Plus, Minus, ArrowRight, Check, X, 
  Heart, Sparkles, ShoppingBag, ShieldCheck, QrCode, 
  Download, MessageCircle, AlertCircle, ChevronRight, Phone,
  Award, Flame, Copy, CheckCircle2
} from "lucide-react";
import confetti from "canvas-confetti";
import { generateIcsFile, playChime, formatPrice, CELEBRATION_PACKS } from "../../data/mockData";
import { generateQrDataUrl } from "../../utils/qrHelper";

export default function CustomerView({
  cafes,
  currency = "INR",
  activeCafeId,
  setActiveCafeId,
  scannedTableInfo,
  onClearScannedTable,
  onAddReservation,
  onPlaceOrder,
  myReservations,
  onCancelReservation,
  isMobileFrame,
  showMyReservationsModal,
  setShowMyReservationsModal,
  cart: propCart,
  setCart: propSetCart,
  isCartOpen: propIsCartOpen,
  setIsCartOpen: propSetIsCartOpen
}) {
  const [selectedCafe, setSelectedCafe] = useState(
    cafes.find(c => c.id === activeCafeId) || cafes[0]
  );
  const [browseSearch, setBrowseSearch] = useState("");
  const [selectedCuisine, setSelectedCuisine] = useState("All");
  const [viewState, setViewState] = useState(scannedTableInfo ? "cafe_detail" : "browse"); 
  // "browse", "cafe_detail", "order_tracking"
  const [cafeTab, setCafeTab] = useState(scannedTableInfo ? "menu" : "menu"); 
  // "menu", "reserve", "event", "reviews"

  // Menu State
  const [activeCategory, setActiveCategory] = useState("all");
  const [menuSearch, setMenuSearch] = useState("");
  const [dietaryFilter, setDietaryFilter] = useState("all"); // "all", "veg", "vegan", "non-veg"
  const [sortBy, setSortBy] = useState("popular");
  const [selectedFoodItem, setSelectedFoodItem] = useState(null);
  const [favorites, setFavorites] = useState([]);

  // Food Customization Modal State
  const [modalQuantity, setModalQuantity] = useState(1);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [singleChoiceOption, setSingleChoiceOption] = useState("");

  // Cart State (Lifted from App or fallback to internal)
  const [internalCart, setInternalCart] = useState([]);
  const [internalIsCartOpen, setInternalIsCartOpen] = useState(false);
  const [addedToast, setAddedToast] = useState(null);

  const cart = propCart !== undefined ? propCart : internalCart;
  const setCart = propSetCart !== undefined ? propSetCart : setInternalCart;
  const isCartOpen = propIsCartOpen !== undefined ? propIsCartOpen : internalIsCartOpen;
  const setIsCartOpen = propSetIsCartOpen !== undefined ? propSetIsCartOpen : setInternalIsCartOpen;

  const [appliedPromo, setAppliedPromo] = useState(null);
  const [promoInput, setPromoInput] = useState("");

  // Reservation Form State
  const [resDate, setResDate] = useState("2026-10-20");
  const [resTime, setResTime] = useState("19:00");
  const [resPartySize, setResPartySize] = useState(4);
  const [resTablePref, setResTablePref] = useState("Near Window");
  const [resOccasion, setResOccasion] = useState("Dining");
  const [resSpecialRequests, setResSpecialRequests] = useState("");
  const [selectedBaseTableConfig, setSelectedBaseTableConfig] = useState({
    name: "4-seater table",
    baseCapacity: 4,
    fee: 200
  });
  const [resExtraChairs, setResExtraChairs] = useState(0); // ₹50 per chair
  const [selectedCelebrationPack, setSelectedCelebrationPack] = useState(null);
  const [resCustomerName, setResCustomerName] = useState("");
  const [resCustomerPhone, setResCustomerPhone] = useState("");
  const [resCustomerEmail, setResCustomerEmail] = useState("");
  const [confirmedReservation, setConfirmedReservation] = useState(null);
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  // WhatsApp Interactive Live Chat Simulator State
  const [showLiveChatModal, setShowLiveChatModal] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([
    { sender: "barista", text: "Hello! Welcome to AromaCloud. Barista Marco is at your service. How may we assist your table today?", time: "12:50" }
  ]);

  // Full Restaurant Event Booking Form State
  const [evtName, setEvtName] = useState("");
  const [evtDate, setEvtDate] = useState("2026-11-20");
  const [evtTimeRange, setEvtTimeRange] = useState("18:00 - 23:00");
  const [evtGuests, setEvtGuests] = useState(50);
  const [evtBudget, setEvtBudget] = useState("₹35,000 - ₹50,000");
  const [evtRequirements, setEvtRequirements] = useState("");
  const [evtSuccessMessage, setEvtSuccessMessage] = useState(false);

  // Checkout State
  const [checkoutStep, setCheckoutStep] = useState(1); // 1: Cart, 2: Details & Payment, 3: Success
  const [diningMode, setDiningMode] = useState(scannedTableInfo ? "table_scan" : "dine_in");
  const [custName, setCustName] = useState("Alex Harrison");
  const [custPhone, setCustPhone] = useState("+1 (555) 392-8812");
  const [orderPaymentMethod, setOrderPaymentMethod] = useState("Apple Pay");
  const [orderSpecialNotes, setOrderSpecialNotes] = useState("");
  const [activeTrackingOrder, setActiveTrackingOrder] = useState(null);

  // Check-In QR modal
  const [viewingCheckinQr, setViewingCheckinQr] = useState(null);
  const [checkinQrDataUrl, setCheckinQrDataUrl] = useState("");

  // Sync selected cafe if prop changes
  useEffect(() => {
    const found = cafes.find(c => c.id === activeCafeId);
    if (found) setSelectedCafe(found);
  }, [activeCafeId, cafes]);

  // If table scan was triggered, jump straight to cafe detail menu
  useEffect(() => {
    if (scannedTableInfo) {
      const targetCafe = cafes.find(c => c.id === scannedTableInfo.cafeId) || cafes[0];
      setSelectedCafe(targetCafe);
      setViewState("cafe_detail");
      setCafeTab("menu");
      setDiningMode("table_scan");
    }
  }, [scannedTableInfo]);

  // Filtered cafes for browsing
  const filteredCafes = cafes.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(browseSearch.toLowerCase()) ||
      c.city.toLowerCase().includes(browseSearch.toLowerCase()) ||
      c.cuisines?.some(cu => cu.toLowerCase().includes(browseSearch.toLowerCase()));
    const matchesCuisine = selectedCuisine === "All" ? true : c.cuisines?.includes(selectedCuisine);
    return matchesSearch && matchesCuisine;
  });

  // Filtered menu items for selected cafe
  const filteredMenuItems = (selectedCafe.menuItems || []).filter(item => {
    const matchesCat = activeCategory === "all" ? true : item.categoryId === activeCategory;
    const matchesDiet = dietaryFilter === "all" ? true : item.dietary === dietaryFilter;
    const matchesSearch = item.name.toLowerCase().includes(menuSearch.toLowerCase()) ||
      item.description.toLowerCase().includes(menuSearch.toLowerCase());
    return matchesCat && matchesDiet && matchesSearch;
  }).sort((a, b) => {
    if (sortBy === "price_low") return a.price - b.price;
    if (sortBy === "price_high") return b.price - a.price;
    return (b.popular ? 1 : 0) - (a.popular ? 1 : 0);
  });

  // Open Food Customizer Modal
  const handleOpenFoodItem = (item) => {
    setSelectedFoodItem(item);
    setModalQuantity(1);
    setSelectedAddons([]);
    // Default single choice if exists
    const singleOption = item.customizations?.find(c => c.type === "single");
    setSingleChoiceOption(singleOption?.options?.[0]?.name || "");
  };

  // Add Item to Cart
  const handleAddToCart = () => {
    if (!selectedFoodItem) return;

    let calculatedUnitPrice = selectedFoodItem.discountedPrice || selectedFoodItem.price;

    // Add cost of selected add-ons
    selectedAddons.forEach(addon => {
      calculatedUnitPrice += (addon.price || 0);
    });

    const itemOptions = [
      ...(singleChoiceOption ? [singleChoiceOption] : []),
      ...selectedAddons.map(a => a.name + (a.price > 0 ? ` (+₹${Math.round(a.price)})` : ""))
    ];

    const cartItem = {
      cartId: `cart-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      itemId: selectedFoodItem.id,
      name: selectedFoodItem.name,
      image: selectedFoodItem.image,
      unitPrice: calculatedUnitPrice,
      quantity: modalQuantity,
      dietary: selectedFoodItem.dietary,
      selectedOptions: itemOptions
    };

    setCart(prevCart => {
      const optKey = itemOptions.slice().sort().join("||");
      const existingIdx = prevCart.findIndex(it => 
        it.itemId === selectedFoodItem.id && 
        (it.selectedOptions || []).slice().sort().join("||") === optKey
      );
      if (existingIdx >= 0) {
        const next = [...prevCart];
        next[existingIdx] = {
          ...next[existingIdx],
          quantity: next[existingIdx].quantity + modalQuantity
        };
        return next;
      }
      return [...prevCart, cartItem];
    });

    const addedItemName = selectedFoodItem.name;
    const addedItemQty = modalQuantity;
    const addedItemImg = selectedFoodItem.image;
    setSelectedFoodItem(null);
    playChime("success");

    setAddedToast({
      name: addedItemName,
      qty: addedItemQty,
      image: addedItemImg
    });
    setTimeout(() => {
      setAddedToast(null);
    }, 4000);
  };

  // Cart Subtotal & Calculations
  const cartSubtotal = cart.reduce((sum, it) => sum + (it.unitPrice * it.quantity), 0);
  let discountAmount = 0;
  if (appliedPromo) {
    if (appliedPromo.discountType === "percentage") {
      discountAmount = (cartSubtotal * appliedPromo.value) / 100;
    } else {
      discountAmount = appliedPromo.value;
    }
  }
  const taxAmount = (cartSubtotal - discountAmount) * 0.08;
  const cartFinalTotal = Math.max(0, cartSubtotal - discountAmount + taxAmount);

  // Copy coupon helper
  const handleCopyCoupon = (code) => {
    navigator.clipboard?.writeText(code);
    setCopiedCoupon(true);
    playChime("success");
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  // Apply Promo Code
  const handleApplyPromo = (codeToApply) => {
    const code = (codeToApply || promoInput).toUpperCase();
    const offer = selectedCafe.offers?.find(o => o.code === code && o.active);
    if (!offer) {
      alert("Invalid or expired promo code.");
      return;
    }
    if (offer.minOrderValue && cartSubtotal < offer.minOrderValue) {
      alert(`This offer requires a minimum order value of ₹${offer.minOrderValue}.`);
      return;
    }
    setAppliedPromo(offer);
    playChime("success");
  };

  // Handle Complete Reservation Submission
  const handleSubmitReservation = (e) => {
    e.preventDefault();
    if (!resCustomerName || !resCustomerPhone) {
      alert("Please provide your name and phone number for the reservation.");
      return;
    }

    const celebrationFee = selectedCelebrationPack ? selectedCelebrationPack.price : 0;
    const totalSetupFee = selectedBaseTableConfig.fee + (resExtraChairs * 50) + celebrationFee;
    const newResId = `RES-${Math.floor(1000 + Math.random() * 9000)}`;

    // Try to match an available table
    const matchedTable = selectedCafe.tables?.find(t => t.status === "available" && t.capacity >= (resPartySize + resExtraChairs)) || selectedCafe.tables?.[0];

    const newReservation = {
      id: newResId,
      customerName: resCustomerName,
      phone: resCustomerPhone,
      email: resCustomerEmail || "guest@aromacloud.com",
      date: resDate,
      time: resTime,
      partySize: Number(resPartySize),
      tableId: matchedTable?.id || "T001",
      tableNumber: matchedTable?.number || "Table Assigned upon Arrival",
      status: "confirmed",
      seatingPreference: resTablePref,
      occasion: resOccasion,
      specialRequests: resSpecialRequests + (selectedCelebrationPack ? ` [Added: ${selectedCelebrationPack.name}]` : ""),
      customSetup: {
        baseTable: selectedBaseTableConfig.name,
        extraChairs: resExtraChairs,
        celebrationPack: selectedCelebrationPack?.name || null,
        setupFee: totalSetupFee
      },
      source: "Customer Online",
      createdAt: new Date().toLocaleString()
    };

    onAddReservation(selectedCafe.id, newReservation);
    setConfirmedReservation(newReservation);
    playChime("success");
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
  };

  // Handle Submit Order
  const handlePlaceOrderSubmit = () => {
    if (cart.length === 0) return;

    const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder = {
      id: orderId,
      tableId: scannedTableInfo ? scannedTableInfo.tableId : (diningMode === "table_scan" ? "T002" : null),
      tableNumber: scannedTableInfo ? scannedTableInfo.tableNumber : (diningMode === "table_scan" ? "Table 2 (Window)" : "Takeaway / Direct"),
      customerName: custName,
      phone: custPhone,
      source: scannedTableInfo ? "Table QR Scan" : "Website Online",
      items: cart.map(it => ({
        name: it.name,
        qty: it.quantity,
        price: it.unitPrice,
        customizations: it.selectedOptions,
        prepared: false
      })),
      subtotal: cartSubtotal,
      discount: discountAmount,
      tax: taxAmount,
      total: cartFinalTotal,
      specialNotes: orderSpecialNotes,
      status: "received", // received -> preparing -> ready -> delivered
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      estimatedMinutes: 20,
      elapsedMinutes: 1,
      paymentMethod: orderPaymentMethod
    };

    onPlaceOrder(selectedCafe.id, newOrder);
    setActiveTrackingOrder(newOrder);
    setCart([]);
    setIsCartOpen(false);
    setCheckoutStep(3); // tracking view
    playChime("success");
    confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
  };

  // Open QR for Reservation Check-In
  const handleOpenCheckinQr = async (res) => {
    setViewingCheckinQr(res);
    const dataUrl = await generateQrDataUrl(`CHECKIN:${selectedCafe.id}:${res.id}:${res.customerName}`);
    setCheckinQrDataUrl(dataUrl);
  };

  return (
    <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "16px" }}>
      {/* ========================================================
          SUB-VIEW 1: BROWSE ALL CAFES (LANDING PAGE)
          ======================================================== */}
      {viewState === "browse" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {/* Hero Banner with Curated Image & Common Signature Palette */}
          <div style={{
            position: "relative",
            borderRadius: "var(--radius-xl)",
            overflow: "hidden",
            minHeight: "260px",
            display: "flex",
            alignItems: "center",
            padding: "36px",
            background: "linear-gradient(rgba(26, 18, 11, 0.72), rgba(26, 18, 11, 0.85)), url('/images/artisan_cafe_ambiance.jpg') center/cover",
            color: "#FFF",
            boxShadow: "var(--shadow-lg)"
          }}>
            <div style={{ maxWidth: "650px", zIndex: 1 }}>
              <span style={{
                background: "var(--cafe-primary)",
                color: "#FFF",
                fontSize: "0.75rem",
                fontWeight: "800",
                padding: "4px 10px",
                borderRadius: "999px",
                letterSpacing: "0.5px"
              }}>
                DISCOVER SPECIALTY ARTISAN CAFÉS
              </span>
              <h1 style={{ fontSize: "2.2rem", color: "#FFF", margin: "12px 0 8px 0", lineHeight: "1.2" }}>
                Reserve Tables & Order From Handcrafted Menus
              </h1>
              <p style={{ fontSize: "0.95rem", color: "rgba(255, 255, 255, 0.85)" }}>
                Experience live table availability, custom seating setups, instant QR dining, and kitchen display updates.
              </p>

              {/* Search Bar */}
              <div style={{
                marginTop: "20px",
                display: "flex",
                background: "#FFF",
                borderRadius: "var(--radius-lg)",
                padding: "6px",
                boxShadow: "0 8px 24px rgba(0, 0, 0, 0.25)",
                alignItems: "center",
                gap: "8px"
              }}>
                <Search size={20} color="#6B5B4E" style={{ marginLeft: "10px" }} />
                <input
                  type="text"
                  placeholder="Search cafés by name, city, or cuisine..."
                  value={browseSearch}
                  onChange={(e) => setBrowseSearch(e.target.value)}
                  style={{
                    border: "none",
                    outline: "none",
                    flex: 1,
                    fontSize: "0.95rem",
                    color: "var(--cafe-text)"
                  }}
                />
              </div>
            </div>
          </div>

          {/* Artisan Quality Promises Strip */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "14px"
          }}>
            {[
              { icon: Coffee, title: "100% Single-Origin", desc: "Small-batch daily house roasted", color: "#C86D27" },
              { icon: Sparkles, title: "48h Cold Ferment", desc: "Artisanal crust & sourdough flour", color: "#D97706" },
              { icon: Calendar, title: "Live Seating & Decor", desc: "Custom celebration table setups", color: "#16A34A" },
              { icon: Clock, title: "15-Min Quick Kitchen", desc: "Live order tracking to table", color: "#2563EB" },
              { icon: Award, title: "4.9★ Gastronomy", desc: "12,500+ happy verified diners", color: "#E11D48" }
            ].map((feat, idx) => {
              const Icon = feat.icon;
              return (
                <div 
                  key={idx}
                  className="glass-card"
                  style={{
                    padding: "14px 16px",
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    borderRadius: "14px"
                  }}
                >
                  <div style={{
                    width: "42px",
                    height: "42px",
                    borderRadius: "12px",
                    background: `${feat.color}15`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: feat.color,
                    flexShrink: 0
                  }}>
                    <Icon size={22} />
                  </div>
                  <div>
                    <div style={{ fontWeight: "800", fontSize: "0.88rem", color: "var(--cafe-text)" }}>{feat.title}</div>
                    <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>{feat.desc}</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Welcome Special Promo Ribbon */}
          <div style={{
            background: "linear-gradient(135deg, #FFF7ED 0%, #FFEDD5 100%)",
            border: "1.5px dashed #F97316",
            borderRadius: "16px",
            padding: "16px 20px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "14px"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
              <div style={{
                width: "44px",
                height: "44px",
                borderRadius: "12px",
                background: "#EA580C",
                color: "#FFF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0
              }}>
                <Flame size={24} />
              </div>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
                  <span style={{ fontWeight: "800", fontSize: "1rem", color: "#9A3412" }}>Special Welcome Offer: Flat 20% OFF</span>
                  <span style={{ background: "#EA580C", color: "#FFF", fontSize: "0.7rem", fontWeight: "800", padding: "2px 8px", borderRadius: "999px" }}>LIMITED TIME</span>
                </div>
                <div style={{ fontSize: "0.82rem", color: "#C2410C", marginTop: "3px" }}>
                  Use coupon code <strong style={{ letterSpacing: "1px", background: "#FFF", padding: "2px 6px", borderRadius: "4px", border: "1px solid #FDBA74" }}>AROMA20</strong> on minimum orders above ₹500
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <button
                type="button"
                onClick={() => handleCopyCoupon("AROMA20")}
                className="btn-secondary"
                style={{
                  padding: "8px 14px",
                  fontSize: "0.82rem",
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  background: "#FFF",
                  borderColor: "#FDBA74",
                  color: "#9A3412"
                }}
              >
                {copiedCoupon ? <CheckCircle2 size={16} color="#16A34A" /> : <Copy size={16} />}
                <span>{copiedCoupon ? "Code Copied!" : "Copy Code"}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedCafe(cafes[0]);
                  setActiveCafeId(cafes[0].id);
                  setViewState("cafe_detail");
                  setCafeTab("menu");
                  handleApplyPromo("AROMA20");
                }}
                className="btn-primary"
                style={{ padding: "8px 16px", fontSize: "0.82rem", background: "#EA580C" }}
              >
                Explore & Apply
              </button>
            </div>
          </div>

          {/* Cuisine Filter Pills */}
          <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "4px" }}>
            {["All", "Artisan Coffee", "Italian", "Bakery", "Continental", "Fast-Casual"].map(cui => (
              <button
                key={cui}
                onClick={() => setSelectedCuisine(cui)}
                style={{
                  padding: "8px 16px",
                  borderRadius: "var(--radius-full)",
                  fontSize: "0.85rem",
                  fontWeight: "700",
                  whiteSpace: "nowrap",
                  background: selectedCuisine === cui ? "var(--cafe-primary)" : "var(--cafe-card)",
                  color: selectedCuisine === cui ? "#FFF" : "var(--cafe-text)",
                  border: "1px solid var(--cafe-border)"
                }}
              >
                {cui}
              </button>
            ))}
          </div>

          {/* All Cafés Cards Grid */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ fontSize: "1.4rem" }}>Featured Franchise Cafés ({filteredCafes.length})</h2>
              <span style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)" }}>Instant Table Booking Available</span>
            </div>

            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
              gap: "24px"
            }}>
              {filteredCafes.map(cafe => (
                <div 
                  key={cafe.id}
                  className="glass-card"
                  style={{
                    overflow: "hidden",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between"
                  }}
                >
                  <div>
                    {/* Thumbnail & Badges */}
                    <div style={{ position: "relative", height: "190px", overflow: "hidden" }}>
                      <img 
                        src={cafe.image} 
                        alt={cafe.name}
                        style={{ width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.3s" }}
                      />
                      <div style={{
                        position: "absolute",
                        top: "12px",
                        left: "12px",
                        background: "rgba(26, 18, 11, 0.75)",
                        backdropFilter: "blur(4px)",
                        color: "#FFF",
                        padding: "3px 8px",
                        borderRadius: "6px",
                        fontSize: "0.75rem",
                        fontWeight: "700"
                      }}>
                        {cafe.priceRange} • {cafe.category}
                      </div>

                      <div style={{
                        position: "absolute",
                        top: "12px",
                        right: "12px",
                        background: "#FFF",
                        color: "#16A34A",
                        padding: "3px 8px",
                        borderRadius: "6px",
                        fontSize: "0.75rem",
                        fontWeight: "800",
                        display: "flex",
                        alignItems: "center",
                        gap: "3px"
                      }}>
                        <Star size={13} fill="#16A34A" /> {cafe.rating} ({cafe.reviewCount})
                      </div>
                    </div>

                    {/* Cafe Info */}
                    <div style={{ padding: "18px 18px 12px 18px" }}>
                      <h3 style={{ fontSize: "1.2rem", marginBottom: "4px" }}>{cafe.name}</h3>
                      <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", display: "flex", alignItems: "center", gap: "4px", marginBottom: "8px" }}>
                        <MapPin size={13} /> {cafe.shopAddress}, {cafe.city}
                      </div>
                      <p style={{ fontSize: "0.82rem", color: "var(--cafe-text-muted)", lineClamp: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                        {cafe.description}
                      </p>

                      {/* Cuisines Tags */}
                      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginTop: "12px" }}>
                        {cafe.cuisines?.map(cui => (
                          <span key={cui} style={{ fontSize: "0.72rem", background: "var(--cafe-card-alt)", border: "1px solid var(--cafe-border-light)", padding: "2px 8px", borderRadius: "4px" }}>
                            {cui}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div style={{
                    padding: "12px 18px 18px 18px",
                    display: "flex",
                    gap: "8px"
                  }}>
                    <button
                      onClick={() => {
                        setSelectedCafe(cafe);
                        setActiveCafeId(cafe.id);
                        setViewState("cafe_detail");
                        setCafeTab("menu");
                      }}
                      className="btn-primary"
                      style={{ flex: 1, padding: "8px", fontSize: "0.82rem" }}
                    >
                      <UtensilsCrossed size={14} /> View Menu
                    </button>

                    <button
                      onClick={() => {
                        setSelectedCafe(cafe);
                        setActiveCafeId(cafe.id);
                        setViewState("cafe_detail");
                        setCafeTab("reserve");
                      }}
                      className="btn-secondary"
                      style={{ flex: 1, padding: "8px", fontSize: "0.82rem" }}
                    >
                      <Calendar size={14} /> Reserve Table
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Verified Foodie Dining Testimonials */}
          <div style={{ marginTop: "12px" }}>
            <div style={{ textAlign: "center", marginBottom: "22px" }}>
              <span style={{
                color: "var(--cafe-primary)",
                fontSize: "0.75rem",
                fontWeight: "800",
                letterSpacing: "1px",
                textTransform: "uppercase"
              }}>
                REAL STORIES FROM REAL DINERS
              </span>
              <h2 style={{ fontSize: "1.6rem", marginTop: "4px" }}>Loved by Over 12,500+ Verified Foodies</h2>
              <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", maxWidth: "560px", margin: "6px auto 0 auto" }}>
                Discover why coffee enthusiasts and food lovers choose AromaCloud partner cafés for artisanal single-origin brews, sourdough bakes, and effortless live table reservations.
              </p>
            </div>

            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
              gap: "20px"
            }}>
              {[
                {
                  name: "Priya Sharma",
                  city: "Bengaluru",
                  rating: 5,
                  cafe: "Aroma Reserve Roastery",
                  dish: "Truffle Porcini Pizza & Flat White",
                  quote: "The sourdough crust here is divine—crispy on the edges, light as air inside! Live table reservation was confirmed instantly with our custom window seating setup.",
                  avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80"
                },
                {
                  name: "Rohan Kapoor",
                  city: "Mumbai",
                  rating: 5,
                  cafe: "Velvet Bean Bistro",
                  dish: "Tagliatelle Carbonara & Espresso Tonic",
                  quote: "Scanning the QR code at our table and receiving live status updates directly on our screen was super smooth. Fast 15-minute kitchen prep and authentic flavors!",
                  avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
                },
                {
                  name: "Ananya & Kabir",
                  city: "New Delhi",
                  rating: 5,
                  cafe: "Aroma Reserve Roastery",
                  dish: "Celebration Pack & Almond Croissants",
                  quote: "Booked a birthday table with the celebration package. The sparkler cake, rose petals, and warm hospitality made our evening truly unforgettable. 10/10!",
                  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                }
              ].map((rev, i) => (
                <div 
                  key={i}
                  className="glass-card"
                  style={{
                    padding: "22px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    borderRadius: "16px"
                  }}
                >
                  <div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
                      <div style={{ display: "flex", gap: "2px" }}>
                        {Array.from({ length: rev.rating }).map((_, si) => (
                          <Star key={si} size={15} fill="#F59E0B" color="#F59E0B" />
                        ))}
                      </div>
                      <span style={{
                        background: "#ECFDF5",
                        color: "#059669",
                        fontSize: "0.7rem",
                        fontWeight: "700",
                        padding: "2px 8px",
                        borderRadius: "999px",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px"
                      }}>
                        <CheckCircle2 size={12} /> Verified Diner
                      </span>
                    </div>

                    <p style={{ fontSize: "0.88rem", color: "var(--cafe-text)", fontStyle: "italic", lineHeight: "1.5", marginBottom: "14px" }}>
                      "{rev.quote}"
                    </p>
                  </div>

                  <div style={{
                    borderTop: "1px solid var(--cafe-border-light)",
                    paddingTop: "12px",
                    display: "flex",
                    alignItems: "center",
                    gap: "12px"
                  }}>
                    <img
                      src={rev.avatar}
                      alt={rev.name}
                      style={{ width: "42px", height: "42px", borderRadius: "50%", objectFit: "cover", border: "2px solid var(--cafe-primary)" }}
                    />
                    <div>
                      <div style={{ fontWeight: "800", fontSize: "0.9rem" }}>{rev.name}</div>
                      <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                        {rev.city} • Ordered <strong style={{ color: "var(--cafe-primary)" }}>{rev.dish}</strong>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Diner Guarantees */}
          <div style={{
            background: "linear-gradient(90deg, #1C120C 0%, #2A170A 100%)",
            color: "#FFF",
            borderRadius: "16px",
            padding: "24px 28px",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: "24px",
            alignItems: "center",
            marginTop: "8px"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
              <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "rgba(200, 109, 39, 0.2)", color: "#FDBA74", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <ShieldCheck size={24} />
              </div>
              <div>
                <div style={{ fontWeight: "800", fontSize: "0.92rem", color: "#FFF" }}>100% Reserved Seating</div>
                <div style={{ fontSize: "0.78rem", color: "rgba(255, 255, 255, 0.7)", marginTop: "2px" }}>Held for your arrival with zero queue wait times</div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
              <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "rgba(22, 163, 74, 0.2)", color: "#86EFAC", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Clock size={24} />
              </div>
              <div>
                <div style={{ fontWeight: "800", fontSize: "0.92rem", color: "#FFF" }}>Express 15-Min Prep</div>
                <div style={{ fontSize: "0.78rem", color: "rgba(255, 255, 255, 0.7)", marginTop: "2px" }}>Live kitchen screen tracking straight to your table</div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
              <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "rgba(217, 119, 6, 0.2)", color: "#FDE68A", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Coffee size={24} />
              </div>
              <div>
                <div style={{ fontWeight: "800", fontSize: "0.92rem", color: "#FFF" }}>Transparent Rupee (₹) Pricing</div>
                <div style={{ fontSize: "0.78rem", color: "rgba(255, 255, 255, 0.7)", marginTop: "2px" }}>Zero hidden commission, direct café menu pricing</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-VIEW 2: CAFE DETAIL PAGE (MENU, RESERVATION, EVENTS)
          ======================================================== */}
      {viewState === "cafe_detail" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {/* Breadcrumb / Back button */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <button
              onClick={() => setViewState("browse")}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                fontSize: "0.85rem",
                color: "var(--cafe-primary)",
                fontWeight: "700"
              }}
            >
              ← Back to All Cafés
            </button>

            {scannedTableInfo && (
              <div style={{
                background: "var(--cafe-primary-light)",
                border: "1px solid var(--cafe-primary)",
                color: "var(--cafe-primary)",
                fontSize: "0.8rem",
                fontWeight: "700",
                padding: "4px 10px",
                borderRadius: "6px"
              }}>
                Direct Table Scan: Table #{scannedTableInfo.tableId}
              </div>
            )}
          </div>

          {/* Cafe Header Banner */}
          <div className="glass-card" style={{ overflow: "hidden" }}>
            <div style={{ position: "relative", height: "220px" }}>
              <img 
                src={selectedCafe.image} 
                alt={selectedCafe.name} 
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
              <div style={{
                position: "absolute",
                inset: 0,
                background: "linear-gradient(to top, rgba(26, 18, 11, 0.9) 0%, rgba(26, 18, 11, 0.2) 60%)"
              }} />

              <div style={{ position: "absolute", bottom: "20px", left: "24px", right: "24px", color: "#FFF" }}>
                <span className="badge badge-primary" style={{ marginBottom: "6px" }}>{selectedCafe.category}</span>
                <h1 style={{ fontSize: "2rem", color: "#FFF" }}>{selectedCafe.name}</h1>
                <div style={{ fontSize: "0.85rem", color: "rgba(255, 255, 255, 0.85)", display: "flex", alignItems: "center", gap: "12px", marginTop: "4px", flexWrap: "wrap" }}>
                  <span><MapPin size={14} style={{ display: "inline" }} /> {selectedCafe.shopAddress}, {selectedCafe.city}</span>
                  <span><Clock size={14} style={{ display: "inline" }} /> {selectedCafe.openHours}</span>
                  <span><Phone size={14} style={{ display: "inline" }} /> {selectedCafe.contactNumber}</span>
                  <span style={{ color: "#F59E0B", fontWeight: "700" }}><Star size={14} fill="#F59E0B" style={{ display: "inline" }} /> {selectedCafe.rating} ({selectedCafe.reviewCount} reviews)</span>
                </div>
              </div>
            </div>

            {/* Navigation Tabs for Cafe */}
            <div style={{
              display: "flex",
              borderTop: "1px solid var(--cafe-border)",
              background: "var(--cafe-card)",
              padding: "4px 16px",
              gap: "12px",
              overflowX: "auto"
            }}>
              {[
                { id: "menu", label: "Menu & Ordering", icon: UtensilsCrossed },
                { id: "reserve", label: "Reserve a Table", icon: Calendar },
                { id: "event", label: "Book Full Event", icon: Sparkles },
                { id: "reviews", label: "Ambiance & Reviews", icon: Star }
              ].map(t => {
                const Icon = t.icon;
                const isTabActive = cafeTab === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setCafeTab(t.id)}
                    style={{
                      padding: "12px 14px",
                      display: "flex",
                      alignItems: "center",
                      gap: "6px",
                      fontSize: "0.9rem",
                      fontWeight: "700",
                      color: isTabActive ? "var(--cafe-primary)" : "var(--cafe-text-muted)",
                      borderBottom: isTabActive ? "3px solid var(--cafe-primary)" : "3px solid transparent",
                      whiteSpace: "nowrap"
                    }}
                  >
                    <Icon size={16} />
                    <span>{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Offers Banner */}
          {selectedCafe.offers && selectedCafe.offers.length > 0 && (
            <div style={{
              background: "linear-gradient(135deg, #FFF7ED 0%, #FFEDD5 100%)",
              border: "1.5px dashed #F97316",
              borderRadius: "14px",
              padding: "14px 20px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "12px"
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <span style={{ fontSize: "1.5rem" }}>🎉</span>
                <div>
                  <div style={{ fontWeight: "800", fontSize: "0.95rem", color: "#9A3412" }}>
                    {selectedCafe.offers[0].title}
                  </div>
                  <div style={{ fontSize: "0.8rem", color: "#C2410C" }}>
                    {selectedCafe.offers[0].description} • Coupon: <strong style={{ background: "#FFF", padding: "1px 6px", borderRadius: "4px", border: "1px solid #FDBA74" }}>{selectedCafe.offers[0].code}</strong>
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <button
                  type="button"
                  onClick={() => handleCopyCoupon(selectedCafe.offers[0].code)}
                  className="btn-secondary"
                  style={{
                    padding: "6px 12px",
                    fontSize: "0.8rem",
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                    background: "#FFF",
                    borderColor: "#FDBA74",
                    color: "#9A3412"
                  }}
                >
                  {copiedCoupon ? <CheckCircle2 size={14} color="#16A34A" /> : <Copy size={14} />}
                  <span>{copiedCoupon ? "Copied" : "Copy"}</span>
                </button>
                <button
                  onClick={() => handleApplyPromo(selectedCafe.offers[0].code)}
                  className="btn-primary"
                  style={{ padding: "6px 14px", fontSize: "0.8rem", background: "#EA580C" }}
                >
                  Apply Coupon
                </button>
              </div>
            </div>
          )}

          {/* TAB 1: MENU BROWSING & ITEM CARDS */}
          {cafeTab === "menu" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              {/* Chef's Signature Spotlight of the Day */}
              {selectedCafe.menu && selectedCafe.menu.length > 0 && (() => {
                const spotlightItem = selectedCafe.menu.find(i => i.popular) || selectedCafe.menu[0];
                if (!spotlightItem) return null;
                const isVeg = spotlightItem.dietary === "veg" || spotlightItem.dietary === "vegan";
                return (
                  <div style={{
                    background: "linear-gradient(135deg, #1C120C 0%, #2E1B10 100%)",
                    borderRadius: "18px",
                    padding: "24px",
                    color: "#FFF",
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
                    gap: "24px",
                    alignItems: "center",
                    boxShadow: "0 10px 25px -5px rgba(28, 18, 12, 0.4)",
                    border: "1px solid rgba(200, 109, 39, 0.3)",
                    position: "relative",
                    overflow: "hidden"
                  }}>
                    {/* Decorative glow */}
                    <div style={{
                      position: "absolute",
                      right: "-50px",
                      top: "-50px",
                      width: "200px",
                      height: "200px",
                      borderRadius: "50%",
                      background: "radial-gradient(circle, rgba(200, 109, 39, 0.25) 0%, transparent 70%)",
                      pointerEvents: "none"
                    }} />

                    {/* Left Info Column */}
                    <div style={{ zIndex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                        <span style={{
                          background: "linear-gradient(90deg, #F59E0B, #EA580C)",
                          color: "#FFF",
                          fontSize: "0.72rem",
                          fontWeight: "800",
                          padding: "3px 10px",
                          borderRadius: "999px",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "4px"
                        }}>
                          <Sparkles size={12} /> CHEF'S SIGNATURE CREATION
                        </span>
                        <span style={{
                          background: "rgba(255,255,255,0.15)",
                          color: "#FFEDD5",
                          fontSize: "0.72rem",
                          fontWeight: "700",
                          padding: "3px 8px",
                          borderRadius: "6px"
                        }}>
                          #1 Most Loved
                        </span>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "6px 0 10px 0" }}>
                        <div style={{
                          width: "20px",
                          height: "20px",
                          border: `2px solid ${isVeg ? "#22C55E" : "#EF4444"}`,
                          borderRadius: "4px",
                          background: "#FFF",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          boxShadow: "0 1px 3px rgba(0,0,0,0.3)"
                        }}>
                          <div style={{
                            width: "8px",
                            height: "8px",
                            borderRadius: isVeg ? "50%" : "2px",
                            background: isVeg ? "#22C55E" : "#EF4444"
                          }} />
                        </div>
                        <h3 style={{ fontSize: "1.5rem", color: "#FFF", margin: 0, fontWeight: "800" }}>{spotlightItem.name}</h3>
                      </div>

                      <p style={{ fontSize: "0.88rem", color: "rgba(255, 255, 255, 0.8)", margin: "0 0 14px 0", lineHeight: "1.5" }}>
                        {spotlightItem.description}
                      </p>

                      <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "16px", flexWrap: "wrap", fontSize: "0.82rem", color: "#FDE68A" }}>
                        <span>⏱️ Fresh Oven Prep: ~{spotlightItem.prepTimeMins} mins</span>
                        <span>🔥 {spotlightItem.calories} kcal</span>
                        <span>⭐ 4.98 Guest Rating</span>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                        <div>
                          <div style={{ fontSize: "0.72rem", color: "rgba(255, 255, 255, 0.6)", textTransform: "uppercase" }}>Special Diner Price</div>
                          <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
                            <span style={{ fontSize: "1.7rem", fontWeight: "900", color: "#FDBA74" }}>
                              ₹{Math.round(spotlightItem.discountedPrice || spotlightItem.price)}
                            </span>
                            {spotlightItem.discountedPrice && (
                              <span style={{ fontSize: "0.95rem", textDecoration: "line-through", color: "rgba(255, 255, 255, 0.5)" }}>
                                ₹{Math.round(spotlightItem.price)}
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          onClick={() => handleOpenFoodItem(spotlightItem)}
                          className="btn-primary"
                          style={{
                            padding: "11px 20px",
                            fontSize: "0.9rem",
                            fontWeight: "800",
                            borderRadius: "12px",
                            boxShadow: "0 4px 18px rgba(200, 109, 39, 0.5)"
                          }}
                        >
                          <Plus size={18} /> Select & Customize
                        </button>
                      </div>
                    </div>

                    {/* Right Dish Image */}
                    <div style={{ position: "relative", height: "200px", borderRadius: "14px", overflow: "hidden", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", border: "2px solid rgba(255,255,255,0.15)" }}>
                      <img
                        src={spotlightItem.image}
                        alt={spotlightItem.name}
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                      <div style={{
                        position: "absolute",
                        bottom: "10px",
                        right: "10px",
                        background: "rgba(0,0,0,0.75)",
                        backdropFilter: "blur(4px)",
                        color: "#FDE68A",
                        padding: "3px 8px",
                        borderRadius: "6px",
                        fontSize: "0.72rem",
                        fontWeight: "700"
                      }}>
                        Handcrafted Fresh to Order
                      </div>
                    </div>
                  </div>
                );
              })()}
              {/* Category Pills & Filters */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
                {/* Horizontal Category Tabs */}
                <div style={{ display: "flex", gap: "8px", overflowX: "auto", flex: 1 }}>
                  <button
                    onClick={() => setActiveCategory("all")}
                    style={{
                      padding: "8px 14px",
                      borderRadius: "var(--radius-full)",
                      fontSize: "0.82rem",
                      fontWeight: "700",
                      whiteSpace: "nowrap",
                      background: activeCategory === "all" ? "var(--cafe-espresso)" : "var(--cafe-card)",
                      color: activeCategory === "all" ? "#FFF" : "var(--cafe-text)",
                      border: "1px solid var(--cafe-border)"
                    }}
                  >
                    All Items
                  </button>
                  {selectedCafe.menuCategories?.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      style={{
                        padding: "8px 14px",
                        borderRadius: "var(--radius-full)",
                        fontSize: "0.82rem",
                        fontWeight: "700",
                        whiteSpace: "nowrap",
                        background: activeCategory === cat.id ? "var(--cafe-primary)" : "var(--cafe-card)",
                        color: activeCategory === cat.id ? "#FFF" : "var(--cafe-text)",
                        border: "1px solid var(--cafe-border)"
                      }}
                    >
                      {cat.icon} {cat.name}
                    </button>
                  ))}
                </div>

                {/* Dietary Filter */}
                <div style={{ display: "flex", gap: "6px" }}>
                  {["all", "veg", "vegan", "non-veg"].map(diet => (
                    <button
                      key={diet}
                      onClick={() => setDietaryFilter(diet)}
                      style={{
                        padding: "6px 10px",
                        borderRadius: "6px",
                        fontSize: "0.78rem",
                        fontWeight: "700",
                        textTransform: "capitalize",
                        background: dietaryFilter === diet ? "var(--cafe-border-light)" : "transparent",
                        border: "1px solid var(--cafe-border)",
                        color: dietaryFilter === diet ? "var(--cafe-primary)" : "var(--cafe-text-muted)"
                      }}
                    >
                      {diet === "all" ? "All Diets" : diet}
                    </button>
                  ))}
                </div>
              </div>

              {/* Menu Grid */}
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(310px, 1fr))",
                gap: "20px"
              }}>
                {filteredMenuItems.map(item => (
                  <div 
                    key={item.id}
                    className="glass-card"
                    style={{
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between"
                    }}
                  >
                    <div>
                      {/* Dish Photo */}
                      <div style={{ position: "relative", height: "180px" }}>
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          style={{ width: "100%", height: "100%", objectFit: "cover" }}
                        />
                        <div style={{ position: "absolute", top: "10px", left: "10px", display: "flex", gap: "6px", alignItems: "center" }}>
                          <div style={{
                            width: "20px",
                            height: "20px",
                            border: `2px solid ${item.dietary === "veg" || item.dietary === "vegan" ? "#16A34A" : "#DC2626"}`,
                            borderRadius: "4px",
                            background: "#FFF",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            boxShadow: "0 2px 5px rgba(0,0,0,0.25)"
                          }}>
                            <div style={{
                              width: "8px",
                              height: "8px",
                              borderRadius: item.dietary === "veg" || item.dietary === "vegan" ? "50%" : "2px",
                              background: item.dietary === "veg" || item.dietary === "vegan" ? "#16A34A" : "#DC2626"
                            }} />
                          </div>
                          <span className={`badge ${item.dietary === "veg" ? "badge-veg" : item.dietary === "vegan" ? "badge-vegan" : "badge-nonveg"}`} style={{ textTransform: "uppercase", fontSize: "0.7rem", fontWeight: "800" }}>
                            {item.dietary === "veg" ? "Veg" : item.dietary === "vegan" ? "Vegan" : "Non-Veg"}
                          </span>
                          {item.spiceLevel !== "mild" && (
                            <span style={{ background: "rgba(0,0,0,0.7)", color: "#FFF", padding: "2px 6px", borderRadius: "4px", fontSize: "0.7rem", fontWeight: "700" }}>
                              🌶️ {item.spiceLevel}
                            </span>
                          )}
                        </div>

                        {item.popular && (
                          <div style={{ position: "absolute", top: "10px", right: "10px" }}>
                            <span className="badge badge-primary">CHEF'S PICK</span>
                          </div>
                        )}
                      </div>

                      <div style={{ padding: "16px" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                          <h4 style={{ fontSize: "1.1rem" }}>{item.name}</h4>
                          <div style={{ textAlign: "right" }}>
                            {item.discountedPrice ? (
                              <div>
                                <span style={{ fontWeight: "800", fontSize: "1.15rem", color: "var(--cafe-primary)" }}>
                                  ₹{Math.round(item.discountedPrice)}
                                </span>
                                <div style={{ fontSize: "0.78rem", textDecoration: "line-through", color: "var(--cafe-text-muted)" }}>
                                  ₹{Math.round(item.price)}
                                </div>
                              </div>
                            ) : (
                              <span style={{ fontWeight: "800", fontSize: "1.15rem", color: "var(--cafe-primary)" }}>
                                ₹{Math.round(item.price)}
                              </span>
                            )}
                          </div>
                        </div>

                        <p style={{ fontSize: "0.82rem", color: "var(--cafe-text-muted)", margin: "6px 0 12px 0", lineClamp: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                          {item.description}
                        </p>

                        <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                          ⏱️ ~{item.prepTimeMins} mins • {item.calories} kcal
                        </div>
                      </div>
                    </div>

                    <div style={{ padding: "0 16px 16px 16px", display: "flex", gap: "8px" }}>
                      <button
                        onClick={() => handleOpenFoodItem(item)}
                        className="btn-primary"
                        style={{ width: "100%", padding: "9px", fontSize: "0.85rem" }}
                      >
                        <Plus size={15} /> Select & Add to Order
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: TABLE RESERVATION SYSTEM */}
          {cafeTab === "reserve" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
              {!confirmedReservation ? (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))", gap: "24px" }}>
                  {/* Left: Reservation Details Form */}
                  <div className="glass-card" style={{ padding: "24px" }}>
                    <h3 style={{ fontSize: "1.2rem", marginBottom: "4px" }}>Book a Table at {selectedCafe.name}</h3>
                    <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", marginBottom: "20px" }}>
                      Guaranteed seating with live table floor confirmation.
                    </p>

                    <form onSubmit={handleSubmitReservation} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                      {/* Date & Time Picker */}
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                        <div className="form-group">
                          <label className="form-label">Reservation Date <span className="req">*</span></label>
                          <input
                            type="date"
                            required
                            min="2026-10-19"
                            value={resDate}
                            onChange={(e) => setResDate(e.target.value)}
                            className="form-input"
                          />
                        </div>

                        <div className="form-group">
                          <label className="form-label">Time Slot <span className="req">*</span></label>
                          <select
                            value={resTime}
                            onChange={(e) => setResTime(e.target.value)}
                            className="form-select"
                          >
                            <option value="12:00">12:00 PM (Lunch)</option>
                            <option value="13:30">01:30 PM</option>
                            <option value="17:30">05:30 PM (Early Dinner)</option>
                            <option value="19:00">07:00 PM (Prime)</option>
                            <option value="20:30">08:30 PM</option>
                            <option value="21:30">09:30 PM (Late Night)</option>
                          </select>
                        </div>
                      </div>

                      {/* Party Size & Table Preference */}
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                        <div className="form-group">
                          <label className="form-label">Party Size <span className="req">*</span></label>
                          <select
                            value={resPartySize}
                            onChange={(e) => setResPartySize(Number(e.target.value))}
                            className="form-select"
                          >
                            {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16].map(n => (
                              <option key={n} value={n}>{n} Guests</option>
                            ))}
                          </select>
                        </div>

                        <div className="form-group">
                          <label className="form-label">Table Preference</label>
                          <select
                            value={resTablePref}
                            onChange={(e) => setResTablePref(e.target.value)}
                            className="form-select"
                          >
                            <option value="Near Window">Near Window (Street View)</option>
                            <option value="Corner/Quiet Area">Corner / Quiet Nook</option>
                            <option value="Outdoor Patio">Outdoor Patio</option>
                            <option value="VIP Area">VIP Dining Area</option>
                            <option value="Any Available">Any Available Table</option>
                          </select>
                        </div>
                      </div>

                      {/* Special Occasion */}
                      <div className="form-group">
                        <label className="form-label">Special Occasion</label>
                        <select
                          value={resOccasion}
                          onChange={(e) => setResOccasion(e.target.value)}
                          className="form-select"
                        >
                          <option value="Dining">Regular Casual Dining</option>
                          <option value="Birthday">Birthday Celebration 🎂</option>
                          <option value="Anniversary">Anniversary Romance 🥂</option>
                          <option value="Business Meeting">Business Meeting 💼</option>
                          <option value="Romantic Date">Romantic Date ❤️</option>
                          <option value="Family Reunion">Family Gathering 👨‍👩‍👧‍👦</option>
                        </select>
                      </div>

                      {/* Celebration Add-On Packages */}
                      <div className="form-group">
                        <label className="form-label">
                          <span>Enhance Your Experience (Optional Celebration Pack)</span>
                        </label>
                        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                          {CELEBRATION_PACKS.map(pack => {
                            const isChosen = selectedCelebrationPack?.id === pack.id;
                            return (
                              <div
                                key={pack.id}
                                onClick={() => setSelectedCelebrationPack(isChosen ? null : pack)}
                                style={{
                                  border: `1.5px solid ${isChosen ? "var(--cafe-primary)" : "var(--cafe-border-light)"}`,
                                  background: isChosen ? "var(--cafe-primary-light)" : "var(--cafe-card-alt)",
                                  padding: "8px 12px",
                                  borderRadius: "8px",
                                  cursor: "pointer",
                                  display: "flex",
                                  justifyContent: "space-between",
                                  alignItems: "center"
                                }}
                              >
                                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                  <span style={{ fontSize: "1.1rem" }}>{pack.icon}</span>
                                  <div>
                                    <div style={{ fontWeight: "700", fontSize: "0.85rem" }}>{pack.name}</div>
                                    <div style={{ fontSize: "0.72rem", color: "var(--cafe-text-muted)" }}>{pack.description}</div>
                                  </div>
                                </div>
                                <div style={{ fontWeight: "800", color: "var(--cafe-primary)", fontSize: "0.85rem" }}>
                                  +{formatPrice(pack.price, currency)}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Special Requests (max 250 chars)</label>
                        <textarea
                          rows="2"
                          maxLength={250}
                          placeholder="e.g. Need high chair for baby, surprise anniversary dessert..."
                          value={resSpecialRequests}
                          onChange={(e) => setResSpecialRequests(e.target.value)}
                          className="form-textarea"
                        />
                      </div>

                      {/* Contact Info */}
                      <div style={{ borderTop: "1px solid var(--cafe-border)", paddingTop: "12px" }}>
                        <div style={{ fontWeight: "700", fontSize: "0.9rem", marginBottom: "8px" }}>
                          Primary Guest Information
                        </div>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                          <input
                            type="text"
                            required
                            placeholder="Your Full Name *"
                            value={resCustomerName}
                            onChange={(e) => setResCustomerName(e.target.value)}
                            className="form-input"
                          />
                          <input
                            type="tel"
                            required
                            placeholder="Mobile (for SMS update) *"
                            value={resCustomerPhone}
                            onChange={(e) => setResCustomerPhone(e.target.value)}
                            className="form-input"
                          />
                        </div>
                      </div>

                      <button type="submit" className="btn-primary" style={{ marginTop: "10px", padding: "12px" }}>
                        <Sparkles size={18} /> Confirm Table Reservation
                      </button>
                    </form>
                  </div>

                  {/* Right: Table Customization & Visual Seating Diagram */}
                  <div className="glass-card" style={{ padding: "24px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                    <div>
                      <h3 style={{ fontSize: "1.2rem", marginBottom: "4px" }}>Interactive Table Customization</h3>
                      <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", marginBottom: "16px" }}>
                        Select standard layout configuration and add optional extra seating chairs.
                      </p>

                      {/* Base Table Selectors */}
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "16px" }}>
                        {[
                          { name: "2-seater table", baseCapacity: 2, fee: 150 },
                          { name: "4-seater table", baseCapacity: 4, fee: 200 },
                          { name: "6-seater table", baseCapacity: 6, fee: 300 },
                          { name: "8-seater table", baseCapacity: 8, fee: 400 }
                        ].map(config => {
                          const isSel = selectedBaseTableConfig.name === config.name;
                          return (
                            <button
                              key={config.name}
                              type="button"
                              onClick={() => setSelectedBaseTableConfig(config)}
                              style={{
                                padding: "12px",
                                borderRadius: "var(--radius-md)",
                                border: `2px solid ${isSel ? "var(--cafe-primary)" : "var(--cafe-border)"}`,
                                background: isSel ? "var(--cafe-primary-light)" : "var(--cafe-card-alt)",
                                textAlign: "left",
                                cursor: "pointer"
                              }}
                            >
                              <div style={{ fontWeight: "700", fontSize: "0.9rem", color: isSel ? "var(--cafe-primary)" : "var(--cafe-text)" }}>
                                {config.name}
                              </div>
                              <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>
                                Setup fee: ₹{config.fee}
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {/* Extra Chairs Customization Adder */}
                      <div style={{
                        background: "var(--cafe-card-alt)",
                        padding: "14px",
                        borderRadius: "var(--radius-md)",
                        border: "1px solid var(--cafe-border)",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: "20px"
                      }}>
                        <div>
                          <div style={{ fontWeight: "700", fontSize: "0.9rem" }}>Add Extra Chairs (+₹50/chair)</div>
                          <div style={{ fontSize: "0.78rem", color: "var(--cafe-text-muted)" }}>
                            Flexibility for sudden guests or baby carriers
                          </div>
                        </div>

                        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                          <button
                            type="button"
                            onClick={() => setResExtraChairs(Math.max(0, resExtraChairs - 1))}
                            style={{ width: "32px", height: "32px", borderRadius: "50%", border: "1px solid var(--cafe-border)", background: "#FFF", display: "flex", alignItems: "center", justifyContent: "center" }}
                          >
                            <Minus size={14} />
                          </button>
                          <span style={{ fontWeight: "800", fontSize: "1.1rem" }}>{resExtraChairs}</span>
                          <button
                            type="button"
                            onClick={() => setResExtraChairs(Math.min(4, resExtraChairs + 1))}
                            style={{ width: "32px", height: "32px", borderRadius: "50%", border: "1px solid var(--cafe-border)", background: "#FFF", display: "flex", alignItems: "center", justifyContent: "center" }}
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>

                      {/* Visual Table Diagram SVG */}
                      <div style={{
                        background: "var(--cafe-bg)",
                        border: "1px dashed var(--cafe-border)",
                        borderRadius: "var(--radius-lg)",
                        padding: "20px",
                        textAlign: "center"
                      }}>
                        <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginBottom: "10px", fontWeight: "600" }}>
                          VISUAL SEATING ARRANGEMENT ({selectedBaseTableConfig.baseCapacity + resExtraChairs} TOTAL SEATS)
                        </div>

                        <svg width="240" height="150" viewBox="0 0 240 150" style={{ margin: "0 auto", display: "block" }}>
                          {/* Central Table Slab */}
                          <rect x="60" y="45" width="120" height="60" rx="12" fill="#C86D27" opacity="0.9" />
                          <text x="120" y="80" textAnchor="middle" fill="#FFFFFF" fontWeight="700" fontSize="12">
                            {selectedBaseTableConfig.name}
                          </text>

                          {/* Base Chairs (Top & Bottom) */}
                          {Array.from({ length: selectedBaseTableConfig.baseCapacity }).map((_, i) => {
                            const isTop = i < selectedBaseTableConfig.baseCapacity / 2;
                            const idx = isTop ? i : i - selectedBaseTableConfig.baseCapacity / 2;
                            const countRow = selectedBaseTableConfig.baseCapacity / 2;
                            const x = 75 + (idx * (90 / Math.max(1, countRow - 1 || 1)));
                            const y = isTop ? 22 : 128;
                            return (
                              <circle key={i} cx={x} cy={y} r="10" fill="#1A120B" stroke="#C86D27" strokeWidth="2" />
                            );
                          })}

                          {/* Extra Custom Chairs (Left & Right Flanks) */}
                          {Array.from({ length: resExtraChairs }).map((_, i) => {
                            const x = i % 2 === 0 ? 35 : 205;
                            const y = i < 2 ? 60 : 90;
                            return (
                              <circle key={`extra-${i}`} cx={x} cy={y} r="10" fill="#16A34A" stroke="#FFFFFF" strokeWidth="2" />
                            );
                          })}
                        </svg>

                        <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)", marginTop: "8px" }}>
                          <span style={{ display: "inline-block", width: "8px", height: "8px", borderRadius: "50%", background: "#1A120B", marginRight: "4px" }} /> Standard Seat •
                          <span style={{ display: "inline-block", width: "8px", height: "8px", borderRadius: "50%", background: "#16A34A", margin: "0 4px 0 8px" }} /> Extra Customized Seat
                        </div>
                      </div>
                    </div>

                    {/* Breakdown Cost */}
                    <div style={{
                      marginTop: "20px",
                      paddingTop: "14px",
                      borderTop: "1px solid var(--cafe-border)",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center"
                    }}>
                      <div>
                        <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>Total Setup Fee:</div>
                        <div style={{ fontSize: "0.75rem", color: "var(--cafe-text-muted)" }}>
                          Base {formatPrice(selectedBaseTableConfig.fee, currency)} + {formatPrice(resExtraChairs * 50, currency)} ({resExtraChairs} chairs) {selectedCelebrationPack ? `+ ${formatPrice(selectedCelebrationPack.price, currency)} (${selectedCelebrationPack.name})` : ""}
                        </div>
                      </div>
                      <div style={{ fontSize: "1.4rem", fontWeight: "800", color: "var(--cafe-primary)" }}>
                        {formatPrice(selectedBaseTableConfig.fee + (resExtraChairs * 50) + (selectedCelebrationPack ? selectedCelebrationPack.price : 0), currency)}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* CONFIRMATION SCREEN */
                <div className="glass-card" style={{ maxWidth: "680px", margin: "0 auto", padding: "36px", textAlign: "center" }}>
                  <div style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    background: "#DCFCE7",
                    color: "#16A34A",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 16px auto"
                  }}>
                    <Check size={32} />
                  </div>

                  <h2 style={{ fontSize: "1.8rem", marginBottom: "8px" }}>Reservation Confirmed!</h2>
                  <p style={{ fontSize: "0.95rem", color: "var(--cafe-text-muted)", marginBottom: "20px" }}>
                    Your table is booked at <strong>{selectedCafe.name}</strong>. An automated confirmation SMS has been dispatched to <strong>{confirmedReservation.phone}</strong>.
                  </p>

                  <div style={{
                    background: "var(--cafe-card-alt)",
                    border: "1px solid var(--cafe-border)",
                    borderRadius: "var(--radius-lg)",
                    padding: "20px",
                    textAlign: "left",
                    marginBottom: "24px"
                  }}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", fontSize: "0.9rem" }}>
                      <div>Reservation ID: <strong>{confirmedReservation.id}</strong></div>
                      <div>Date & Time: <strong>{confirmedReservation.date} at {confirmedReservation.time}</strong></div>
                      <div>Party Size: <strong>{confirmedReservation.partySize} Guests</strong></div>
                      <div>Table Assigned: <strong style={{ color: "var(--cafe-primary)" }}>{confirmedReservation.tableNumber}</strong></div>
                      <div>Occasion: <strong>{confirmedReservation.occasion}</strong></div>
                      <div>Setup Fee: <strong>₹{confirmedReservation.customSetup.setupFee}</strong></div>
                    </div>
                  </div>

                  <div style={{ display: "flex", justifyContent: "center", gap: "12px", flexWrap: "wrap" }}>
                    <button
                      onClick={() => generateIcsFile(confirmedReservation, selectedCafe)}
                      className="btn-primary"
                    >
                      <Download size={16} /> Add to Calendar (.ICS)
                    </button>

                    <button
                      onClick={() => handleOpenCheckinQr(confirmedReservation)}
                      className="btn-secondary"
                    >
                      <QrCode size={16} /> View Check-In QR
                    </button>

                    <button
                      onClick={() => setConfirmedReservation(null)}
                      className="btn-secondary"
                    >
                      Book Another Table
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BOOK FULL RESTAURANT FOR EVENT */}
          {cafeTab === "event" && (
            <div className="glass-card" style={{ maxWidth: "780px", margin: "0 auto", padding: "32px" }}>
              <div style={{ textAlign: "center", marginBottom: "24px" }}>
                <span className="badge badge-primary">FULL BUYOUT & PRIVATE BANQUETS</span>
                <h2 style={{ fontSize: "1.8rem", marginTop: "8px" }}>Book Entire Restaurant for Your Event</h2>
                <p style={{ fontSize: "0.9rem", color: "var(--cafe-text-muted)" }}>
                  Corporate receptions, wedding banquets, private product launches, and birthday galas.
                </p>
              </div>

              {evtSuccessMessage ? (
                <div style={{ textAlign: "center", padding: "40px" }}>
                  <Check size={48} color="#16A34A" style={{ margin: "0 auto 12px auto" }} />
                  <h3 style={{ fontSize: "1.4rem" }}>Event Quote Request Dispatched!</h3>
                  <p style={{ fontSize: "0.9rem", color: "var(--cafe-text-muted)", marginTop: "6px" }}>
                    {selectedCafe.ownerName} and the event management team will review your requirements and provide a customized buyout proposal within 24 hours.
                  </p>
                  <button onClick={() => setEvtSuccessMessage(false)} className="btn-secondary" style={{ marginTop: "20px" }}>
                    Submit Another Inquiry
                  </button>
                </div>
              ) : (
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    setEvtSuccessMessage(true);
                    playChime("success");
                    confetti();
                  }}
                  style={{ display: "flex", flexDirection: "column", gap: "16px" }}
                >
                  <div className="form-group">
                    <label className="form-label">Event Name / Occasion <span className="req">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Design Studio Annual Autumn Banquet"
                      value={evtName}
                      onChange={(e) => setEvtName(e.target.value)}
                      className="form-input"
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <div className="form-group">
                      <label className="form-label">Event Date <span className="req">*</span></label>
                      <input
                        type="date"
                        required
                        value={evtDate}
                        onChange={(e) => setEvtDate(e.target.value)}
                        className="form-input"
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Time Window <span className="req">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 18:00 - 23:00"
                        value={evtTimeRange}
                        onChange={(e) => setEvtTimeRange(e.target.value)}
                        className="form-input"
                      />
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <div className="form-group">
                      <label className="form-label">Expected Guest Count <span className="req">*</span></label>
                      <input
                        type="number"
                        min="20"
                        max="250"
                        value={evtGuests}
                        onChange={(e) => setEvtGuests(Number(e.target.value))}
                        className="form-input"
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Target Budget Range</label>
                      <input
                        type="text"
                        placeholder="e.g. ₹30,000 - ₹50,000"
                        value={evtBudget}
                        onChange={(e) => setEvtBudget(e.target.value)}
                        className="form-input"
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Special Requirements & Audio/Visual Needs</label>
                    <textarea
                      rows="3"
                      placeholder="Wireless microphone, cocktail bar setup, special dietary catering, acoustic jazz requirements..."
                      value={evtRequirements}
                      onChange={(e) => setEvtRequirements(e.target.value)}
                      className="form-textarea"
                    />
                  </div>

                  <button type="submit" className="btn-primary" style={{ padding: "12px" }}>
                    <Sparkles size={16} /> Submit Event for Custom Quote Approval
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 4: REVIEWS & GALLERY */}
          {cafeTab === "reviews" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
              {/* Ambiance Gallery */}
              <div className="glass-card" style={{ padding: "20px" }}>
                <h3 style={{ fontSize: "1.2rem", marginBottom: "12px" }}>Café Ambiance Gallery</h3>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "14px" }}>
                  {selectedCafe.gallery?.map((img, i) => (
                    <img
                      key={i}
                      src={img}
                      alt={`Ambiance ${i + 1}`}
                      style={{ width: "100%", height: "200px", objectFit: "cover", borderRadius: "var(--radius-md)" }}
                    />
                  ))}
                </div>
              </div>

              {/* Verified Reviews */}
              <div className="glass-card" style={{ padding: "20px" }}>
                <h3 style={{ fontSize: "1.2rem", marginBottom: "14px" }}>Customer Reviews & Experiences</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                  {[
                    { name: "Julian Vance", rating: 5, date: "3 days ago", comment: "The truffle mushroom pizza crust was otherworldly! The table QR ordering was instantaneous." },
                    { name: "Claire Chen", rating: 5, date: "1 week ago", comment: "Customized a 4-seater with 2 extra chairs for my daughter's birthday. Perfect service and cozy corner seating!" }
                  ].map((rev, i) => (
                    <div key={i} style={{ padding: "12px", background: "var(--cafe-card-alt)", borderRadius: "8px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <strong>{rev.name}</strong>
                        <span style={{ color: "#F59E0B" }}>{"★".repeat(rev.rating)}</span>
                      </div>
                      <div style={{ fontSize: "0.85rem", color: "var(--cafe-text)", marginTop: "4px" }}>{rev.comment}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          MODAL: FOOD DETAILS & ADD-ON CUSTOMIZATION
          ======================================================== */}
      {selectedFoodItem && (
        <div className="modal-overlay" onClick={() => setSelectedFoodItem(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "580px", padding: "24px" }}>
            <div style={{ position: "relative", height: "200px", borderRadius: "12px", overflow: "hidden", marginBottom: "16px" }}>
              <img 
                src={selectedFoodItem.image} 
                alt={selectedFoodItem.name} 
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
              <button 
                onClick={() => setSelectedFoodItem(null)}
                style={{ position: "absolute", top: "10px", right: "10px", background: "#FFF", borderRadius: "50%", width: "32px", height: "32px", display: "flex", alignItems: "center", justifyContent: "center" }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h3 style={{ fontSize: "1.3rem" }}>{selectedFoodItem.name}</h3>
                <span className={`badge ${selectedFoodItem.dietary === "veg" ? "badge-veg" : selectedFoodItem.dietary === "vegan" ? "badge-vegan" : "badge-nonveg"}`} style={{ marginTop: "4px" }}>
                  {selectedFoodItem.dietary}
                </span>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: "1.3rem", fontWeight: "800", color: "var(--cafe-primary)" }}>
                  ₹{Math.round(selectedFoodItem.discountedPrice || selectedFoodItem.price)}
                </div>
                {selectedFoodItem.discountedPrice && (
                  <div style={{ fontSize: "0.85rem", textDecoration: "line-through", color: "var(--cafe-text-muted)" }}>
                    ₹{Math.round(selectedFoodItem.price)}
                  </div>
                )}
              </div>
            </div>

            <p style={{ fontSize: "0.85rem", color: "var(--cafe-text-muted)", margin: "10px 0" }}>
              {selectedFoodItem.description}
            </p>

            {/* Allergens Warning Highlighted in Red */}
            {selectedFoodItem.allergens && selectedFoodItem.allergens.length > 0 && (
              <div style={{
                background: "#FEF2F2",
                border: "1px solid #FECACA",
                color: "#DC2626",
                padding: "8px 12px",
                borderRadius: "8px",
                fontSize: "0.8rem",
                display: "flex",
                alignItems: "center",
                gap: "6px",
                margin: "12px 0"
              }}>
                <AlertCircle size={16} />
                <span><strong>Allergens Warning:</strong> Contains {selectedFoodItem.allergens.join(", ")}</span>
              </div>
            )}

            {/* Nutrition Facts */}
            {selectedFoodItem.nutrition && (
              <div style={{
                background: "var(--cafe-card-alt)",
                padding: "8px 12px",
                borderRadius: "8px",
                fontSize: "0.78rem",
                display: "flex",
                justifyContent: "space-between",
                margin: "10px 0"
              }}>
                <span>Calories: <strong>{selectedFoodItem.calories} kcal</strong></span>
                <span>Protein: <strong>{selectedFoodItem.nutrition.protein}</strong></span>
                <span>Carbs: <strong>{selectedFoodItem.nutrition.carbs}</strong></span>
                <span>Fat: <strong>{selectedFoodItem.nutrition.fat}</strong></span>
              </div>
            )}

            {/* Customizations Section */}
            {selectedFoodItem.customizations?.map((custom) => (
              <div key={custom.id} style={{ margin: "14px 0", borderTop: "1px solid var(--cafe-border)", paddingTop: "10px" }}>
                <div style={{ fontWeight: "700", fontSize: "0.88rem", marginBottom: "8px" }}>
                  {custom.name} {custom.required && <span style={{ color: "#DC2626" }}>*</span>}
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {custom.options?.map((opt, i) => {
                    const isSelected = custom.type === "single" 
                      ? singleChoiceOption === opt.name
                      : selectedAddons.some(a => a.name === opt.name);

                    return (
                      <label key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", cursor: "pointer", padding: "6px 8px", borderRadius: "6px", background: isSelected ? "var(--cafe-primary-light)" : "transparent" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <input
                            type={custom.type === "single" ? "radio" : "checkbox"}
                            name={custom.id}
                            checked={isSelected}
                            onChange={() => {
                              if (custom.type === "single") {
                                setSingleChoiceOption(opt.name);
                              } else {
                                if (isSelected) {
                                  setSelectedAddons(selectedAddons.filter(a => a.name !== opt.name));
                                } else {
                                  setSelectedAddons([...selectedAddons, opt]);
                                }
                              }
                            }}
                          />
                          <span>{opt.name}</span>
                        </div>
                        <span style={{ fontWeight: "700", color: opt.price > 0 ? "var(--cafe-primary)" : "var(--cafe-text-muted)" }}>
                          {opt.price > 0 ? `+₹${Math.round(opt.price)}` : "Included"}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Quantity Selector & Add Button */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <button
                  onClick={() => setModalQuantity(Math.max(1, modalQuantity - 1))}
                  style={{ width: "32px", height: "32px", borderRadius: "50%", border: "1px solid var(--cafe-border)", background: "#FFF", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <Minus size={14} />
                </button>
                <span style={{ fontWeight: "800", fontSize: "1.1rem" }}>{modalQuantity}</span>
                <button
                  onClick={() => setModalQuantity(modalQuantity + 1)}
                  style={{ width: "32px", height: "32px", borderRadius: "50%", border: "1px solid var(--cafe-border)", background: "#FFF", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <Plus size={14} />
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                className="btn-primary"
                style={{ padding: "10px 24px", fontSize: "0.95rem", fontWeight: "700" }}
              >
                Add to Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          SLIDE-OVER SHOPPING CART & CHECKOUT
          ======================================================== */}
      {isCartOpen && (
        <div className="modal-overlay" onClick={() => setIsCartOpen(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "520px", padding: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h3 style={{ fontSize: "1.3rem" }}>
                Your Order ({cart.reduce((c, i) => c + i.quantity, 0)} Items)
              </h3>
              <button onClick={() => setIsCartOpen(false)}>✕</button>
            </div>

            {cart.length === 0 ? (
              <div style={{ textAlign: "center", padding: "40px", color: "var(--cafe-text-muted)" }}>
                <ShoppingBag size={42} style={{ margin: "0 auto 12px auto", opacity: 0.5 }} />
                <p>Your cart is empty. Add delicious dishes from the menu!</p>
              </div>
            ) : (
              <div>
                {/* Dining Mode Selector */}
                <div style={{
                  background: "var(--cafe-card-alt)",
                  padding: "8px",
                  borderRadius: "8px",
                  display: "flex",
                  gap: "6px",
                  marginBottom: "16px"
                }}>
                  {[
                    { id: "table_scan", label: "Dine-In Table" },
                    { id: "pickup", label: "Takeaway Pickup" },
                    { id: "delivery", label: "Delivery" }
                  ].map(m => (
                    <button
                      key={m.id}
                      onClick={() => setDiningMode(m.id)}
                      style={{
                        flex: 1,
                        padding: "6px",
                        fontSize: "0.8rem",
                        borderRadius: "6px",
                        fontWeight: "700",
                        background: diningMode === m.id ? "var(--cafe-primary)" : "transparent",
                        color: diningMode === m.id ? "#FFF" : "var(--cafe-text)"
                      }}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>

                {diningMode === "table_scan" && (
                  <div style={{
                    background: "var(--cafe-primary-light)",
                    border: "1px dashed var(--cafe-primary)",
                    padding: "8px 12px",
                    borderRadius: "6px",
                    fontSize: "0.8rem",
                    color: "var(--cafe-primary)",
                    fontWeight: "700",
                    marginBottom: "14px"
                  }}>
                    📍 Auto-associated with {scannedTableInfo ? scannedTableInfo.tableNumber : "Table 2 (Window)"}
                  </div>
                )}

                {/* Items List */}
                <div style={{ display: "flex", flexDirection: "column", gap: "10px", maxHeight: "280px", overflowY: "auto", marginBottom: "16px" }}>
                  {cart.map((it) => (
                    <div key={it.cartId} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--cafe-border-light)" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px", flex: 1, paddingRight: "10px" }}>
                        <img
                          src={it.image || "/images/artisan_coffee_desserts.jpg"}
                          alt={it.name}
                          style={{
                            width: "44px",
                            height: "44px",
                            borderRadius: "50%",
                            objectFit: "cover",
                            border: "2px solid var(--cafe-border)",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
                            flexShrink: 0
                          }}
                        />
                        <div>
                          <div style={{ fontWeight: "700", fontSize: "0.9rem" }}>{it.name}</div>
                          {it.selectedOptions && it.selectedOptions.length > 0 && (
                            <div style={{ fontSize: "0.75rem", color: "var(--cafe-primary)", marginTop: "2px" }}>
                              {it.selectedOptions.join(", ")}
                            </div>
                          )}
                          <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)", marginTop: "2px" }}>
                            ₹{Math.round(it.unitPrice)} each
                          </div>
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                        <div style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "6px",
                          background: "var(--cafe-card-alt)",
                          border: "1px solid var(--cafe-border)",
                          borderRadius: "20px",
                          padding: "2px 8px"
                        }}>
                          <button
                            type="button"
                            onClick={() => {
                              if (it.quantity <= 1) {
                                setCart(cart.filter(item => item.cartId !== it.cartId));
                              } else {
                                setCart(cart.map(item => item.cartId === it.cartId ? { ...item, quantity: item.quantity - 1 } : item));
                              }
                            }}
                            style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", padding: "2px" }}
                          >
                            <Minus size={12} />
                          </button>
                          <span style={{ fontSize: "0.85rem", fontWeight: "700", minWidth: "16px", textAlign: "center" }}>{it.quantity}</span>
                          <button
                            type="button"
                            onClick={() => {
                              setCart(cart.map(item => item.cartId === it.cartId ? { ...item, quantity: item.quantity + 1 } : item));
                            }}
                            style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", padding: "2px" }}
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <div style={{ fontWeight: "800", color: "var(--cafe-text)", minWidth: "60px", textAlign: "right" }}>
                          ₹{Math.round(it.unitPrice * it.quantity)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Promo Code Input */}
                <div style={{ display: "flex", gap: "8px", marginBottom: "14px" }}>
                  <input
                    type="text"
                    placeholder="Enter Promo Code (e.g. AROMA20)"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    className="form-input"
                    style={{ fontSize: "0.85rem", textTransform: "uppercase" }}
                  />
                  <button onClick={() => handleApplyPromo()} className="btn-secondary" style={{ fontSize: "0.85rem" }}>
                    Apply
                  </button>
                </div>

                {/* Bill Summary */}
                <div style={{ fontSize: "0.85rem", display: "flex", flexDirection: "column", gap: "4px", padding: "10px 0", borderTop: "1px solid var(--cafe-border)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Subtotal:</span>
                    <span>₹{Math.round(cartSubtotal)}</span>
                  </div>
                  {appliedPromo && (
                    <div style={{ display: "flex", justifyContent: "space-between", color: "#16A34A" }}>
                      <span>Discount ({appliedPromo.code}):</span>
                      <span>-₹{Math.round(discountAmount)}</span>
                    </div>
                  )}
                  <div style={{ display: "flex", justifyContent: "space-between", color: "var(--cafe-text-muted)" }}>
                    <span>Taxes & Service (8%):</span>
                    <span>₹{Math.round(taxAmount)}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontWeight: "800", fontSize: "1.1rem", marginTop: "4px" }}>
                    <span>Final Total:</span>
                    <span style={{ color: "var(--cafe-primary)" }}>₹{Math.round(cartFinalTotal)}</span>
                  </div>
                </div>

                {/* Checkout Trigger */}
                <button
                  onClick={handlePlaceOrderSubmit}
                  className="btn-primary"
                  style={{ width: "100%", marginTop: "14px", padding: "12px" }}
                >
                  Place Order • ₹{Math.round(cartFinalTotal)}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          ORDER TRACKING & WHATSAPP ALERT SCREEN (AFTER ORDER)
          ======================================================== */}
      {activeTrackingOrder && checkoutStep === 3 && (
        <div className="modal-overlay" onClick={() => setActiveTrackingOrder(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "560px", padding: "28px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h3 style={{ fontSize: "1.3rem" }}>Live Order Status & Updates</h3>
              <button onClick={() => setActiveTrackingOrder(null)}>✕</button>
            </div>

            {/* Stages Timeline */}
            <div style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              position: "relative",
              margin: "24px 0"
            }}>
              {[
                { stage: "received", label: "Received", icon: "✓" },
                { stage: "preparing", label: "Preparing", icon: "⏳" },
                { stage: "ready", label: "Ready", icon: "🔔" },
                { stage: "delivered", label: "Delivered", icon: "🎉" }
              ].map((st, idx) => {
                const stages = ["received", "preparing", "ready", "delivered"];
                const isCurrent = activeTrackingOrder.status === st.stage;
                const isDone = stages.indexOf(activeTrackingOrder.status) >= idx;

                return (
                  <div key={st.stage} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "6px", zIndex: 1 }}>
                    <div style={{
                      width: "36px",
                      height: "36px",
                      borderRadius: "50%",
                      background: isDone ? "var(--cafe-primary)" : "var(--cafe-card-alt)",
                      border: `2px solid ${isDone ? "var(--cafe-primary)" : "var(--cafe-border)"}`,
                      color: isDone ? "#FFF" : "var(--cafe-text-muted)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontWeight: "800",
                      fontSize: "0.85rem"
                    }}>
                      {st.icon}
                    </div>
                    <span style={{ fontSize: "0.75rem", fontWeight: isCurrent ? "800" : "600", color: isCurrent ? "var(--cafe-primary)" : "var(--cafe-text-muted)" }}>
                      {st.label}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Simulated WhatsApp Card Notification Preview */}
            <div style={{
              background: "#E7F8EC",
              border: "1px solid #A7F3D0",
              borderRadius: "12px",
              padding: "16px",
              marginTop: "20px"
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", color: "#065F46", fontWeight: "700", fontSize: "0.85rem" }}>
                <MessageCircle size={16} /> Instant WhatsApp Order Notification Dispatched
              </div>

              <div style={{
                background: "#FFFFFF",
                borderRadius: "8px",
                padding: "12px",
                marginTop: "10px",
                fontFamily: "monospace",
                fontSize: "0.82rem",
                color: "#1E293B",
                lineHeight: "1.4"
              }}>
                <div>🍕 <strong>Order Confirmed</strong></div>
                <div>Order ID: #{activeTrackingOrder.id}</div>
                <div>From: {selectedCafe.name}</div>
                <div>Items: {activeTrackingOrder.items?.map(i => `${i.qty}x ${i.name}`).join(", ")}</div>
                <div>Total: ₹{Math.round(activeTrackingOrder.total)}</div>
                <div>Estimated Time: {activeTrackingOrder.estimatedMinutes} minutes</div>
              </div>
            </div>

            {/* Live Interactive Action Buttons */}
            <div style={{ marginTop: "20px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "10px" }}>
              <div style={{ display: "flex", gap: "8px" }}>
                {/* Fast forward stage for demo testing */}
                <button
                  onClick={() => {
                    const stages = ["received", "preparing", "ready", "delivered"];
                    const nextIdx = (stages.indexOf(activeTrackingOrder.status) + 1) % stages.length;
                    const nextSt = stages[nextIdx];
                    setActiveTrackingOrder({ ...activeTrackingOrder, status: nextSt });
                    playChime("alert");
                  }}
                  className="btn-secondary"
                  style={{ fontSize: "0.8rem", padding: "6px 10px" }}
                  title="Simulate kitchen progress"
                >
                  ⚡ Fast-Forward Status ({activeTrackingOrder.status} →)
                </button>

                {/* WhatsApp Chat Simulator Button */}
                <button
                  onClick={() => setShowLiveChatModal(true)}
                  style={{
                    background: "#25D366",
                    color: "#FFFFFF",
                    border: "none",
                    borderRadius: "var(--radius-md)",
                    padding: "6px 12px",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    fontSize: "0.8rem",
                    fontWeight: "700",
                    cursor: "pointer"
                  }}
                >
                  <MessageCircle size={15} />
                  <span>Chat with Barista</span>
                </button>
              </div>

              <button onClick={() => setActiveTrackingOrder(null)} className="btn-primary">
                Done & Continue Browsing
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: INTERACTIVE WHATSAPP CHAT WITH BARISTA
          ======================================================== */}
      {showLiveChatModal && (
        <div className="modal-overlay" onClick={() => setShowLiveChatModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "420px", padding: 0, overflow: "hidden", background: "#ECE5DD", borderRadius: "18px" }}>
            {/* WhatsApp Top Green Header */}
            <div style={{
              background: "#075E54",
              color: "#FFF",
              padding: "12px 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between"
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{
                  width: "38px",
                  height: "38px",
                  borderRadius: "50%",
                  background: "var(--cafe-primary)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1.1rem"
                }}>
                  ☕
                </div>
                <div>
                  <div style={{ fontWeight: "700", fontSize: "0.95rem" }}>Barista Luca • {selectedCafe.name}</div>
                  <div style={{ fontSize: "0.75rem", color: "#A7F3D0" }}>Online • Table Concierge</div>
                </div>
              </div>
              <button onClick={() => setShowLiveChatModal(false)} style={{ color: "#FFF", fontSize: "1.1rem" }}>✕</button>
            </div>

            {/* Chat Messages Body */}
            <div style={{
              padding: "16px",
              minHeight: "260px",
              maxHeight: "340px",
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: "10px"
            }}>
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  style={{
                    alignSelf: msg.sender === "customer" ? "flex-end" : "flex-start",
                    background: msg.sender === "customer" ? "#DCF8C6" : "#FFFFFF",
                    color: "#1A1A1A",
                    padding: "8px 12px",
                    borderRadius: "12px",
                    maxWidth: "80%",
                    boxShadow: "0 1px 2px rgba(0,0,0,0.1)",
                    fontSize: "0.85rem"
                  }}
                >
                  <div>{msg.text}</div>
                  <div style={{ fontSize: "0.68rem", color: "#888", textAlign: "right", marginTop: "3px" }}>
                    {msg.time} {msg.sender === "customer" && "✓✓"}
                  </div>
                </div>
              ))}
            </div>

            {/* Chat Typing Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!chatInput.trim()) return;
                const newMsg = {
                  sender: "customer",
                  text: chatInput,
                  time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                };
                setChatMessages(prev => [...prev, newMsg]);
                setChatInput("");
                playChime("success");

                // Automated Barista Response Simulation after 1 sec
                setTimeout(() => {
                  setChatMessages(prev => [
                    ...prev,
                    {
                      sender: "barista",
                      text: "Noted with pleasure! We are taking care of that for your order right away. ☕✨",
                      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    }
                  ]);
                  playChime("alert");
                }, 1000);
              }}
              style={{
                background: "#F0F0F0",
                padding: "8px 12px",
                display: "flex",
                gap: "8px",
                alignItems: "center"
              }}
            >
              <input
                type="text"
                placeholder="Type a message to the barista..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                style={{
                  flex: 1,
                  padding: "8px 12px",
                  borderRadius: "20px",
                  border: "1px solid #CCC",
                  outline: "none",
                  fontSize: "0.85rem"
                }}
              />
              <button
                type="submit"
                style={{
                  background: "#128C7E",
                  color: "#FFF",
                  border: "none",
                  borderRadius: "50%",
                  width: "36px",
                  height: "36px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer"
                }}
              >
                ➤
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: MY RESERVATIONS HUB
          ======================================================== */}
      {showMyReservationsModal && (
        <div className="modal-overlay" onClick={() => setShowMyReservationsModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "650px", padding: "26px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h3 style={{ fontSize: "1.3rem" }}>My Booked Table Reservations</h3>
              <button onClick={() => setShowMyReservationsModal(false)}>✕</button>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {myReservations && myReservations.length > 0 ? (
                myReservations.map(res => (
                  <div key={res.id} style={{
                    padding: "14px",
                    background: "var(--cafe-card-alt)",
                    borderRadius: "10px",
                    border: "1px solid var(--cafe-border-light)",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center"
                  }}>
                    <div>
                      <div style={{ fontWeight: "700", fontSize: "0.95rem" }}>
                        {res.customerName} • {res.partySize} Guests
                      </div>
                      <div style={{ fontSize: "0.8rem", color: "var(--cafe-text-muted)" }}>
                        {res.date} at {res.time} • {res.tableNumber}
                      </div>
                      <span className="badge badge-active" style={{ marginTop: "4px" }}>{res.status}</span>
                    </div>

                    <div style={{ display: "flex", gap: "8px" }}>
                      <button
                        onClick={() => handleOpenCheckinQr(res)}
                        className="btn-secondary"
                        style={{ padding: "6px 10px", fontSize: "0.78rem" }}
                      >
                        <QrCode size={14} /> Check-In QR
                      </button>

                      <button
                        onClick={() => onCancelReservation(res.id)}
                        className="btn-danger"
                        style={{ padding: "6px 10px", fontSize: "0.78rem" }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p style={{ textAlign: "center", color: "var(--cafe-text-muted)", padding: "20px" }}>
                  No active reservations found under your profile.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: CHECK-IN QR CODE
          ======================================================== */}
      {viewingCheckinQr && (
        <div className="modal-overlay" onClick={() => setViewingCheckinQr(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "380px", padding: "28px", textAlign: "center" }}>
            <h3 style={{ fontSize: "1.3rem" }}>Entrance Check-In QR</h3>
            <p style={{ fontSize: "0.82rem", color: "var(--cafe-text-muted)", margin: "4px 0 16px 0" }}>
              Show this QR code at {selectedCafe.name} entrance for instant check-in.
            </p>

            {checkinQrDataUrl && (
              <img src={checkinQrDataUrl} alt="Check In QR" style={{ width: "200px", height: "200px", margin: "0 auto", borderRadius: "10px" }} />
            )}

            <div style={{ fontSize: "0.8rem", color: "var(--cafe-text)", marginTop: "14px" }}>
              ID: <strong>{viewingCheckinQr.id}</strong> • {viewingCheckinQr.customerName}
            </div>

            <button onClick={() => setViewingCheckinQr(null)} className="btn-secondary" style={{ marginTop: "18px" }}>
              Close
            </button>
          </div>
        </div>
      )}

      {/* Toast Notification when item added to order */}
      {addedToast && (
        <div style={{
          position: "fixed",
          top: "80px",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 1000,
          background: "var(--cafe-espresso)",
          color: "#FFF",
          border: "1px solid var(--cafe-primary)",
          padding: "10px 20px",
          borderRadius: "999px",
          boxShadow: "0 10px 30px rgba(0, 0, 0, 0.4)",
          display: "flex",
          alignItems: "center",
          gap: "10px",
          animation: "fadeIn 0.2s ease"
        }}>
          <Check size={18} color="var(--cafe-primary)" />
          <span style={{ fontSize: "0.88rem", fontWeight: "600" }}>
            Added {addedToast.qty}x {addedToast.name} to your order!
          </span>
          <button
            onClick={() => {
              setAddedToast(null);
              setIsCartOpen(true);
            }}
            style={{
              background: "var(--cafe-primary)",
              color: "#FFF",
              border: "none",
              padding: "4px 12px",
              borderRadius: "999px",
              fontSize: "0.78rem",
              fontWeight: "700",
              cursor: "pointer",
              marginLeft: "6px"
            }}
          >
            View Order
          </button>
        </div>
      )}

      {/* Floating Bottom Quick Order Bar when items are in cart (Blinkit Style) */}
      {cart.length > 0 && !isCartOpen && (
        <div style={{
          position: "fixed",
          bottom: "20px",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 99,
          width: "calc(100% - 32px)",
          maxWidth: "520px",
          animation: "fadeIn 0.25s ease",
          display: "flex",
          flexDirection: "column",
          alignItems: "stretch",
          filter: "drop-shadow(0 14px 35px rgba(0, 0, 0, 0.45))"
        }}>
          {/* Blinkit-Style Top Item Images Strip (Just on top of the View Order bar) */}
          <div 
            onClick={() => setIsCartOpen(true)}
            style={{
              background: "var(--cafe-card)",
              border: "1px solid var(--cafe-border)",
              borderBottom: "none",
              borderRadius: "20px 20px 0 0",
              padding: "10px 18px 8px 18px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: "12px",
              cursor: "pointer",
              boxShadow: "0 -4px 16px rgba(0, 0, 0, 0.08)"
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "12px", overflowX: "auto", scrollbarWidth: "none", padding: "4px 2px" }}>
              {cart.map((item, idx) => (
                <div key={item.cartId || idx} style={{ position: "relative", flexShrink: 0 }}>
                  <div style={{
                    width: "52px",
                    height: "52px",
                    borderRadius: "50%",
                    padding: "2px",
                    background: "linear-gradient(135deg, var(--cafe-primary) 0%, #1A120B 100%)",
                    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                  }}>
                    <img
                      src={item.image || "/images/artisan_coffee_desserts.jpg"}
                      alt={item.name}
                      style={{
                        width: "100%",
                        height: "100%",
                        borderRadius: "50%",
                        objectFit: "cover",
                        display: "block"
                      }}
                    />
                  </div>
                  <span style={{
                    position: "absolute",
                    top: "-2px",
                    right: "-2px",
                    background: "var(--cafe-primary)",
                    color: "#FFF",
                    fontSize: "0.72rem",
                    fontWeight: "800",
                    borderRadius: "50%",
                    minWidth: "20px",
                    height: "20px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "0 4px",
                    border: "2px solid #FFF",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.25)"
                  }}>
                    {item.quantity}
                  </span>
                </div>
              ))}
            </div>

            <div style={{
              fontSize: "0.78rem",
              fontWeight: "700",
              color: "var(--cafe-primary)",
              whiteSpace: "nowrap",
              display: "flex",
              alignItems: "center",
              gap: "3px"
            }}>
              <span>{cart.reduce((s, i) => s + (i.quantity || 1), 0)} {cart.reduce((s, i) => s + (i.quantity || 1), 0) === 1 ? "dish" : "dishes"}</span>
              <ChevronRight size={14} />
            </div>
          </div>

          {/* Main View Order Action Bar */}
          <div 
            onClick={() => setIsCartOpen(true)}
            style={{
              background: "linear-gradient(135deg, var(--cafe-espresso) 0%, #2A1C12 100%)",
              color: "#FFF",
              borderRadius: "0 0 18px 18px",
              padding: "12px 20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              border: "1px solid var(--cafe-border)",
              borderTop: "1px solid rgba(255, 255, 255, 0.1)",
              cursor: "pointer"
            }}
          >
            <div>
              <div style={{ fontSize: "1.1rem", fontWeight: "800", color: "#FFF", letterSpacing: "-0.3px" }}>
                ₹{Math.round(cartFinalTotal)}
              </div>
              <div style={{ fontSize: "0.75rem", color: "rgba(255, 255, 255, 0.7)", marginTop: "1px" }}>
                Total payable • Direct Table / Delivery
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsCartOpen(true);
              }}
              className="btn-primary"
              style={{
                padding: "9px 20px",
                fontSize: "0.9rem",
                fontWeight: "700",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                borderRadius: "12px",
                boxShadow: "0 4px 14px var(--cafe-primary-glow)"
              }}
            >
              <span>View Order</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
