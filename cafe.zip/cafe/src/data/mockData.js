// Mock Database & Seed State for AromaCloud Platform
// Universal Signature Café Palette: Warm Amber Roast & Espresso Obsidian

export const INITIAL_CAFES = [
  {
    id: "cafe-aroma-01",
    name: "Aroma Roast Artisan Café",
    ownerName: "Marcus Vance",
    mobile: "+1 (555) 234-8901",
    email: "marcus@aromaroast.com",
    shopAddress: "42 Heritage Boulevard, Old Town",
    city: "San Francisco",
    state: "California",
    pincode: "94103",
    description: "An authentic specialty micro-roastery and Italian hearth kitchen serving hand-pulled espresso, slow-fermented wood-fired sourdough pizzas, and delicate house-made pastas. Designed with reclaimed warm walnut, ambient brass lighting, and leafy indoor courtyard seating.",
    contactNumber: "+1 (555) 234-8900",
    category: "Fine Casual",
    seatingCapacity: 48,
    openHours: "07:30 - 22:30",
    cuisines: ["Artisan Coffee", "Italian", "Continental", "Bakery"],
    image: "/images/artisan_cafe_ambiance.jpg",
    gallery: [
      "/images/artisan_cafe_ambiance.jpg",
      "/images/gourmet_cafe_dishes.jpg",
      "/images/artisan_coffee_desserts.jpg"
    ],
    bankDetails: {
      bankName: "First Heritage Merchant Bank",
      accountNumber: "9832-8492-1049",
      swiftIfsc: "FHMBUS33SF",
      accountType: "Commercial Business Checking"
    },
    credentials: {
      username: "aroma_roast_marcus",
      tempPassword: "Aroma#Secure2026!",
      permissionLevel: "Full Operations",
      status: "active"
    },
    status: "active",
    rating: 4.9,
    reviewCount: 342,
    priceRange: "$$",
    createdAt: "2026-01-15",
    updatedAt: "2026-10-18",
    stats: {
      monthlyOrders: 1420,
      monthlyRevenue: 38450,
      customerGrowth: "+18.4%"
    },
    tables: [
      {
        id: "T001",
        number: "Table 1 (Window)",
        capacity: 2,
        location: "Near Window",
        features: ["High chair available", "Scenic street view", "Power outlet"],
        status: "available",
        notes: "Perfect for couples or casual reading with natural daylight.",
        setupFee: 150,
        scanCount: 142
      },
      {
        id: "T002",
        number: "Table 2 (Window)",
        capacity: 4,
        location: "Near Window",
        features: ["High chair available", "Scenic street view"],
        status: "occupied",
        notes: "Currently seated party of 3.",
        setupFee: 200,
        scanCount: 219
      },
      {
        id: "T003",
        number: "Table 3 (Center Courtyard)",
        capacity: 4,
        location: "Center",
        features: ["Spacious", "Wheelchair accessible"],
        status: "available",
        notes: "Under suspended hanging fern chandeliers.",
        setupFee: 200,
        scanCount: 98
      },
      {
        id: "T004",
        number: "Table 4 (Quiet Corner)",
        capacity: 6,
        location: "Corner",
        features: ["Plush leather booth", "VIP privacy", "High chair"],
        status: "reserved",
        notes: "Reserved for Mr. Sterling at 19:30.",
        setupFee: 300,
        scanCount: 310
      },
      {
        id: "T005",
        number: "Table 5 (Terrace Garden)",
        capacity: 4,
        location: "Outdoor",
        features: ["Heated patio", "Pet friendly", "Fresh herbs view"],
        status: "available",
        notes: "Outdoor heaters active in evening.",
        setupFee: 200,
        scanCount: 164
      },
      {
        id: "T006",
        number: "Table 6 (Grand VIP Table)",
        capacity: 8,
        location: "VIP",
        features: ["Solid walnut dining slab", "Sommelier service", "Private wine chiller"],
        status: "available",
        notes: "Includes dedicated server.",
        setupFee: 400,
        scanCount: 75
      },
      {
        id: "T007",
        number: "Table 7 (Espresso Bar)",
        capacity: 2,
        location: "Center",
        features: ["Bar seating", "Barista view", "Quick dine"],
        status: "available",
        notes: "Front row to La Marzocco machine.",
        setupFee: 150,
        scanCount: 88
      },
      {
        id: "T008",
        number: "Table 8 (Fireplace Nook)",
        capacity: 4,
        location: "Corner",
        features: ["Fireplace ambiance", "Acoustic insulation"],
        status: "maintenance",
        notes: "Varnish touch-up today.",
        setupFee: 200,
        scanCount: 42
      }
    ],
    menuCategories: [
      { id: "cat-coffee", name: "Espresso & Specialty Brews", icon: "☕", displayOrder: 1, active: true },
      { id: "cat-pizza", name: "Wood-Fired Pizza", icon: "🍕", displayOrder: 2, active: true },
      { id: "cat-pasta", name: "Handcrafted Pasta", icon: "🍝", displayOrder: 3, active: true },
      { id: "cat-appetizers", name: "Artisan Appetizers", icon: "🥗", displayOrder: 4, active: true },
      { id: "cat-desserts", name: "Bakery & Desserts", icon: "🥐", displayOrder: 5, active: true },
      { id: "cat-beverages", name: "Cooling Refreshers", icon: "🍹", displayOrder: 6, active: true }
    ],
    menuItems: [
      {
        id: "item-01",
        name: "Truffle Wild Mushroom Pizza",
        categoryId: "cat-pizza",
        description: "Slow-fermented 48h sourdough crust, fior di latte mozzarella, roasted cremini & chanterelle mushrooms, black truffle carpaccio, and fresh thyme.",
        price: 490,
        discountedPrice: 420,
        status: "in_stock",
        stockQty: 40,
        prepTimeMins: 14,
        spiceLevel: "mild",
        dietary: "veg", // "veg", "non-veg", "vegan"
        calories: 780,
        nutrition: { protein: "32g", carbs: "84g", fat: "28g" },
        allergens: ["Dairy", "Gluten"],
        image: "/images/gourmet_cafe_dishes.jpg",
        popular: true,
        customizations: [
          {
            id: "opt-crust",
            name: "Crust Style",
            required: true,
            type: "single", // radio
            options: [
              { name: "Neapolitan Sourdough (Classic)", price: 0 },
              { name: "Crispy Thin Crust", price: 0 },
              { name: "Gluten-Free Cauliflower Crust", price: 60 }
            ]
          },
          {
            id: "opt-addons",
            name: "Extra Toppings",
            required: false,
            type: "multiple", // checkbox
            options: [
              { name: "Extra Black Truffle Shavings", price: 90 },
              { name: "Buffalo Mozzarella DOP", price: 60 },
              { name: "Caramelized Balsamic Onions", price: 40 },
              { name: "Wild Rocket & Shaved Parmesan", price: 50 }
            ]
          }
        ]
      },
      {
        id: "item-02",
        name: "Artisan Tagliatelle Carbonara",
        categoryId: "cat-pasta",
        description: "Silky hand-rolled egg pasta with cured Italian guanciale, pasture egg yolks, 24-month aged Pecorino Romano, and toasted Tellicherry peppercorn.",
        price: 440,
        status: "in_stock",
        stockQty: 25,
        prepTimeMins: 16,
        spiceLevel: "medium",
        dietary: "non-veg",
        calories: 820,
        nutrition: { protein: "38g", carbs: "76g", fat: "36g" },
        allergens: ["Eggs", "Dairy", "Gluten"],
        image: "/images/gourmet_cafe_dishes.jpg",
        popular: true,
        customizations: [
          {
            id: "opt-pasta-addon",
            name: "Additions & Extras",
            required: false,
            type: "multiple",
            options: [
              { name: "Extra Crispy Guanciale", price: 80 },
              { name: "Extra Aged Pecorino", price: 50 },
              { name: "Pan-Seared King Oyster Mushroom", price: 60 }
            ]
          }
        ]
      },
      {
        id: "item-03",
        name: "Velvet Amber Flat White",
        categoryId: "cat-coffee",
        description: "Double ristretto extracted from our single-origin Ethiopian Guji roast, textured micro-foam milk poured with signature rosetta latte art.",
        price: 220,
        status: "in_stock",
        stockQty: 100,
        prepTimeMins: 4,
        spiceLevel: "mild",
        dietary: "veg",
        calories: 140,
        nutrition: { protein: "7g", carbs: "11g", fat: "6g" },
        allergens: ["Dairy (Optional Plant Milks)"],
        image: "/images/artisan_coffee_desserts.jpg",
        popular: true,
        customizations: [
          {
            id: "opt-milk",
            name: "Select Your Milk",
            required: true,
            type: "single",
            options: [
              { name: "Whole Organic Cream Milk", price: 0 },
              { name: "Oatly Barista Edition (Oat)", price: 40 },
              { name: "California Roasted Almond Milk", price: 40 },
              { name: "Coconut Silk Milk", price: 40 }
            ]
          },
          {
            id: "opt-coffee-shots",
            name: "Espresso Customization",
            required: false,
            type: "multiple",
            options: [
              { name: "Extra Espresso Shot", price: 35 },
              { name: "Madagascar Vanilla Bean Syrup", price: 30 },
              { name: "Salted Caramel Drizzle", price: 30 },
              { name: "Decaf Swiss Water Process", price: 0 }
            ]
          }
        ]
      },
      {
        id: "item-04",
        name: "Flaky Almond Praline Croissant",
        categoryId: "cat-desserts",
        description: "Twice-baked French butter croissant filled with silky almond frangipane cream, topped with toasted sliced almonds and powdered sugar.",
        price: 190,
        discountedPrice: 160,
        status: "in_stock",
        stockQty: 18,
        prepTimeMins: 3,
        spiceLevel: "mild",
        dietary: "veg",
        calories: 420,
        nutrition: { protein: "9g", carbs: "48g", fat: "22g" },
        allergens: ["Tree Nuts", "Dairy", "Gluten", "Eggs"],
        image: "/images/artisan_coffee_desserts.jpg",
        popular: true,
        customizations: [
          {
            id: "opt-croissant",
            name: "Preparation",
            required: false,
            type: "single",
            options: [
              { name: "Warm & Crispy from Oven", price: 0 },
              { name: "Ambient / Room Temp", price: 0 }
            ]
          }
        ]
      },
      {
        id: "item-05",
        name: "Burrata & Heirloom Berry Salad",
        categoryId: "cat-appetizers",
        description: "Fresh Puglia burrata bulb, wild baby arugula, ripe California strawberries, blackberries, toasted walnuts, aged Modena balsamic glaze.",
        price: 360,
        status: "in_stock",
        stockQty: 20,
        prepTimeMins: 8,
        spiceLevel: "mild",
        dietary: "veg",
        calories: 390,
        nutrition: { protein: "16g", carbs: "18g", fat: "26g" },
        allergens: ["Dairy", "Tree Nuts"],
        image: "/images/gourmet_cafe_dishes.jpg",
        popular: false,
        customizations: [
          {
            id: "opt-salad",
            name: "Salad Enhancements",
            required: false,
            type: "multiple",
            options: [
              { name: "Toasted Garlic Focaccia (2 pcs)", price: 50 },
              { name: "Prosciutto di Parma Crisps", price: 80 }
            ]
          }
        ]
      },
      {
        id: "item-06",
        name: "Traditional Tiramisu al Mascarpone",
        categoryId: "cat-desserts",
        description: "Savoiardi ladyfingers soaked in our house espresso roast, layered with whipped Zabaione mascarpone cream, dusted with Valrhona 70% cocoa.",
        price: 260,
        status: "in_stock",
        stockQty: 14,
        prepTimeMins: 4,
        spiceLevel: "mild",
        dietary: "veg",
        calories: 460,
        nutrition: { protein: "8g", carbs: "52g", fat: "24g" },
        allergens: ["Dairy", "Eggs", "Gluten"],
        image: "/images/artisan_coffee_desserts.jpg",
        popular: true,
        customizations: []
      }
    ],
    offers: [
      {
        id: "OFFER-01",
        code: "AROMA20",
        title: "20% Off Welcome Feast",
        description: "Enjoy 20% off your entire bill on orders over ₹500. Valid for dine-in & table reservations.",
        discountType: "percentage",
        value: 20,
        minOrderValue: 500,
        validUntil: "2026-12-31",
        applicableCategories: ["cat-pizza", "cat-pasta", "cat-appetizers"],
        usageCount: 89,
        active: true
      },
      {
        id: "OFFER-02",
        code: "COFFEEBREW",
        title: "₹80 Off Signature Brews",
        description: "Get ₹80 off when you pair any gourmet pastry with specialty coffee on orders over ₹250.",
        discountType: "flat",
        value: 80,
        minOrderValue: 250,
        validUntil: "2026-11-30",
        applicableCategories: ["cat-coffee", "cat-desserts"],
        usageCount: 142,
        active: true
      }
    ],
    reservations: [
      {
        id: "RES-8491",
        customerName: "Sophia Montgomery",
        phone: "+1 (555) 782-3901",
        email: "sophia.m@gmail.com",
        date: "2026-10-19",
        time: "19:00",
        partySize: 4,
        tableId: "T004",
        tableNumber: "Table 4 (Quiet Corner)",
        status: "confirmed", // pending, confirmed, arrived, cancelled, no-show
        seatingPreference: "Corner/Quiet Area",
        occasion: "Anniversary",
        specialRequests: "Window corner if possible, celebrating 5th wedding anniversary with complimentary dessert sparkler.",
        customSetup: {
          baseTable: "4-seater",
          extraChairs: 0,
          setupFee: 200
        },
        source: "Online Website",
        createdAt: "2026-10-17 14:20"
      },
      {
        id: "RES-8492",
        customerName: "Dr. Alexander Kim",
        phone: "+1 (555) 491-0023",
        email: "alexander.kim@ucsf.edu",
        date: "2026-10-19",
        time: "13:30",
        partySize: 2,
        tableId: "T001",
        tableNumber: "Table 1 (Window)",
        status: "arrived",
        seatingPreference: "Near Window",
        occasion: "Business Meeting",
        specialRequests: "Quiet spot near power outlets for tablet presentation.",
        customSetup: {
          baseTable: "2-seater",
          extraChairs: 0,
          setupFee: 150
        },
        source: "Online Website",
        createdAt: "2026-10-18 09:15"
      },
      {
        id: "RES-8493",
        customerName: "Liam O'Connor",
        phone: "+1 (555) 912-4481",
        email: "liam.oconnor@techflow.io",
        date: "2026-10-19",
        time: "20:30",
        partySize: 6,
        tableId: "T006",
        tableNumber: "Table 6 (Grand VIP Table)",
        status: "pending",
        seatingPreference: "VIP Area",
        occasion: "Birthday",
        specialRequests: "Need high chair for a 2-year old toddler and surprise candle.",
        customSetup: {
          baseTable: "6-seater",
          extraChairs: 2, // custom extra chairs
          setupFee: 400 // 300 + 2*50
        },
        source: "Online Website",
        createdAt: "2026-10-19 10:45"
      }
    ],
    orders: [
      {
        id: "ORD-9281",
        tableId: "T002",
        tableNumber: "Table 2 (Window)",
        customerName: "Elena & Guest",
        phone: "+1 (555) 302-9912",
        source: "Table QR Scan",
        items: [
          {
            name: "Truffle Wild Mushroom Pizza",
            qty: 1,
            price: 490,
            customizations: ["Neapolitan Sourdough", "Extra Black Truffle Shavings (+₹120)"],
            prepared: false
          },
          {
            name: "Velvet Amber Flat White",
            qty: 2,
            price: 220,
            customizations: ["Oatly Barista Edition (+₹40)"],
            prepared: true
          }
        ],
        subtotal: 1130,
        discount: 0,
        tax: 56.50,
        total: 1186.50,
        specialNotes: "Please bring flat whites first while pizza bakes.",
        status: "preparing", // received, preparing, ready, delivered
        createdAt: "2026-10-19 12:35",
        estimatedMinutes: 18,
        elapsedMinutes: 9,
        paymentMethod: "Apple Pay (Online Paid)"
      },
      {
        id: "ORD-9282",
        tableId: "T004",
        tableNumber: "Table 4 (Quiet Corner)",
        customerName: "David Harrison",
        phone: "+1 (555) 881-2299",
        source: "Table QR Scan",
        items: [
          {
            name: "Artisan Tagliatelle Carbonara",
            qty: 1,
            price: 440,
            customizations: ["Extra Crispy Guanciale (+₹90)"],
            prepared: false
          },
          {
            name: "Burrata & Heirloom Berry Salad",
            qty: 1,
            price: 360,
            customizations: ["Toasted Garlic Focaccia (+₹70)"],
            prepared: false
          }
        ],
        subtotal: 960,
        discount: 100,
        tax: 43.00,
        total: 903.00,
        specialNotes: "Guest has dairy preference, please serve fresh focaccia hot.",
        status: "received",
        createdAt: "2026-10-19 12:48",
        estimatedMinutes: 20,
        elapsedMinutes: 3,
        paymentMethod: "Credit Card (Visa)"
      },
      {
        id: "ORD-9280",
        tableId: "T001",
        tableNumber: "Table 1 (Window)",
        customerName: "Dr. Alexander Kim",
        phone: "+1 (555) 491-0023",
        source: "Table QR Scan",
        items: [
          {
            name: "Velvet Amber Flat White",
            qty: 1,
            price: 220,
            customizations: ["Whole Organic Cream Milk"],
            prepared: true
          },
          {
            name: "Flaky Almond Praline Croissant",
            qty: 1,
            price: 190,
            customizations: ["Warm & Crispy from Oven"],
            prepared: true
          }
        ],
        subtotal: 410,
        discount: 0,
        tax: 20.50,
        total: 430.50,
        specialNotes: "Served promptly.",
        status: "delivered",
        createdAt: "2026-10-19 12:10",
        estimatedMinutes: 6,
        elapsedMinutes: 40,
        paymentMethod: "Credit Card (Mastercard)"
      }
    ],
    eventRequests: [
      {
        id: "EVT-102",
        eventName: "Design Guild Annual Autumn Banquet",
        customerName: "Victoria Sterling",
        phone: "+1 (555) 772-9900",
        email: "v.sterling@designguild.org",
        date: "2026-11-14",
        timeRange: "18:00 - 23:00",
        guests: 45,
        budget: "₹45,000 - ₹60,000",
        requirements: "Full restaurant buyout, custom 4-course Italian tasting menu with wine pairings, wireless microphone for keynote speeches, ambient background jazz.",
        status: "quote_sent",
        quoteAmount: 52000,
        createdAt: "2026-10-15"
      }
    ]
  },
  {
    id: "cafe-velvet-02",
    name: "Velvet Bean Bistro & Bakery",
    ownerName: "Elena Rostova",
    mobile: "+1 (555) 472-9102",
    email: "elena@velvetbean.com",
    shopAddress: "88 Victorian Row, Presidio Heights",
    city: "San Francisco",
    state: "California",
    pincode: "94118",
    description: "Chic French-European pastry parlour and botanical bistro with glass greenhouse terrace, artisanal sourdough pastries, organic matcha brews, and gourmet brunch plates.",
    contactNumber: "+1 (555) 472-9100",
    category: "Bakery & Bistro",
    seatingCapacity: 36,
    openHours: "08:00 - 20:00",
    cuisines: ["Bakery", "Artisan Coffee", "Continental", "French"],
    image: "/images/artisan_coffee_desserts.jpg",
    gallery: [
      "/images/artisan_coffee_desserts.jpg",
      "/images/artisan_cafe_ambiance.jpg"
    ],
    bankDetails: {
      bankName: "Pacific Coast Commercial",
      accountNumber: "4421-9081-3312",
      swiftIfsc: "PCCBUS66SF",
      accountType: "Checking"
    },
    credentials: {
      username: "velvet_bean_elena",
      tempPassword: "Velvet#Pass991!",
      permissionLevel: "Full Operations",
      status: "active"
    },
    status: "active",
    rating: 4.8,
    reviewCount: 215,
    priceRange: "$$",
    createdAt: "2026-03-10",
    updatedAt: "2026-10-16",
    stats: {
      monthlyOrders: 980,
      monthlyRevenue: 24600,
      customerGrowth: "+12.1%"
    },
    tables: [
      { id: "T001", number: "Table 1 (Garden)", capacity: 2, location: "Outdoor", features: ["Botanical view"], status: "available", setupFee: 15, scanCount: 88 },
      { id: "T002", number: "Table 2 (Greenhouse)", capacity: 4, location: "Near Window", features: ["Glass atrium"], status: "occupied", setupFee: 20, scanCount: 120 },
      { id: "T003", number: "Table 3 (Parlour Booth)", capacity: 6, location: "VIP", features: ["Velvet banquette"], status: "available", setupFee: 30, scanCount: 65 }
    ],
    menuCategories: [
      { id: "cat-pastries", name: "Artisanal Viennoiserie", icon: "🥐", displayOrder: 1, active: true },
      { id: "cat-brunch", name: "Bistro Brunch Plates", icon: "🍳", displayOrder: 2, active: true },
      { id: "cat-brews", name: "Specialty Tea & Coffee", icon: "🍵", displayOrder: 3, active: true }
    ],
    menuItems: [
      {
        id: "vb-01",
        name: "Wild Truffle Poached Eggs Benedict",
        categoryId: "cat-brunch",
        description: "Organic pasture poached eggs over warm toasted sourdough brioche with black truffle hollandaise and asparagus spears.",
        price: 16.50,
        status: "in_stock",
        stockQty: 30,
        prepTimeMins: 12,
        spiceLevel: "mild",
        dietary: "veg",
        calories: 640,
        nutrition: { protein: "24g", carbs: "42g", fat: "38g" },
        allergens: ["Eggs", "Dairy", "Gluten"],
        image: "/images/artisan_coffee_desserts.jpg",
        popular: true,
        customizations: []
      }
    ],
    offers: [],
    reservations: [],
    orders: [],
    eventRequests: []
  },
  {
    id: "cafe-copper-03",
    name: "Copper Kettle Hearth & Kitchen",
    ownerName: "David Chen",
    mobile: "+1 (555) 883-2019",
    email: "david@copperkettle.com",
    shopAddress: "120 Mission Innovation Way",
    city: "San Francisco",
    state: "California",
    pincode: "94105",
    description: "Fast-casual culinary tech lounge featuring wood-grilled flatbreads, cold-pressed elixirs, craft kombuchas, and lightning-fast digital table ordering.",
    contactNumber: "+1 (555) 883-2000",
    category: "Fast-Casual",
    seatingCapacity: 60,
    openHours: "07:00 - 21:00",
    cuisines: ["Fast-Casual", "Healthy Gourmet", "Cold Brews", "Global"],
    image: "/images/gourmet_cafe_dishes.jpg",
    gallery: [
      "/images/gourmet_cafe_dishes.jpg"
    ],
    bankDetails: {
      bankName: "Metro Silicon Bank",
      accountNumber: "7721-3329-8810",
      swiftIfsc: "MSBUS77SF",
      accountType: "Commercial"
    },
    credentials: {
      username: "copper_kettle_david",
      tempPassword: "Copper#99281!",
      permissionLevel: "Full Operations",
      status: "active"
    },
    status: "active",
    rating: 4.7,
    reviewCount: 189,
    priceRange: "$$",
    createdAt: "2026-05-01",
    updatedAt: "2026-10-18",
    stats: {
      monthlyOrders: 1850,
      monthlyRevenue: 42100,
      customerGrowth: "+24.8%"
    },
    tables: [
      { id: "T001", number: "Booth 1", capacity: 4, location: "Center", features: ["Power hubs"], status: "available", setupFee: 20, scanCount: 190 },
      { id: "T002", number: "Booth 2", capacity: 4, location: "Center", features: ["Power hubs"], status: "available", setupFee: 20, scanCount: 184 }
    ],
    menuCategories: [],
    menuItems: [],
    offers: [],
    reservations: [],
    orders: [],
    eventRequests: []
  }
];

// Helper: Load or Initialize LocalStorage State
export const STORAGE_KEY = "aroma_cloud_cafes_data_v5_inr";

export function getStoredCafes() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error("Failed to parse stored cafes:", e);
  }
  saveStoredCafes(INITIAL_CAFES);
  return INITIAL_CAFES;
}

export function saveStoredCafes(cafes) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cafes));
  } catch (e) {
    console.error("Failed to save cafes:", e);
  }
}

// Generate an .ICS Calendar File for download
export function generateIcsFile(reservation, cafe) {
  const startDateTime = new Date(`${reservation.date}T${reservation.time}:00`);
  const endDateTime = new Date(startDateTime.getTime() + 2 * 60 * 60 * 1000); // 2 hour duration

  const formatIcsDate = (date) => {
    return date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  };

  const icsContent = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//AromaCloud Platform//Table Reservation//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${reservation.id}@aromacloud.com`,
    `DTSTAMP:${formatIcsDate(new Date())}`,
    `DTSTART:${formatIcsDate(startDateTime)}`,
    `DTEND:${formatIcsDate(endDateTime)}`,
    `SUMMARY:Table Reservation at ${cafe.name} (${reservation.partySize} Guests)`,
    `DESCRIPTION:Reservation Confirmed! Table: ${reservation.tableNumber || 'Assigned on arrival'}. Occasion: ${reservation.occasion || 'Dining'}. Special requests: ${reservation.specialRequests || 'None'}. Confirmation ID: ${reservation.id}`,
    `LOCATION:${cafe.name}, ${cafe.shopAddress}, ${cafe.city}`,
    "STATUS:CONFIRMED",
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");

  const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `Reservation_${reservation.id}_${cafe.name.replace(/\s+/g, "_")}.ics`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// CSV Export Helper
export function exportToCsv(filename, rows) {
  if (!rows || !rows.length) return;
  const separator = ",";
  const keys = Object.keys(rows[0]);
  const csvContent =
    keys.join(separator) +
    "\n" +
    rows.map((row) => {
      return keys
        .map((k) => {
          let cell = row[k] === null || row[k] === undefined ? "" : row[k];
          cell = cell instanceof Date ? cell.toLocaleString() : cell.toString().replace(/"/g, '""');
          if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
          return cell;
        })
        .join(separator);
    }).join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Currency formatting helper
export const CURRENCIES = {
  INR: { symbol: "₹", rate: 1.0, name: "INR (₹)" }
};

export function formatPrice(amount, currencyCode = "INR") {
  const num = Number(amount) || 0;
  return `₹${Math.round(num).toLocaleString("en-IN")}`;
}

// Celebration Add-On Packages
export const CELEBRATION_PACKS = [
  {
    id: "pack-bday",
    name: "Artisan Birthday Cake & Sparkler",
    icon: "🎂",
    price: 449,
    description: "House-baked miniature triple-chocolate cake with golden sparkler candle delivered to table."
  },
  {
    id: "pack-romance",
    name: "Rose Petals & Sparkling Beverage",
    icon: "🥂",
    price: 599,
    description: "Fresh fragrant rose petals table decor and two complimentary chilled Italian Prosecco flutes."
  },
  {
    id: "pack-business",
    name: "Executive Presentation Setup",
    icon: "💼",
    price: 349,
    description: "Power extension hub, high-speed conference Wi-Fi pass, and still mineral water bottles."
  }
];

// Play subtle UI chime (Web Audio API)
export function playChime(type = "success") {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === "success") {
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.15); // G5
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.start();
      osc.stop(ctx.currentTime + 0.36);
    } else if (type === "alert") {
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
      osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      osc.start();
      osc.stop(ctx.currentTime + 0.31);
    }
  } catch (err) {
    // Ignore audio context autoplay errors
  }
}
