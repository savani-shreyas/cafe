import QRCode from "qrcode";

// Generate QR Code as Data URL
export async function generateQrDataUrl(text, options = {}) {
  try {
    const opts = {
      width: options.width || 240,
      margin: options.margin || 2,
      color: {
        dark: options.darkColor || "#1A120B", // Deep Espresso Roast
        light: options.lightColor || "#FFFFFF"
      }
    };
    return await QRCode.toDataURL(text, opts);
  } catch (err) {
    console.error("QR Code generation error:", err);
    return "";
  }
}

// Generate URL for table scan
export function getTableScanUrl(cafeId, tableId) {
  // Uses clean URL parameters for immediate local testing
  const baseUrl = window.location.origin + window.location.pathname;
  return `${baseUrl}?cafe=${cafeId}&table=${tableId}`;
}
